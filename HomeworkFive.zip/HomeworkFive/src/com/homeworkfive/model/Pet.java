package com.homeworkfive.model;

import java.io.Serializable;

public class Pet implements Serializable, Comparable<Object> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String petType;
	private int petID;
	private String petName;
	private double birthWeight;

	public Pet(int paramInt, String paramString, double paramDouble) {
		this.petID = paramInt;
		this.petName = paramString;
		this.birthWeight = paramDouble;
	}

	public void setType(String paramString) {
		this.petType = paramString;
	}

	public void setID(int paramInt) {
		this.petID = paramInt;
	}

	public void setName(String paramString) {
		this.petName = paramString;
	}

	public void setWeight(double paramDouble) {
		this.birthWeight = paramDouble;
	}

	public String getType() {
		return this.petType;
	}

	public int getID() {
		return this.petID;
	}

	public String getName() {
		return this.petName;
	}

	public double getWeight() {
		return this.birthWeight;
	}

	public Pet getObj() {
		return this;
	}

	public int compareTo(Object paramObject) {
		Pet localPet = (Pet) paramObject;
		if (this.petID < localPet.petID) {
			return -1;
		}
		if (this.petID > localPet.petID) {
			return 1;
		}
		return 0;
	}
}

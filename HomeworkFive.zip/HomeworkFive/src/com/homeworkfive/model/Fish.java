package com.homeworkfive.model;

public class Fish extends Pet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String scaleCondition;
	private String isFreshWater;

	public Fish(int paramInt, String paramString1, double paramDouble, String paramString2, String paramString3) {
		super(paramInt, paramString1, paramDouble);
		setType("Fish");
		this.scaleCondition = paramString2;
		this.isFreshWater = paramString3;
	}

	public void setFresh(String paramString) {
		this.isFreshWater = paramString;
	}

	public String getFresh() {
		return this.isFreshWater;
	}

	public void setScale(String paramString) {
		this.scaleCondition = paramString;
	}

	public String getScale() {
		return this.scaleCondition;
	}
}

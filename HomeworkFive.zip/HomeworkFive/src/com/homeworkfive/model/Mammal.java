package com.homeworkfive.model;

public class Mammal extends Pet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int litterSize;
	private String haveClaws;

	public Mammal(int paramInt1, String paramString1, double paramDouble, int paramInt2, String paramString2) {
		super(paramInt1, paramString1, paramDouble);
		setType("Mammal");
		this.litterSize = paramInt2;
		this.haveClaws = paramString2;
	}

	public int getSize() {
		return this.litterSize;
	}

	public void setSize(int paramInt) {
		this.litterSize = paramInt;
	}

	public void setClaws(String paramString) {
		this.haveClaws = paramString;
	}

	public String getClaws() {
		return this.haveClaws;
	}
}
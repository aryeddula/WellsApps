package com.homeworkfive.model;

public class Reptile extends Pet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String isVenomous;
	double length;

	public Reptile(int paramInt, String paramString1, double paramDouble1, String paramString2, double paramDouble2) {
		super(paramInt, paramString1, paramDouble1);
		setType("Reptile");
		this.isVenomous = paramString2;
		this.length = paramDouble2;
	}

	public void setV(String paramString) {
		this.isVenomous = paramString;
	}

	public String getV() {
		return this.isVenomous;
	}

	public void setLength(double paramDouble) {
		this.length = paramDouble;
	}

	public double getLength() {
		return this.length;
	}
}

package com.homeworkfive.main;

/**
 * Author:
 * Date:
 * 
 * This is the PetApp class which contains the main method to display the form.
 * 
 * 
 */
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.homeworkfive.model.Fish;
import com.homeworkfive.model.Mammal;
import com.homeworkfive.model.Pet;
import com.homeworkfive.model.Reptile;

public class PetGUI extends JFrame implements ActionListener {

	/**
	 * Default version ID
	 */
	public static final long serialVersionUID = 1L;

	/**
	 * List that contains Pet data
	 */
	private List<Pet> pList = new ArrayList<Pet>();

	private int petCount = 0;
	private int curIndex = 0;

	/**
	 * Reptile Object
	 */
	private Reptile rep;

	/**
	 * Pet Object
	 */
	private Pet pet;
	/**
	 * Fish Object
	 */
	private Fish fish;

	/**
	 * Mammal Object
	 */
	private Mammal mammal;

	/**
	 * File data input and output stream objects declaration
	 */
	private ObjectInputStream inputstream;
	private ObjectOutputStream outstream;

	/**
	 * JFrame Declarations
	 */
	private JMenuItem ji;
	private JButton btnFind;
	private JButton btnNext;
	private JButton btnPrevious;
	private JPanel pnlButtonData;
	private JPanel pnlPetData;
	private JPanel pnlFishData;
	private JPanel pnlMammalData;
	private JPanel pnlReptileData;
	private JPanel pnlTopData;
	private JPanel pnlBottomData;
	private JPanel pnlFind;
	private JPanel pnlMiddle;
	private JPanel cards;
	private JLabel lblTitle;
	private JLabel lblID;
	private JLabel lblType;
	private JLabel lblName;
	private JLabel lblWeight;
	private JLabel lblClaws;
	private JLabel lblSize;
	private JLabel lblFresh;
	private JLabel lblScale;
	private JLabel lblLength;
	private JLabel lblV;
	private JTextField txtType;
	private JTextField txtID;
	private JTextField txtName;
	private JTextField txtWeight;
	private JTextField txtSize;
	private JTextField txtClaws;
	private JTextField txtLength;
	private JTextField txtV;
	private JTextField txtFresh;
	private JTextField txtScale;
	private JLabel lblFind;
	private JTextField txtFind;
	private Container content;
	private JLabel lblMsg;
	private CardLayout c1;

	/**
	 * Constants
	 */
	static final String FISHPANEL = "Fish Specific Information";
	static final String REPTILEPANEL = "Reptile Specific Information";
	static final String MAMMALPANEL = "Mammal Specific Information";

	public PetGUI() {
		setSize(1000, 300);
		initComponents();
	}

	/**
	 * JFrame Initialization
	 */
	private void initComponents() {
		pnlButtonData = new JPanel();
		pnlFind = new JPanel();

		lblFind = new JLabel("Enter Pet ID: ");
		txtFind = new JTextField(10);

		btnFind = new JButton("Find");
		btnFind.addActionListener(this);

		pnlFind.add(lblFind);
		pnlFind.add(txtFind);
		pnlFind.add(btnFind);

		btnNext = new JButton("Next");
		btnNext.addActionListener(this);
		pnlButtonData.add(btnNext);

		btnPrevious = new JButton("Previous");
		btnPrevious.addActionListener(this);
		pnlButtonData.add(btnPrevious);

		lblMsg = new JLabel();
		pnlMiddle = new JPanel();
		pnlMiddle.add(lblMsg);

		JMenuBar localJMenuBar = new JMenuBar();
		JMenu localJMenu = new JMenu("File");
		ji = new JMenuItem("Exit");
		ji.addActionListener(this);
		localJMenu.add(ji);
		localJMenuBar.add(localJMenu);
		setJMenuBar(localJMenuBar);

		content = getContentPane();
		content.setLayout(new BorderLayout());

		pnlTopData = new JPanel();
		pnlTopData.setLayout(new GridLayout(2, 1));
		lblTitle = new JLabel("PET DATA  APPLICATION ");
		lblTitle.setHorizontalAlignment(0);

		pnlTopData.add(lblTitle);
		pnlPetData = new JPanel();
		pnlPetData.setBackground(new Color(255, 255, 204));
		pnlPetData.setLayout(new GridLayout(2, 4));
		txtType = new JTextField();
		lblType = new JLabel("Pet Type");
		lblName = new JLabel("Pet Name");
		txtName = new JTextField();
		lblID = new JLabel("Pet ID");
		txtID = new JTextField();
		lblWeight = new JLabel("Pet Weight");
		txtWeight = new JTextField();

		pnlPetData.add(lblType);
		pnlPetData.add(txtType);
		pnlPetData.add(lblID);
		pnlPetData.add(txtID);
		pnlPetData.add(lblName);
		pnlPetData.add(txtName);
		pnlPetData.add(lblWeight);
		pnlPetData.add(txtWeight);
		pnlTopData.add(pnlPetData);

		content.add(pnlTopData, "North");

		cards = new JPanel(new CardLayout());

		pnlFishData = new JPanel();
		pnlFishData.setBackground(new Color(204, 204, 255));
		pnlFishData.setLayout(new GridLayout(2, 2));
		lblScale = new JLabel("What is the scale condition?");
		txtScale = new JTextField();
		lblFresh = new JLabel("Is this a fresh water fish?");
		txtFresh = new JTextField();

		pnlFishData.add(lblScale);
		pnlFishData.add(txtScale);
		pnlFishData.add(lblFresh);
		pnlFishData.add(txtFresh);

		pnlMammalData = new JPanel();
		pnlMammalData.setBackground(new Color(204, 204, 255));
		pnlMammalData.setLayout(new GridLayout(2, 2));
		lblSize = new JLabel("Litter Size");
		txtSize = new JTextField();
		lblClaws = new JLabel("Does this pet have claws?");
		txtClaws = new JTextField();

		pnlMammalData.add(lblSize);
		pnlMammalData.add(txtSize);
		pnlMammalData.add(lblClaws);
		pnlMammalData.add(txtClaws);

		pnlReptileData = new JPanel();
		pnlReptileData.setBackground(new Color(204, 204, 255));
		pnlReptileData.setLayout(new GridLayout(2, 2));
		lblV = new JLabel("Is this a venomous reptile?");
		txtV = new JTextField();
		lblLength = new JLabel("What is the length of this reptile?");
		txtLength = new JTextField();

		pnlReptileData.add(lblV);
		pnlReptileData.add(txtV);
		pnlReptileData.add(lblLength);
		pnlReptileData.add(txtLength);

		cards.add(pnlFishData, "Fish Specific Information");
		cards.add(pnlReptileData, "Reptile Specific Information");
		cards.add(pnlMammalData, "Mammal Specific Information");
		content.add(cards, "Center");

		pnlBottomData = new JPanel();
		pnlBottomData.setLayout(new BorderLayout());
		pnlButtonData.setBackground(new Color(255, 255, 204));
		lblFind.setText("Enter Pet ID:");

		pnlBottomData.add(pnlButtonData, "West");
		pnlBottomData.add(pnlFind, "East");
		pnlBottomData.add(pnlMiddle, "Center");
		content.add(pnlBottomData, "South");
		c1 = ((CardLayout) cards.getLayout());

		setDefaultCloseOperation(3);
		readData();
		/* loadData(); */
	}

	public static void main(String[] paramArrayOfString) {
		new PetGUI().setVisible(true);
	}

	/**
	 * Find the record based on the ID. Retrieve Pet object providing PetID
	 */
	public void find() {
		if (txtFind.getText().equals("")) {
			lblMsg.setText("Enter an ID here before clicking Find");
		} else {
			int i = Integer.parseInt(txtFind.getText());
			curIndex = getID(i);
			/* loadData(); */
		}
	}

	public int getID(int paramInt) {
		int i = 0;
		for (i = 0; i < pList.size(); i++) {
			if (paramInt == ((Pet) pList.get(i)).getID()) {
				return i;
			}
		}
		lblMsg.setText("Pet not found! Displaying first Pet");
		txtFind.setText("");
		return 0;
	}

	/**
	 * load data retrived by setting the record to Pet Object
	 */
	public void loadData() {
		Pet localPet = (Pet) pList.get(curIndex);
		txtType.setText(localPet.getType());
		txtID.setText(Integer.toString(localPet.getID()));
		txtName.setText(localPet.getName());
		txtWeight.setText(Double.toString(localPet.getWeight()));
		if (localPet.getType().equals("Mammal")) {
			mammal = ((Mammal) localPet);
			txtSize.setText(Integer.toString(mammal.getSize()));
			txtClaws.setText(mammal.getClaws());
			c1.show(cards, "Mammal Specific Information");
		} else if (localPet.getType().equals("Reptile")) {
			rep = ((Reptile) localPet);
			txtV.setText(rep.getV());
			txtLength.setText(Double.toString(rep.getLength()));
			c1.show(cards, "Reptile Specific Information");
		} else {
			fish = ((Fish) localPet);
			txtScale.setText(fish.getScale());
			txtFresh.setText(fish.getFresh());
			c1.show(cards, "Fish Specific Information");
		}
	}

	/**
	 * Read the Pet Object from .dat file
	 */
	public void readData() {
		try {
			/**
			 * Read the data from .dat file
			 */
			try {
				inputstream = new ObjectInputStream(
						new FileInputStream("C:\\Users\\AYEDD\\Desktop\\MIS6323Fall2017HomeworkFive\\petdata.dat"));
				System.out.println(inputstream.toString());
				while ((Pet) inputstream.readObject() != null) {
					pList.add((Pet) inputstream.readObject());
					System.out.println(pList);
					petCount += 1;
				}
			} catch (EOFException localEOFException) {
				System.out.println("Entered EOF");
			} catch (ClassNotFoundException localClassNotFoundException) {
				System.out.println("Class Error: " + localClassNotFoundException.getMessage());
			}
			System.out.println("Read " + petCount + " records");
			inputstream.close();
		} catch (FileNotFoundException localFileNotFoundException) {
			System.out.println("File Error: " + localFileNotFoundException.getMessage());
		} catch (IOException localIOException) {
			System.out.println("IO Error in read file data: " + localIOException.getMessage());
		}
		Collections.sort(pList);
	}

	/**
	 * Events Triggered when the following actions are performed
	 */
	public void actionPerformed(ActionEvent paramActionEvent) {
		String str = paramActionEvent.getActionCommand();
		if (str.equals("Next")) {
			nextPet();
		} else if (str.equals("Previous")) {
			previousPet();
		} else if (str.equals("Find")) {
			find();
		} else if (str.equals("Exit")) {
			saveData();
			System.exit(0);
		} else {
			System.out.println("error in Command Interface");
		}
	}

	/**
	 * Save record to .dat file
	 */
	public void saveData() {
		try {
			outstream = new ObjectOutputStream(
					new FileOutputStream("C:\\Users\\AYEDD\\Desktop\\MIS6323Fall2017HomeworkFive\\petdata.dat", false));
			for (Pet localPet : pList) {
				outstream.writeObject(localPet);
			}
			System.out.println("Wrote " + petCount + " records");
			outstream.flush();
			outstream.close();
		} catch (IOException localIOException) {
			System.out.println("IO Error in saveData: " + localIOException.getMessage());
		}
	}

	/**
	 * Validate the records forward
	 */
	public void nextPet() {
		lblMsg.setText("");
		if (curIndex == petCount - 1) {
			lblMsg.setText("Already at last record");
		} else {
			lblMsg.setText("");
			curIndex += 1;
			/* loadData(); */
		}
	}

	/**
	 * Validate the records Backwards
	 */
	public void previousPet() {
		lblMsg.setText("");
		if (curIndex == 0) {
			lblMsg.setText("Already at first record");
		} else {
			lblMsg.setText("");
			curIndex -= 1;
			/* loadData(); */
		}
	}
}

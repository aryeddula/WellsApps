/*
 * 
 * Monitoring Server resources using JMX
 * 
 * Changes due to architectural change in the Server Domains(WebLogic 12.2.1)
 * 
 * @Author: 
 * @Version: 1.1
 * @Created on: 5/17/2017
 */

package com.wellsfargo.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.jms.JMSException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import javax.rmi.ssl.SslRMIClientSocketFactory;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import com.wellsfargo.model.EventModel;
import com.wellsfargo.util.CryptoUtil;

@Configuration
@Service("healthCheckService")
@EnableScheduling
@PropertySource({ "classpath:server.properties", "classpath:queue.properties"})
public class HealthCheckService {

	static final Logger logger = Logger.getLogger(HealthCheckService.class);
	@Autowired
	Environment env;

	@Autowired(required = true)
	CryptoUtil cryptoUtil;

	/*
	 * * * * *************************************************** Weblogic 12.2.1
	 *******************************************************/
	/* ********* Initialize Admin Port details ************** */

	@Value("#{'${uat_admin_port}'}")
	private String uat_admin_port;

	/* ********* Initialize Admin details ************** */
	@Value("#{'${uat_admin}'}")
	private String uat_admin;

	/* ********* Initialize Managed Port details ************** */
	/*
	 * @Value("#{'${listener_managed_port}'}") private String
	 * listener_managed_port;
	 * 
	 * @Value("#{'${consumer_managed_port}'}") private String
	 * consumer_managed_port;
	 */

	@Value("#{'${manager_managed_port}'}")
	private String manager_managed_port;

	@Value("#{'${analyzer_managed_port}'}")
	private String analyzer_managed_port;

	/* ********* Initialize Managed details ************** */

	/*
	 * @Value("#{'${listener_uat_managed}'.split(',')}") private List<String>
	 * listener_uat_managed;
	 * 
	 * @Value("#{'${consumer_uat_managed}'.split(',')}") private List<String>
	 * consumer_uat_managed;
	 */

	@Value("#{'${manager_uat_managed}'.split(',')}")
	private List<String> manager_uat_managed;

	@Value("#{'${analyzer_uat_managed}'.split(',')}")
	private List<String> analyzer_uat_managed;

	/*
	 * * * * *************************************************** Weblogic 12.1.3
	 *******************************************************/
	/* ********* Initialize Listener details ************** */

	@Value("#{'${listener_admin_port}'}")
	private String listener_admin_port;

	@Value("#{'${listener_managed_port}'}")
	private String listener_managed_port;

	@Value("#{'${listener_uat_admin}'}")
	private String listener_uat_admin;

	@Value("#{'${listener_uat_managed}'.split(',')}")
	private List<String> listener_uat_managed;

	/* ********* Initialize Consumer details ************** */

	@Value("#{'${consumer_admin_port}'}")
	private String consumer_admin_port;

	@Value("#{'${consumer_managed_port}'}")
	private String consumer_managed_port;

	@Value("#{'${consumer_uat_admin}'}")
	private String consumer_uat_admin;

	@Value("#{'${consumer_uat_managed}'.split(',')}")
	private List<String> consumer_uat_managed;

	/* *************data Variables for credentials********************** */
	private static String uatSecurityCredentials_enc;

	private static String uatSecurityCredentials;

	@PostConstruct
	public void init() {
		logger.info("init : start");
		try {
			uatSecurityCredentials_enc = env.getProperty("uat.security.credentials");
			uatSecurityCredentials = cryptoUtil.decrypt(uatSecurityCredentials_enc);
			logger.info("uatSecurityCredentials :" + uatSecurityCredentials);

		} catch (Exception e) {
			logger.info("Exception in init method" + ExceptionUtils.getFullStackTrace(e));
			e.printStackTrace();
		}
		logger.info("init : end");
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	public synchronized Map<String, Map<String, List<EventModel>>> getHealthCheckStatusInfo(String env)
			throws JMSException {
		logger.info("Method get invoked every 5 minutes");
		logger.info("getHealthCheckStatusInfo : start");
		Map<String, Map<String, List<EventModel>>> healthCheckDetails = new HashMap<String, Map<String, List<EventModel>>>();
		Map<String, List<EventModel>> envDetails = new HashMap<String, List<EventModel>>();
		@SuppressWarnings("unused")
		String flag = null;
		List<EventModel> envELDetails = new ArrayList<EventModel>();
		List<EventModel> envECDetails = new ArrayList<EventModel>();
		List<EventModel> envEMDetails = new ArrayList<EventModel>();
		List<EventModel> envEADetails = new ArrayList<EventModel>();
		if (env.equalsIgnoreCase("uat")) {
			getServerHealthState(listener_uat_admin, listener_admin_port, listener_managed_port, uatSecurityCredentials,
					envELDetails, flag = "X");
			// Refresh flag
			flag = null;

			getServerHealthState(consumer_uat_admin, consumer_admin_port, consumer_managed_port, uatSecurityCredentials,
					envECDetails, flag = "X");

			// Refresh flag
			flag = null;

			getServerHealthState(uat_admin, uat_admin_port, manager_managed_port, uatSecurityCredentials, envEMDetails,
					flag = "Y");

			// Refresh flag
			flag = null;

			getServerHealthState(uat_admin, uat_admin_port, analyzer_managed_port, uatSecurityCredentials, envEADetails,
					flag = "Z");
			// Refresh flag
			flag = null;
			envDetails.put("el", envELDetails);
			envDetails.put("ec", envECDetails);
			envDetails.put("em", envEMDetails);
			envDetails.put("ea", envEADetails);
			healthCheckDetails.put("env", envDetails);
		}else{
			logger.info("BCP/PROD Under maintenance:");
		}
		logger.info("getHealthCheckStatusInfo : end");
		return healthCheckDetails;
	}

	private synchronized void getServerHealthState(String adminServer, String adminPort, String managedPort,
			String securityCredentials, List<EventModel> emList, String flag) {
		logger.info("getServerHealthState : start");
		int portValue = Integer.valueOf(adminPort).intValue();
		Hashtable<String, Object> wlsEnvParamHashTbl = new Hashtable<String, Object>();

		wlsEnvParamHashTbl.put(Context.SECURITY_PRINCIPAL, env.getProperty("security.principal"));
		wlsEnvParamHashTbl.put(Context.SECURITY_CREDENTIALS, uatSecurityCredentials);

		wlsEnvParamHashTbl.put("com.sun.jndi.rmi.factory.socket", new SslRMIClientSocketFactory());
		wlsEnvParamHashTbl.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
		logger.info("" + wlsEnvParamHashTbl);
		try {

			JMXServiceURL serviceURL = new JMXServiceURL("service:jmx:t3s://" + adminServer + ":" + portValue
					+ "/jndi/weblogic.management.mbeanservers.domainruntime");
			JMXConnector connector = JMXConnectorFactory.connect(serviceURL, wlsEnvParamHashTbl);
			logger.info("connector" + connector);
			MBeanServerConnection connection = connector.getMBeanServerConnection();
			logger.info("connection :" + connection);
			ObjectName service = new ObjectName(
					"com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
			ObjectName arr[] = (ObjectName[]) connection.getAttribute(service, "ServerRuntimes");
			for (ObjectName temp : arr)
				System.out.println("nt servers: " + temp);
			ObjectName domain = (ObjectName) connection.getAttribute(service, "DomainConfiguration");
			logger.info("domain: " + domain);
			ObjectName[] servers = (ObjectName[]) connection.getAttribute(domain, "Servers");

			for (ObjectName server : servers) {
				EventModel em = new EventModel();
				String aName = (String) connection.getAttribute(server, "Name");
				if ((aName.equals("consumer_wuvra87a0419_9200") && flag.equals("X"))
						|| (aName.equals("consumer_wuvra88a0419_9200") && flag.equals("X"))
						|| (aName.equals("consumer_wuvra89a0419_9200") && flag.equals("X"))
						|| (aName.equals("consumer_wuvra90a0419_9200") && flag.equals("X"))
						|| (aName.equals("listener_wuvra92a0419_9000") && flag.equals("X"))
						|| (aName.equals("listener_wuvra93a0419_9000") && flag.equals("X"))
						|| (aName.equals("eventman_wuvra98a0618_9100") && flag.equals("Y"))
						|| (aName.equals("analyzer_wuvra95a0618_9300") && flag.equals("Z"))
						|| (aName.equals("analyzer_wuvra96a0618_9300") && flag.equals("Z"))
						|| (aName.equals("analyzer_wuvra97a0618_9300") && flag.equals("Z"))
						|| (aName.equals("admin_wuvra91a0419_9003")) || (aName.equals("admin_wuvra91a0419_9203"))
						|| (aName.equals("admin_wuvra99a0618_9000"))) {

					try {
						ObjectName ser = new ObjectName(
								"com.bea:Name=" + aName + ",Location=" + aName + ",Type=ServerRuntime");
						String serverState = (String) connection.getAttribute(ser, "State");
						logger.info("Server: " + aName + "State: " + serverState);
						weblogic.health.HealthState serverHealthState = (weblogic.health.HealthState) connection
								.getAttribute(ser, "HealthState");
						int hState = serverHealthState.getState();

						if (hState == weblogic.health.HealthState.HEALTH_OK) {
							logger.info("Server: " + aName + "State Health: HEALTH_OK");
							em.setServer(aName);
							em.setStatus("OK");
						}
						if (hState == weblogic.health.HealthState.HEALTH_WARN) {
							logger.info("Server: " + aName + "State Health: HEALTH_WARN");
							em.setServer(aName);
							em.setStatus("WARNING");
						}
						if (hState == weblogic.health.HealthState.HEALTH_CRITICAL) {
							logger.info("Server: " + aName + "State Health: HEALTH_CRITICAL");
							System.out.println("Server: " + aName + "State Health: HEALTH_CRITICAL");
							em.setServer(aName);
							em.setStatus("CRITICAL");
						}
						if (hState == weblogic.health.HealthState.HEALTH_FAILED) {
							logger.info("Server: " + aName + "State Health: HEALTH_FAILED");
							em.setServer(aName);
							em.setStatus("FAILED");
						}
						if (hState == weblogic.health.HealthState.HEALTH_OVERLOADED) {
							logger.info("Server: " + aName + "State Health: HEALTH_OVERLOADED");
							em.setServer(aName);
							em.setStatus("FAILED");
						}
					} catch (javax.management.InstanceNotFoundException e) {
						logger.info("Server: " + aName + "State: SHUTDOWN ");
						em.setServer(aName);
						em.setStatus("SHUTDOWN");
					}
					String formattedServerName = StringUtils.substringBetween(aName, "_") + ".wellsfargo.com";
					logger.info("Formatted server name: " + formattedServerName);
					if (!formattedServerName.equals("wuvra99a0618.wellsfargo.com")
							&& !formattedServerName.equals("wuvra91a0419.wellsfargo.com")
							&& !formattedServerName.equals("wuvra92a0419.wellsfargo.com")
							&& !formattedServerName.equals("wuvra93a0419.wellsfargo.com ")
							&& !formattedServerName.equals("wuvra98a0618.wellsfargo.com")) {

						if ((em.getStatus()).equals("OK")) {
							getQueueSizeDetails(formattedServerName, managedPort, securityCredentials, em);
						}
					}
					emList.add(em);
				}

				/*
				 * // Refresh flag flag = null;
				 */
			}
		} catch (Exception e) {
			logger.info("exception in getServerHealthState :" + ExceptionUtils.getFullStackTrace(e));

		}
		logger.info("getServerHealthState : end");
	}

	private synchronized void getQueueSizeDetails(String managedServer, String managedPort, String securityCredentials,
			EventModel evm) throws IOException {
		logger.info("getQueueSizeDetails : start");
		JMXConnector jmxCon = null;
		logger.info("Managed Server ::" + managedServer);
		try {
			JMXServiceURL serviceUrl = new JMXServiceURL("service:jmx:t3s://" + managedServer + ":" + managedPort
					+ "/jndi/weblogic.management.mbeanservers.runtime");
			logger.info("Connecting to Service URL: " + serviceUrl);

			Hashtable<String, Object> wlsEnvParamHashTbl = new Hashtable<String, Object>();
			wlsEnvParamHashTbl.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
			wlsEnvParamHashTbl.put(javax.naming.Context.SECURITY_PRINCIPAL, env.getProperty("security.principal"));
			wlsEnvParamHashTbl.put(javax.naming.Context.SECURITY_CREDENTIALS, uatSecurityCredentials);
			wlsEnvParamHashTbl.put("com.sun.jndi.rmi.factory.socket", new SslRMIClientSocketFactory());
			jmxCon = JMXConnectorFactory.newJMXConnector(serviceUrl, wlsEnvParamHashTbl);
			logger.info("jmxCon :" + jmxCon);
			jmxCon.connect();

			MBeanServerConnection connection = jmxCon.getMBeanServerConnection();
			ObjectName service = new ObjectName(
					"com.bea:Name=RuntimeService,Type=weblogic.management.mbeanservers.runtime.RuntimeServiceMBean");
			ObjectName serverRuntimeMBean = (ObjectName) connection.getAttribute(service, "ServerRuntime");
		/*	String serverName = (String) connection.getAttribute(serverRuntimeMBean, "Name");*/

			ObjectName jmsRuntimeMbean = (ObjectName) connection.getAttribute(serverRuntimeMBean, "JMSRuntime");

			ObjectName[] jmsServerRuntimeMbeans = (ObjectName[]) connection.getAttribute(jmsRuntimeMbean, "JMSServers");

			for (ObjectName jmsServerRuntime : jmsServerRuntimeMbeans) {
				/*String jmsServerName = (String) connection.getAttribute(jmsServerRuntime, "Name");*/

				ObjectName[] jmsDestinationRuntimeMbeans = (ObjectName[]) connection.getAttribute(jmsServerRuntime,
						"Destinations");
				for (ObjectName jmsDestinationRuntime : jmsDestinationRuntimeMbeans) {
					String destinationName = (String) connection.getAttribute(jmsDestinationRuntime, "Name");

					if (destinationName.split("@").length == 2) {
						destinationName = destinationName.split("@")[1];
					}
					if (destinationName.split("!").length == 2) {
						destinationName = destinationName.split("!")[1];
					}

					logger.info("Destinations :" + destinationName);
					long messagesCurrentCount = (Long) connection.getAttribute(jmsDestinationRuntime,
							"MessagesCurrentCount");
					logger.info("messagesCurrentCount " + messagesCurrentCount);
					evm.setMessagesCurrentCount(Long.toString(messagesCurrentCount));

					long messagesPendingCount = (Long) connection.getAttribute(jmsDestinationRuntime,
							"MessagesPendingCount");
					logger.info("messagesPendingCount " + messagesPendingCount);
					evm.setMessagesPendingCount(Long.toString(messagesPendingCount));

					long messagesReceivedCount = (Long) connection.getAttribute(jmsDestinationRuntime,
							"MessagesReceivedCount");
					logger.info("messagesReceivedCount " + messagesReceivedCount);
					evm.setMessagesReceivedCount(Long.toString(messagesReceivedCount));

					long messagesHighCount = (Long) connection.getAttribute(jmsDestinationRuntime, "MessagesHighCount");
					logger.info("messagesHighCount " + messagesHighCount);
					evm.setMessagesHighCount(Long.toString(messagesHighCount));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("exception in getQueueSizeDetails :" + ExceptionUtils.getFullStackTrace(e));
		} finally {
			if (jmxCon != null)
				jmxCon.close();
		}
		logger.info("getQueueSizeDetails : end");
	}

	@PreDestroy
	public void preDestroy() {

	}

}

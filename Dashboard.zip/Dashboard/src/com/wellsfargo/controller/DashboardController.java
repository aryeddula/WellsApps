package com.wellsfargo.controller;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.wellsfargo.model.HealthCheckResponse;
import com.wellsfargo.service.HealthCheckService;


@RestController
@Scope("prototype")
public class DashboardController {

	 static final Logger logger = Logger.getLogger(DashboardController.class);
	@Autowired(required = true)
    private HealthCheckService healthCheckService;

	@Autowired(required = true)
	private HealthCheckResponse healthCheckResponse;

	@ResponseBody
	@RequestMapping(value="/getHealthCheckResults", method = RequestMethod.POST,headers="Accept=application/json")
	public String getHealthCheckResults(@RequestBody String env) {
		logger.info("getHealthCheckResults : start");
		try{
			logger.info("Controller invoked");
			healthCheckResponse.setStatusCode("200");
			healthCheckResponse.setStatusText("success");
			healthCheckResponse.setResult(healthCheckService.getHealthCheckStatusInfo(env));
		}catch(Exception ex){
			healthCheckResponse.setStatusCode("204");
			healthCheckResponse.setStatusText("error");
			healthCheckResponse.setReason(ex.getMessage());
			logger.info("Exception in getHealth check results"+ExceptionUtils.getFullStackTrace(ex));
		}
		logger.info("healthCheckDetails"+new Gson().toJson(healthCheckResponse));
		logger.info("getHealthCheckResults : end");
		return new Gson().toJson(healthCheckResponse);
	}

}

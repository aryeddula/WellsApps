package com.wellsfargo.model;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonView;

@Component
@Scope(value = "prototype")
public class HealthCheckResponse {
	
	@JsonView
	String statusCode;
	
	@JsonView
	String statusText;
	
	@JsonView
	String reason;
	
	@JsonView
	Map<String,Map<String,List<EventModel>>> result;
	
	
	public String getStatusCode() {
		return statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Map<String,Map<String,List<EventModel>>> getResult() {
		return result;
	}

	public void setResult(
			Map<String,Map<String,List<EventModel>>> result) {
		this.result = result;
	}

	
}

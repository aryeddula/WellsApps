package com.wellsfargo.model;

public class EventModel {
	
	private String server;
	private String status;
	private String messagesCurrentCount;
	private String messagesPendingCount;
	private String messagesReceivedCount;
	private String messagesHighCount;
	
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessagesCurrentCount() {
		return messagesCurrentCount;
	}
	public void setMessagesCurrentCount(String messagesCurrentCount) {
		this.messagesCurrentCount = messagesCurrentCount;
	}
	public String getMessagesPendingCount() {
		return messagesPendingCount;
	}
	public void setMessagesPendingCount(String messagesPendingCount) {
		this.messagesPendingCount = messagesPendingCount;
	}
	public String getMessagesReceivedCount() {
		return messagesReceivedCount;
	}
	public void setMessagesReceivedCount(String messagesReceivedCount) {
		this.messagesReceivedCount = messagesReceivedCount;
	}
	public String getMessagesHighCount() {
		return messagesHighCount;
	}
	public void setMessagesHighCount(String messagesHighCount) {
		this.messagesHighCount = messagesHighCount;
	}
	
}

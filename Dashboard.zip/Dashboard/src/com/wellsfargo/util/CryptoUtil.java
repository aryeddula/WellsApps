package com.wellsfargo.util;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStore.SecretKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


import sun.misc.BASE64Decoder;

/*@Component*/
@Configuration
/*@PropertySource({ "classpath:queue.properties"})*/
public class CryptoUtil {
	private static final String PROP_KEYSTORE_PATH = "waf.crypto.keystorePath";
	private static final String PROP_KEY_ALIAS = "waf.crypto.keyAlias";
/*	private static final String PROP_KEYSTORE_PASSWORD = "waf.crypto.keystorePassword";*/
	private static final String KEYSTORE_TYPE = "JCEKS";
	private static final String KEYSTORE_PASSWORD = "?kSlGgYQcx";
	private static final String ALGO = "AES";

	private static CryptoUtil mEncryptor = null;
	private KeyStore ks;
	private Cipher cipher;
	private String storePassword;

	// @Autowired(required = true)
	// static CryptoProperties cryptoProperties;

	public CryptoUtil() throws Exception {
		this(KEYSTORE_TYPE, CryptoProperties.getProperty(PROP_KEYSTORE_PATH), KEYSTORE_PASSWORD/*System.getProperty(PROP_KEYSTORE_PASSWORD)*/);
	}

	public CryptoUtil(final String typeKeyStore, final String pathToKeyStore, final String storePassword)
			throws Exception {
		this.storePassword = storePassword;

		ks = KeyStore.getInstance(typeKeyStore);
		InputStream keyStore = this.getClass().getClassLoader()
                .getResourceAsStream(pathToKeyStore);
		ks.load(keyStore, storePassword.toCharArray());

		cipher = Cipher.getInstance(ALGO);
	}

	public static CryptoUtil getInstance(final String typeKeyStore, final String pathToKeyStore,
			final String storePassword) throws Exception {
		if (mEncryptor == null) {
			mEncryptor = new CryptoUtil(typeKeyStore, pathToKeyStore, storePassword);
		}

		return mEncryptor;
	}

	public static CryptoUtil getInstance() throws Exception {
		if (mEncryptor == null) {
			mEncryptor = new CryptoUtil();
		}

		return mEncryptor;
	}

	private SecretKey getSecretKey(final String keyAlias, final String aliasPassword) throws KeyStoreException,
			IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableEntryException {

		SecretKeyEntry entry = (SecretKeyEntry) ks.getEntry(keyAlias,
				new KeyStore.PasswordProtection(aliasPassword.toCharArray()));
		return entry.getSecretKey();
	}

	public String decrypt(final String keyAlias, final String encrypted) throws Exception {
		return this.decrypt(keyAlias, storePassword, encrypted);
	}

	public String decrypt(final String encrypted) throws Exception {
		String keyAlias = CryptoProperties.getProperty(PROP_KEY_ALIAS);
		return this.decrypt(keyAlias, encrypted);
	}

	public synchronized String decrypt(final String keyAlias, final String aliasPassword, final String encrypted)
			throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, KeyStoreException,
			CertificateException, NoSuchAlgorithmException, UnrecoverableEntryException, IOException {
		// Switch the cipher to decryption
		cipher.init(Cipher.DECRYPT_MODE, getSecretKey(keyAlias, aliasPassword));

		byte[] decodedValue = new BASE64Decoder().decodeBuffer(encrypted);

		// Decrypt the text
		cipher.doFinal(decodedValue);

		String decrypted = new String(cipher.doFinal(decodedValue));

		return decrypted;
	}
}
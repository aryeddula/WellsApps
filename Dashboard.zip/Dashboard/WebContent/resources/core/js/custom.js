var app = angular.module('dashboardApp', []);

app.controller("dashboardController", function($scope, $http) {
	
	$scope.doEnvSelection = function(item, event){
		$('input:radio[id=uat]').prop('checked', true);
		$('#envSelModal').modal({show:true});
        $("div").removeClass("modal-backdrop in");
        $("div").removeClass("modal-backdrop fade in");
	}
	  
    $scope.doHealthCheck = function(item, event) {
    	$scope.env = $("input[name='env']:checked").val();
    	if($scope.env == 'prod' || $scope.env == 'bcp'){
    		showAlertMessage1("Application Health Check for BCP /PROD is under maintainence");
        	$("div").removeClass("modal-backdrop in");
            $("div").removeClass("modal-backdrop fade in");
    	}else{
    	$('#envSelModal').modal('hide');
    	showSpinner();     
        var healthCheckResponse =  $http({url: "getHealthCheckResults", method: 'POST',data : $scope.env});
        healthCheckResponse.success(function(data, status, headers, config) {
        	//console.log(data.statusCode  + data.result +data.reason + data.result.env);
            $scope.response = data;    
            hideSpinner();
            if($scope.response.statusText == 'success'){
            	$('#healthCheckModal').modal({show:true});
                $("div").removeClass("modal-backdrop in");
                $("div").removeClass("modal-backdrop fade in");
            }else{
            	$scope.response = "";
            	showAlertMessage('Sorry,failed to process. Unable to fetch data from backend system.');
            	$("div").removeClass("modal-backdrop in");
                $("div").removeClass("modal-backdrop fade in");
            }
            
        });
    	}
        healthCheckResponse.error(function(data, status, headers, config) {
        	hideSpinner();
        	$scope.response = "";
        	showAlertMessage("Failed to process due to backend connection failure.");
        	$("div").removeClass("modal-backdrop in");
            $("div").removeClass("modal-backdrop fade in");
        });
    }    
} );


function showSpinner() {
	$("#modal").css("display","block");
	$("#fade").css("display","block");
}

function hideSpinner() {
	$("#modal").css("display","none");
	$("#fade").css("display","none");
}


function showAlertMessage(errMsg) {

	BootstrapDialog.show({
        type: BootstrapDialog.TYPE_DANGER,
        title: 'Error !',
        message: errMsg,
        buttons: [{ label: 'OK',
            action: function(dialogItself){
                dialogItself.close();
            }}]
	});
	
}

function showAlertMessage1(errMsg) {

	BootstrapDialog.show({
        type: BootstrapDialog.TYPE_INFO,
        title: 'Info !',
        message: errMsg,
        buttons: [{ label: 'OK',
            action: function(dialogItself){
                dialogItself.close();
            }}]
	});
	
}
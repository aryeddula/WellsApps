package com.wellsfargo.fileutil;

import java.io.File;

import org.apache.log4j.Logger;

public class FileUtil {
	private static Logger logger = Logger.getLogger(FileUtil.class);

	public void filerollup(String dirName, String rollupFolder, File filename) {
		try {
			if (filename.renameTo(new File(dirName + "/" + "rolled" + "/" + filename.getName())))
				logger.trace("File is moved successful!");

		} catch (Exception e) {
			logger.error("Error occured while moving the file:");
		}
	}
}

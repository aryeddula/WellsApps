/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.jobscheduler;

/** 
* Quartz Job
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Scanner;

import javax.jms.JMSException;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.wellsfargo.fileutil.FileUtil;
import com.wellsfargo.jms.SendMessageEA;
import com.wellsfargo.jms.exception.JMSClientException;
import com.wellsfargo.props.WAFProducerProperties;

public class QuartzJob implements Job {
	private static Logger logger = Logger.getLogger(QuartzJob.class);
	private SendMessageEA sender;
	private FileUtil fileUtil;

	public void execute(JobExecutionContext context) throws JobExecutionException {
		logger.info("Inside QuartzJob execute: ");
		FileInputStream in = null;
		Scanner sc = null;
		File[] files = null;
		String dirName = WAFProducerProperties.getProperty("input.file.url");
		logger.info("DirName is: " + dirName);
		if (dirName != null)
			files = finder(dirName);
		if (files != null)
			for (File filename : files) {

				try {
					if (filename != null)
						in = new FileInputStream(filename);
					if (in != null) {
						fileUtil = new FileUtil();
						fileUtil.filerollup(dirName, "rolled", filename);
					}
					if (in == null)
						in = retry(filename);
					else
						sc = new Scanner(in, "UTF-8");

					while (sc.hasNextLine()) {
						String line = sc.nextLine();
						sender = new SendMessageEA();
						sender.init();
						sender.send(line);
						sender.close();
					}
				} catch (JMSException | JMSClientException e) {
					logger.error("JMSException: " + e);

				} catch (FileNotFoundException e) {
					logger.error("FileNotFoundException: " + e);
				} catch (InterruptedException e) {
					logger.error("InterruptedException: " + e);
				} catch (Exception e) {
					logger.error("Exception: " + e);
				} finally {
					if (in != null)
						try {
							in.close();
						} catch (IOException e) {
							logger.error("Error while closing the InputStream: " + e);
						}
				}
			}

	}

	/**
	 * 
	 * if the file not found retries for 3 times
	 * 
	 * @param filename
	 * @return
	 * @throws Exception
	 */
	public FileInputStream retry(File filename) throws Exception {
		logger.info("Inside Retry:");
		Thread.sleep(1000);
		int count = 0;
		int maxTries = 3;
		FileInputStream in = null;
		while (in == null) {
			try {
				in = new FileInputStream(filename);
			} catch (Exception e) {
				if (++count == maxTries)
					logger.error("Retry failed:" + e);
			}
		}
		return in;
	}

	/**
	 * files finder
	 * 
	 * @param dirName
	 * @return
	 */
	public File[] finder(String dirName) {
		File dir = new File(dirName);

		return dir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String filename) {
				return filename.contains("Messages.log");
			}
		});
	}

	/**
	 * 
	 * 
	 */
	public void fileRename() {

	}
}
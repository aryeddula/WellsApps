/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.jobscheduler;

/** 
* Quartz Job
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.io.InputStream;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.DependsOn;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import static org.quartz.JobBuilder.*;
import static org.quartz.TriggerBuilder.*;
import static org.quartz.CronScheduleBuilder.*;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import com.wellsfargo.props.WAFProducerProperties;

@Singleton
@Startup
@DependsOn("WAFProducerProperties")
public class QuartzScheduler {
	private static Logger logger = Logger.getLogger(QuartzScheduler.class);
	InputStream input = null;
	private String cronJob = null;
	private Scheduler scheduler;

	@PostConstruct
	public void scheduleJobs() throws Exception {
		logger.info("Inside scheduleJobs:");
		scheduler = new StdSchedulerFactory().getScheduler();
		JobDetail job = newJob(QuartzJob.class).withIdentity("ErrorMessagesJob", "ErrorMessagesgroup").build();
		logger.info("Job Build:" + job);
		cronJob = WAFProducerProperties.getProperty("cronJob");
		if (cronJob != null && job != null) {
			Trigger trigger = newTrigger().withIdentity("ErrorMessagestrigger", "ErrorMessagesgroup")
					.withSchedule(cronSchedule(cronJob)).forJob("ErrorMessagesJob", "ErrorMessagesgroup").build();
			logger.info("Trigger Build:" + trigger);
			scheduler.start();
			logger.info("scheduler Started:" + trigger);
			scheduler.scheduleJob(job, trigger);
			logger.info("Job Scheduled Successfully:" + trigger);
		}
	}

	@PreDestroy
	public void stopJobs() {
		if (scheduler != null) {
			try {
				scheduler.shutdown(true);
			} catch (SchedulerException e) {
				logger.trace("Error creating scheduler" + ExceptionUtils.getStackTrace(e));
				logger.error("Error creating scheduler", e);
			}
		}
	}
}
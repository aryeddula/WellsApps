/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.jms;

/** 
* JMS class read and send the messages to the queue
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.ssl.SslRMIClientSocketFactory;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.jms.exception.JMSClientException;
import com.wellsfargo.props.WAFProducerProperties;

public class SendMessageEA {

	/** For logging purpose. */
	private static Logger logger = Logger.getLogger(SendMessageEA.class);

	/** Initial Context of server where MDB is deployed. */
	private static InitialContext ctx = null;

	/** Connection factory object */
	private static QueueConnectionFactory qcf = null;

	/** Connection object for establishing connection with Queue. */
	private static QueueConnection qc = null;

	/** Used for creating message and queueSender. */
	private static QueueSession qsess = null;

	/** Queue object. */
	private static Queue q = null;

	/** Queue Sender object */
	private static QueueSender qsndr = null;

	/** Text Message Object */
	private static TextMessage message = null;

	/** Connection factory JNDI name. */
	private static final String QCF_NAME = WAFProducerProperties.getProperty("waf.connection.factory.jndi");

	/** Queue JNDI name. */
	private static final String QUEUE_NAME = WAFProducerProperties.getProperty("waf.destination.jndi");

	/**
	 * Creates all the necessary objects for sending messages to a JMS queue.
	 *
	 * @param ctx
	 *            JNDI initial context
	 * @param queueName
	 *            name of queue
	 * @exception NamingException
	 *                if operation cannot be performed
	 * @exception JMSException
	 *                if JMS fails to initialize due to internal error
	 * @throws JMSClientException
	 */
	public void init() throws JMSClientException, JMSException {
		Context ctx = getInitialContext();
		try {
			qcf = (QueueConnectionFactory) ctx.lookup(QCF_NAME);
		} catch (NamingException ne) {
			logger.error("Naming exception in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(ne);
			throw exception;
		}
		try {
			qc = qcf.createQueueConnection();
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
		try {
			qsess = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
		try {
			q = (Queue) ctx.lookup(QUEUE_NAME);
		} catch (NamingException ne) {
			logger.error("Naming exception in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(ne);
			throw exception;
		}
		try {
			qsndr = qsess.createSender(q);
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
		// create TextMessage
		try {
			message = qsess.createTextMessage();
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
		qc.start();
	}

	/**
	 * Sends a message to a JMS queue.
	 *
	 * @param message
	 *            message to be sent
	 * @exception JMSException
	 *                if JMS fails to send message due to internal error
	 * @throws JMSClientException
	 */
	public void send(String messageText) throws JMSException, JMSClientException {
		try {
			message.setText(messageText);
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
		try {
			qsndr.send(message);
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;

		}
	}

	/**
	 * Closes JMS objects.
	 * 
	 * @exception JMSException
	 *                if JMS fails to close objects due to internal error
	 * @throws JMSClientException
	 */
	public void close() throws JMSException, JMSClientException {
		try {
			message = null;
			qsndr.close();
			qsndr = null;
			q = null;
			qsess.close();
			qsess = null;
			qc.close();
			qc = null;
			qcf = null;
		} catch (JMSException jmse) {
			logger.error("JMSException in SendMessageEA");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(jmse);
			throw exception;
		}
	}

	/**
	 * Initial Context
	 * 
	 * @exception NamingException
	 *                if JMS fails to load the properties
	 */
	private static Context getInitialContext() {
		Hashtable<String, Object> properties = new Hashtable<String, Object>();
		properties.put(Context.INITIAL_CONTEXT_FACTORY,
				WAFProducerProperties.getProperty("waf.initial.context.factory"));
		properties.put(Context.PROVIDER_URL, WAFProducerProperties.getProperty("waf.jndi.provider"));
		properties.put(Context.SECURITY_PRINCIPAL, WAFProducerProperties.getProperty("waf.security.principal"));
		properties.put(Context.SECURITY_CREDENTIALS, WAFProducerProperties.getProperty("waf.security.credentials"));
		properties.put("com.sun.jndi.rmi.factory.socket", new SslRMIClientSocketFactory());

		logger.trace("properties " + properties);
		try {
			ctx = new InitialContext(properties);
			logger.trace("ctx " + ctx);
		} catch (NamingException ne) {
			logger.trace("JMS exception" + ExceptionUtils.getFullStackTrace(ne));
			logger.error("JMS exception", ne);
		}
		return ctx;
	}

	/**
	 * Closes all the open senders, connections and sessions.
	 * 
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	private void destroyQueueClient() {
		try {
			if (qsndr != null) {
				qsndr.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}

		try {
			if (qsess != null) {
				qsess.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}

		try {
			if (qc != null) {
				qc.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}
	}
}

/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.jms.exception;

/**
 * Exception used for all JMS related operations.
 * @author Syntel
 * @version 1.0
 */
public class JMSClientException extends Exception {

    /**
     * Default serial version id.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor with throwable parameter.
     * @param exception
     */
    public JMSClientException(Throwable exception) {
        super(exception);
    }

    /**
     * Constructor.
     * @param message
     */
    public JMSClientException(String message) {
        super(message);
    }

    /**
     * Constructor.
     * @param message
     * @param cause
     */
    public JMSClientException(String message, Throwable cause) {
        super(message, cause);
    }

}

/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.props;

/** 
* Read properties from propety file at App startup
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.log4j.Logger;

@Singleton
@Startup
public class WAFProducerProperties {
	private static Logger logger = Logger.getLogger(WAFProducerProperties.class);
	private static Properties properties;
	private InputStream inputStream;

	@PostConstruct
	public void init() {
		logger.info("Start properties initialization:");
		inputStream = this.getClass().getClassLoader().getResourceAsStream("waf.analyzer.properties");
		logger.info("InputStream is: " + inputStream);
		properties = new Properties();

		try {
			if (inputStream != null)
				properties.load(inputStream);

			if (properties != null)
				logger.info("Properties loaded Successfully: ");
		} catch (IOException e) {
			try {
				inputStream.close();
			} catch (IOException e1) {
				logger.error("Error while closing the InputStream" + e1);
			}
			logger.error("Error while reading properties" + e);
		}
	}

	public static String getProperty(String key) {
		return properties.getProperty(key);
	}

	@PreDestroy
	public void close() {
		try {
			inputStream.close();
			properties.clear();
		} catch (IOException e) {
			logger.error("Error while closing the InputStream:" + e);
		}
	}

}

/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 

package com.wellsfargo.DAO;

*//** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*//*
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import org.apache.log4j.Logger;

import com.wellsfargo.model.WAFAlert;
import com.wellsfargo.util.EntityManagerFactoryDBProps;

@Stateless
public class WAFDAO {

	private static Logger logger = Logger.getLogger(WAFDAO.class);

	@EJB
	EntityManagerFactoryDBProps entityManagerFactoryDBProps;

	public void saveErrorMessages(List<WAFAlert> wafAlertList) throws Exception {
		logger.trace("Inside saveErrorMessages:");
		EntityManagerFactory emf = entityManagerFactoryDBProps.setDBProperties();
		if (wafAlertList.size() != 0 && emf != null) {
			EntityManager entityManager = emf.createEntityManager();
			try {
				entityManager.getTransaction().begin();
				logger.trace("Begin Transaction:");
				for (WAFAlert wafArray : wafAlertList) {
					System.out.println(wafArray);
					 entityManager.persist(wafArray); 
				}
				entityManager.getTransaction().commit();
				logger.info("Transaction commited:");
				entityManager.close();
				logger.trace("End Transaction:");
			} catch (Exception ex) {
				logger.error("Transaction Ignored:");
				if (entityManager.getTransaction() != null) {
					entityManager.flush();
					entityManager.clear();
					entityManager.close();
				}
			} finally {
				entityManager.flush();
				entityManager.clear();
				entityManager.close();
			}
		}
	}

	public List<WAFAlert> readErrorMessages(List<WAFAlert> wafAlertList) {
		logger.trace("Inside readErrorMessages:");
		List<WAFAlert> wafAlertList_val = new ArrayList<WAFAlert>();
		EntityManagerFactory emf = entityManagerFactoryDBProps.setDBProperties();
		if (wafAlertList.size() != 0 && emf != null) {
			EntityManager entityManager = emf.createEntityManager();
			try {
				entityManager.getTransaction().begin();
				logger.trace("Begin Transaction:");
				for (WAFAlert wafArray : wafAlertList) {
					
					 * Query query = entityManager
					 * .createQuery("select WAFAlert from" +
					 * WAFAlert.class.getName() + "where ALERT_ID =:AlertId")
					 * .setParameter("AlertId", wafArray.getALERT_ID());
					 * wafAlertList_val = query.getResultList();
					 
					System.out.println("Validated:" + wafArray);

				}
				entityManager.getTransaction().commit();
				entityManager.close();
				logger.trace("End Transaction:");
				System.out.println("End Transaction:");

			} catch (Exception ex) {
				logger.error("Transaction Ignored:");
				if (entityManager.getTransaction() != null) {
					entityManager.flush();
					entityManager.clear();
					entityManager.close();
				}
			} finally {
				entityManager.flush();
				entityManager.clear();
				entityManager.close();
			}

		}
		return wafAlertList_val;

	}
}
*/
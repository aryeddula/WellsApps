/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.waf.ejb.action;

import org.apache.log4j.Logger;

/**
 * @author 
 *
 */
public class FileLoggerAction implements EventActionHandlerIntf {

	private static Logger logger = Logger.getLogger("messageLogger");

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wellsfargo.waf.ejb.action.EventActionListenerIntf#execute(java.lang.
	 * String)
	 */
	@Override
	public void execute(String eventMessage) {
		// parsing the plain message
		// int ending = eventMessage.indexOf("}");
		// int delimit = eventMessage.indexOf(",");
		// String facility = eventMessage.substring(1, delimit);
		// String level = eventMessage.substring(delimit+1, ending);

		logger.log(MessageLogLevel.STORE, eventMessage);
	}

}

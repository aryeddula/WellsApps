/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.waf.ejb.action;

import org.apache.log4j.Level;

public class MessageLogLevel extends Level {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String STORE_STR = "STORE";

	/**
	 * sets the level integer to be higher than OFF level, so that the logging
	 * is always on
	 */
	public static final int STORE_INT = OFF_INT - 1;

	/**
	 * {@link Level} representing my log level
	 */
	public static final Level STORE = new MessageLogLevel(STORE_INT, STORE_STR, 7);

	protected MessageLogLevel(int arg0, String arg1, int arg2) {
		super(arg0, arg1, arg2);

	}

	public static Level toLevel(String sArg) {
		if (sArg != null && sArg.toUpperCase().equals(STORE_STR)) {
			return STORE;
		}
		return (Level) toLevel(sArg, Level.ALL);
	}

	public static Level toLevel(int val) {
		if (val == STORE_INT) {
			return STORE;
		}
		return (Level) toLevel(val, Level.ALL);
	}

	public static Level toLevel(int val, Level defaultLevel) {
		if (val == STORE_INT) {
			return STORE;
		}
		return Level.toLevel(val, defaultLevel);
	}

	public static Level toLevel(String sArg, Level defaultLevel) {
		if (sArg != null && sArg.toUpperCase().equals(STORE_STR)) {
			return STORE;
		}
		return Level.toLevel(sArg, defaultLevel);
	}
}
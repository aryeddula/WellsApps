/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.waf.ejb;

/** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.util.ArrayList;
import java.util.List;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.wellsfargo.model.WAFAlert;
import com.wellsfargo.waf.ejb.action.EventActionHandlerIntf;
import com.wellsfargo.waf.ejb.action.FileLoggerAction;

/**
 * Message-Driven Bean implementation class for: CFMLiteMDB
 *
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "connectionFactoryJndiName", propertyValue = "cf01") }, mappedName = "Queue1", name = "WAF-AnalyzerMDB")
public class WAFAnalyzerCollectorMDB implements MessageListener {

/*	@EJB
	WAFDAO wAFDAO;*/

	private static Logger logger = Logger.getLogger(WAFAnalyzerCollectorMDB.class);

/*	@EJB
	CEFLogParser cefLogParser;*/

	List<WAFAlert> wafAlertList = null;
	List<WAFAlert> wafAlertList_valid = null;

	private static ArrayList<EventActionHandlerIntf> actions = new ArrayList<EventActionHandlerIntf>();

	static {
		actions.add(new FileLoggerAction());
	}

	/**
	 * Default constructor.
	 */
	public WAFAnalyzerCollectorMDB() {

	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message message) {
		logger.trace("Inside onMessage:");
		wafAlertList = new ArrayList<WAFAlert>();
		wafAlertList_valid = new ArrayList<WAFAlert>();
		if (message instanceof TextMessage) {
			try {
				String msg = ((TextMessage) message).getText();
				logger.trace("MDB received msg: " + msg);

				for (EventActionHandlerIntf action : actions) {
					action.execute(msg);
				}
/*				if (msg != null)
					wafAlertList = cefLogParser.parse(msg);
				if (wafAlertList != null)
					wafAlertList_valid = wAFDAO.readErrorMessages(wafAlertList);
				if (wafAlertList != null && wafAlertList_valid.size() == 0)
					wAFDAO.saveErrorMessages(wafAlertList);*/
			} catch (Exception ex) {
				logger.error("Exception:" + ex);
			}

		}

	}

}
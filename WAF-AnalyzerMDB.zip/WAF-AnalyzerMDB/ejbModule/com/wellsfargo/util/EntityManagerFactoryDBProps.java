/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 
package com.wellsfargo.util;

*//** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*//*
import java.util.HashMap;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.apache.log4j.Logger;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import com.wellsfargo.props.WAFMDBProperties;

@Singleton
@Startup
@DependsOn("WAFMDBProperties")
@Stateless
public class EntityManagerFactoryDBProps {
	private static Logger logger = Logger.getLogger(WAFMDBProperties.class);
	Map<String, String> props = null;
	CustomBasicDatasource customBasicDatasource;
	static EntityManagerFactory emf = null;

	 @PostConstruct 
	public EntityManagerFactory setDBProperties() {
		logger.info("Inside Set DB Properties:");
		props = new HashMap<String, String>();
		customBasicDatasource = new CustomBasicDatasource();
		try {
			customBasicDatasource.setPassword(WAFMDBProperties.getProperty("jdbc.password"));
			props.put(PersistenceUnitProperties.JDBC_DRIVER, WAFMDBProperties.getProperty("jdbc.driverClassName"));
			props.put(PersistenceUnitProperties.JDBC_URL, WAFMDBProperties.getProperty("jdbc.databaseurl"));
			props.put(PersistenceUnitProperties.JDBC_USER, WAFMDBProperties.getProperty("jdbc.username"));
			props.put(PersistenceUnitProperties.JDBC_PASSWORD, customBasicDatasource.getPassword());
			emf = Persistence.createEntityManagerFactory("EjbComponentPU1", props);
		} catch (Exception e) {
			logger.error("Error while setting the props to the Entity Manager");
			throw e;
		}
		return emf;
	}

	
	 * public static EntityManagerFactory getemf() { return emf; }
	 

	
	 * @PreDestroy public void close() throws Exception { props.clear(); }
	 

}
*/
/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 
package com.wellsfargo.util;

*//** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*//*
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.dbcp.BasicDataSource;

public class CustomBasicDatasource extends BasicDataSource {

	public CustomBasicDatasource() {
		super();
	}

	public synchronized void setPassword(String encodedPassword) {
		this.password = decode(encodedPassword);
	}

	private String decode(String password) {
		return new String(Base64.decodeBase64(password));
	}

}
*/
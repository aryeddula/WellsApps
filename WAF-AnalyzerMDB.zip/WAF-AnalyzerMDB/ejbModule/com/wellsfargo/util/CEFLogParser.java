/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 
package com.wellsfargo.util;

*//** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*//*
import java.util.ArrayList;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import com.wellsfargo.model.TagList;
import com.wellsfargo.model.WAFAlert;

@Stateless
public class CEFLogParser {

	private static Logger logger = Logger.getLogger(CEFLogParser.class);

	private static String DATABASE_MESSAGE = "String length exceeded column limit";

	public List<WAFAlert> parse(String msg) throws Exception {
		logger.trace("ErrorMessage Parse : start");
		List<WAFAlert> wafAlertList = new ArrayList<WAFAlert>();
		String[] parts = msg.split("\\{(-?\\w+),(-?\\w+)\\}");

		for (String strg : parts) {
			String[] csTags = strg.split("cs(\\d)");
			int cstags = csTags.length / 2;
			WAFAlert wafAlert = new WAFAlert();
			String[] part = strg.split("cs\\d");
			String header = part[0];
			String[] headers = header.split("\\|");
			int counter = 0;
			String body = "";
			for (String head : headers) {
				if (counter == 0) {
					String[] logFormat = head.split(":");

					try {
						String[] format = logFormat[2].split(" ");
						wafAlert.setLOG_FORMAT((format[3].length() <= 100) ? format[3] : DATABASE_MESSAGE);
						wafAlert.setLOG_VERSION((logFormat[3].length() <= 100) ? logFormat[3] : DATABASE_MESSAGE);
					} catch (ArrayIndexOutOfBoundsException e) {
						logger.trace("MEssage without CEF version");
					}

				} else if (counter == 1) {
					wafAlert.setVENDOR((head.length() <= 100) ? head : DATABASE_MESSAGE);
				} else if (counter == 2) {
					wafAlert.setVENDOR_PRODUCT((head.length() <= 100) ? head : DATABASE_MESSAGE);
				} else if (counter == 3) {
					wafAlert.setVENDOR_PRODUCT_VERSION((head.length() <= 100) ? head : DATABASE_MESSAGE);
				} else if (counter == 4) {
					wafAlert.setALERT_TYPE((head.length() <= 500) ? head : DATABASE_MESSAGE);
				} else if (counter == 5) {
					wafAlert.setALERT_NAME((head.length() <= 100) ? head : DATABASE_MESSAGE);
				} else if (counter == 6) {
					wafAlert.setALERT_SEVERITY((head.length() <= 100) ? head : DATABASE_MESSAGE);
				} else if (counter == 7) {
					body = head;
				}
				counter++;
			}

			Pattern csPattern1 = Pattern.compile("(\\w+)=\"*((?<=\")[^\"]+(?=\")|([^\\s]+))\"*");
			Matcher csMatcher1 = csPattern1.matcher(body);
			while (csMatcher1.find()) {
				if (csMatcher1.group(1).equalsIgnoreCase(TagList.getAct())) {
					wafAlert.setALERT_ACTION(
							(csMatcher1.group(2).length() <= 500) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getDst())) {
					wafAlert.setDEST_IP((csMatcher1.group(2).length() <= 100) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getDpt())) {
					wafAlert.setDEST_PORT(
							(csMatcher1.group(2).length() <= 100) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getSrc())) {
					wafAlert.setSOURCE_IP(
							(csMatcher1.group(2).length() <= 100) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getSpt())) {
					wafAlert.setSOURCE_PORT(
							(csMatcher1.group(2).length() <= 100) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getProto())) {
					wafAlert.setSOURCE_PROTOCOL(
							(csMatcher1.group(2).length() <= 100) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getDuser())) {
					wafAlert.setALERT_USERNAME(
							(csMatcher1.group(2).length() <= 500) ? csMatcher1.group(2) : DATABASE_MESSAGE);
				} else if (csMatcher1.group(1).equalsIgnoreCase(TagList.getCat())) {
					wafAlert.setALERT_CATEGORY(
							(csMatcher1.group(2).length() <= 500) ? csMatcher1.group(2) : DATABASE_MESSAGE);

				}

			}

			Pattern pattern4 = Pattern.compile("rt=(.*?)cat");
			Matcher csMatcher4 = pattern4.matcher(body);
			while (csMatcher4.find()) {
				wafAlert.setALERT_CREATETIME(
						(csMatcher4.group(1).length() <= 100) ? csMatcher4.group(1) : DATABASE_MESSAGE);
			}

			@SuppressWarnings("unused")
			int count = 0;
			String[] bodytags = body.split("\\w=\\w");
			for (@SuppressWarnings("unused")
			String tags : bodytags) {
				count++;
			}

			for (int i = 1; i <= cstags; i++) {
				String cs = "cs" + i + "=(.*?)cs[" + i + "]";
				String csl = "cs" + i + "Label=(\\w+)";
				String csName = "";
				String csLabel = "";
				Pattern csPattern = Pattern.compile(cs);
				Pattern cslPattern = Pattern.compile(csl);

				Matcher csMatcher = csPattern.matcher(strg);
				Matcher cslMatcher = cslPattern.matcher(strg);

				if (csMatcher.find()) {
					csName = csMatcher.group(1).trim();
				}
				if (cslMatcher.find()) {
					csLabel = cslMatcher.group(1).trim();
				}
				if (csLabel.equals(TagList.getPolicy())) {
					wafAlert.setALERT_POLICY((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getServerGroup())) {
					wafAlert.setSERVERGROUP((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getServiceName())) {
					wafAlert.setSERVICENAME((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getApplicationName())) {
					wafAlert.setAPPLICATIONNAME((csName.length() <= 1000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getDescript().trim())) {
					wafAlert.setDESCRIPTION((csName.length() <= 4000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertType())) {
					wafAlert.setALERT_TYPE((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertName())) {
					wafAlert.setALERT_NAME((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertSeverity())) {
					wafAlert.setALERT_SEVERITY((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertID())) {
					wafAlert.setALERT_ID((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertFlag())) {
					wafAlert.setALERT_FLAG((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertLastUpdateTime())) {
					wafAlert.setALERT_LASTUPDATETIME((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventGateway())) {
					wafAlert.setEVENT_GATEWAY((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getViolationDescription())) {
					wafAlert.setVIOLATION_DESC((csName.length() <= 4000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getAlertOccurences())) {
					wafAlert.setALERT_OCCURANCES((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventAlertName())) {
					wafAlert.setEVENT_ALERTNAME((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventOccurences())) {
					wafAlert.setEVENT_OCCURANCES((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventSeverity())) {
					wafAlert.setEVENT_SEVERITY((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventID())) {
					wafAlert.setEVENT_ID((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventAction())) {
					wafAlert.setEVENT_ACTION((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventSimulationMode())) {
					wafAlert.setEVENT_SIM_MODE((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventResponseCode())) {
					wafAlert.setEVENT_RESPONSECODE((csName.length() <= 500) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventHTTPMethod())) {
					wafAlert.setEVENT_HTTP_METHOD((csName.length() <= 50) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventURLPath())) {
					wafAlert.setEVENT_URL_PATH((csName.length() <= 2000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventQuery())) {
					wafAlert.setEVENT_QUERY((csName.length() <= 4000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventReqHeaderName().trim())) {
					wafAlert.setEVENT_REQ_HEADER_NAME((csName.length() <= 1000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventREqHeaderValue())) {
					wafAlert.setEVENT_REQ_HEADER_VALUE((csName.length() <= 1000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventResponseSize())) {
					wafAlert.setEVENT_RESPONSESIZE((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventResponseTime())) {
					wafAlert.setEVENT_RESPONSETIME((csName.length() <= 100) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventResHeaderName().trim())) {
					wafAlert.setEVENT_RES_HEADER_NAME((csName.length() <= 1000) ? csName : DATABASE_MESSAGE);
				}
				if (csLabel.equals(TagList.getEventResHeaderValue())) {
					wafAlert.setEVENT_RES_HEADER_VALUE((csName.length() <= 1000) ? csName : DATABASE_MESSAGE);
				}
			}
			wafAlert.setLOB_SOURCE("Wholesale");
			wafAlert.setLOB_CEF_VERSION("CEFVer1.1");

			// Date date = new Date();
			wafAlert.setCREATE_DATETIME(new java.util.Date());
			 try { 
			if (!wafAlert.getLOG_FORMAT().equals(null) && !wafAlert.getLOG_FORMAT().isEmpty()
					&& wafAlert.getLOG_FORMAT().length() == 0)
				wafAlertList.add(wafAlert);
			else
				logger.trace("Got dummy message so ignored: " + msg);
			
			 * } catch (Exception e) {
			 * logger.trace("Got dummy message so ignored: " + msg); }
			 
		}
		return wafAlertList;
	}

}
*/
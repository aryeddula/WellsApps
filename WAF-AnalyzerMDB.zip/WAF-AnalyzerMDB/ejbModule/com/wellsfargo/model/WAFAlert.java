/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.model;

/** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "WAF_SSA.WAF_ALERT")
public class WAFAlert implements Serializable {

	/**
	 * Generated Vesion Id
	 */
	private static final long serialVersionUID = 582449944110150292L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "waf_alert_sequence")
	@SequenceGenerator(name = "waf_alert_sequence", sequenceName = "WAF_SSA.WAF_ALERT_SEQ", allocationSize = 20)
	private String ID;

	@Column(name = "ALERT_ID", nullable = false)
	private String ALERT_ID;

	@Column(name = "ALERT_NAME", nullable = false)
	private String ALERT_NAME;

	@Column(name = "ALERT_TYPE", nullable = false)
	private String ALERT_TYPE;

	@Column(name = "ALERT_SEVERITY", nullable = false)
	private String ALERT_SEVERITY;

	@Column(name = "ALERT_FLAG")
	private String ALERT_FLAG;

	@Column(name = "ALERT_ACTION")
	private String ALERT_ACTION;

	@Column(name = "ALERT_CREATETIME")
	private String ALERT_CREATETIME;

	@Column(name = "SOURCE_IP")
	private String SOURCE_IP;

	@Column(name = "SOURCE_PORT")
	private String SOURCE_PORT;

	@Column(name = "SOURCE_PROTOCOL")
	private String SOURCE_PROTOCOL;

	@Column(name = "DEST_IP")
	private String DEST_IP;

	@Column(name = "DEST_PORT")
	private String DEST_PORT;

	@Column(name = "ALERT_CATEGORY")
	private String ALERT_CATEGORY;

	@Column(name = "ALERT_POLICY")
	private String ALERT_POLICY;

	@Column(name = "APPLICATIONNAME", nullable = false)
	private String APPLICATIONNAME;

	@Column(name = "SERVERGROUP")
	private String SERVERGROUP;

	@Column(name = "SERVICENAME")
	private String SERVICENAME;

	@Column(name = "DESCRIPTION")
	private String DESCRIPTION;

	@Column(name = "ALERT_LASTUPDATETIME")
	private String ALERT_LASTUPDATETIME;

	@Column(name = "EVENT_GATEWAY")
	private String EVENT_GATEWAY;

	@Column(name = "VIOLATION_DESC")
	private String VIOLATION_DESC;

	@Column(name = "ALERT_OCCURANCES", nullable = false)
	private String ALERT_OCCURANCES;

	@Column(name = "EVENT_ALERTNAME")
	private String EVENT_ALERTNAME;

	@Column(name = "EVENT_OCCURANCES")
	private String EVENT_OCCURANCES;

	@Column(name = "EVENT_SEVERITY")
	private String EVENT_SEVERITY;

	@Column(name = "EVENT_ID")
	private String EVENT_ID;

	@Column(name = "EVENT_ACTION")
	private String EVENT_ACTION;

	@Column(name = "EVENT_SIM_MODE")
	private String EVENT_SIM_MODE;

	@Column(name = "EVENT_RESPONSECODE")
	private String EVENT_RESPONSECODE;

	@Column(name = "EVENT_HTTP_METHOD")
	private String EVENT_HTTP_METHOD;

	@Column(name = "EVENT_URL_PATH")
	private String EVENT_URL_PATH;

	@Column(name = "EVENT_QUERY")
	private String EVENT_QUERY;

	@Column(name = "EVENT_RESPONSESIZE")
	private String EVENT_RESPONSESIZE;

	@Column(name = "EVENT_RESPONSETIME")
	private String EVENT_RESPONSETIME;

	@Column(name = "LOG_FORMAT")
	private String LOG_FORMAT;

	@Column(name = "LOG_VERSION")
	private String LOG_VERSION;

	@Column(name = "VENDOR")
	private String VENDOR;

	@Column(name = "VENDOR_PRODUCT")
	private String VENDOR_PRODUCT;

	@Column(name = "VENDOR_PRODUCT_VERSION")
	private String VENDOR_PRODUCT_VERSION;

	@Column(name = "LOB_SOURCE")
	private String LOB_SOURCE;

	@Column(name = "LOB_CEF_VERSION")
	private String LOB_CEF_VERSION;

	@Column(name = "EVENT_REQ_HEADER_NAME")
	private String EVENT_REQ_HEADER_NAME;

	@Column(name = "EVENT_REQ_HEADER_VALUE")
	private String EVENT_REQ_HEADER_VALUE;

	@Column(name = "EVENT_RES_HEADER_NAME")
	private String EVENT_RES_HEADER_NAME;

	@Column(name = "EVENT_RES_HEADER_VALUE")
	private String EVENT_RES_HEADER_VALUE;

	@Column(name = "ALERT_USERNAME")
	private String ALERT_USERNAME;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATETIME")
	private Date CREATE_DATETIME;

	public Date getCREATE_DATETIME() {
		return CREATE_DATETIME;
	}

	public void setCREATE_DATETIME(Date cREATE_DATETIME) {
		CREATE_DATETIME = cREATE_DATETIME;
	}

	public String getEVENT_REQ_HEADER_NAME() {
		return EVENT_REQ_HEADER_NAME;
	}

	public void setEVENT_REQ_HEADER_NAME(String eVENT_REQ_HEADER_NAME) {
		EVENT_REQ_HEADER_NAME = eVENT_REQ_HEADER_NAME;
	}

	public String getALERT_USERNAME() {
		return ALERT_USERNAME;
	}

	public void setALERT_USERNAME(String aLERT_USERNAME) {
		ALERT_USERNAME = aLERT_USERNAME;
	}

	public String getEVENT_REQ_HEADER_VALUE() {
		return EVENT_REQ_HEADER_VALUE;
	}

	public void setEVENT_REQ_HEADER_VALUE(String eVENT_REQ_HEADER_VALUE) {
		EVENT_REQ_HEADER_VALUE = eVENT_REQ_HEADER_VALUE;
	}

	public String getEVENT_RES_HEADER_NAME() {
		return EVENT_RES_HEADER_NAME;
	}

	public void setEVENT_RES_HEADER_NAME(String eVENT_RES_HEADER_NAME) {
		EVENT_RES_HEADER_NAME = eVENT_RES_HEADER_NAME;
	}

	public String getEVENT_RES_HEADER_VALUE() {
		return EVENT_RES_HEADER_VALUE;
	}

	public void setEVENT_RES_HEADER_VALUE(String eVENT_RES_HEADER_VALUE) {
		EVENT_RES_HEADER_VALUE = eVENT_RES_HEADER_VALUE;
	}

	public String getALERT_ID() {
		return ALERT_ID;
	}

	public void setALERT_ID(String aLERT_ID) {
		ALERT_ID = aLERT_ID;
	}

	public String getALERT_NAME() {
		return ALERT_NAME;
	}

	public void setALERT_NAME(String aLERT_NAME) {
		ALERT_NAME = aLERT_NAME;
	}

	public String getALERT_TYPE() {
		return ALERT_TYPE;
	}

	public void setALERT_TYPE(String aLERT_TYPE) {
		ALERT_TYPE = aLERT_TYPE;
	}

	public String getALERT_SEVERITY() {
		return ALERT_SEVERITY;
	}

	public void setALERT_SEVERITY(String aLERT_SEVERITY) {
		ALERT_SEVERITY = aLERT_SEVERITY;
	}

	public String getALERT_FLAG() {
		return ALERT_FLAG;
	}

	public void setALERT_FLAG(String aLERT_FLAG) {
		ALERT_FLAG = aLERT_FLAG;
	}

	public String getALERT_ACTION() {
		return ALERT_ACTION;
	}

	public void setALERT_ACTION(String aLERT_ACTION) {
		ALERT_ACTION = aLERT_ACTION;
	}

	public String getSOURCE_IP() {
		return SOURCE_IP;
	}

	public void setSOURCE_IP(String sOURCE_IP) {
		SOURCE_IP = sOURCE_IP;
	}

	public String getSOURCE_PORT() {
		return SOURCE_PORT;
	}

	public void setSOURCE_PORT(String sOURCE_PORT) {
		SOURCE_PORT = sOURCE_PORT;
	}

	public String getSOURCE_PROTOCOL() {
		return SOURCE_PROTOCOL;
	}

	public void setSOURCE_PROTOCOL(String sOURCE_PROTOCOL) {
		SOURCE_PROTOCOL = sOURCE_PROTOCOL;
	}

	public String getDEST_IP() {
		return DEST_IP;
	}

	public void setDEST_IP(String dEST_IP) {
		DEST_IP = dEST_IP;
	}

	public String getDEST_PORT() {
		return DEST_PORT;
	}

	public void setDEST_PORT(String dEST_PORT) {
		DEST_PORT = dEST_PORT;
	}

	public String getALERT_CATEGORY() {
		return ALERT_CATEGORY;
	}

	public void setALERT_CATEGORY(String aLERT_CATEGORY) {
		ALERT_CATEGORY = aLERT_CATEGORY;
	}

	public String getALERT_POLICY() {
		return ALERT_POLICY;
	}

	public void setALERT_POLICY(String aLERT_POLICY) {
		ALERT_POLICY = aLERT_POLICY;
	}

	public String getAPPLICATIONNAME() {
		return APPLICATIONNAME;
	}

	public void setAPPLICATIONNAME(String aPPLICATIONNAME) {
		APPLICATIONNAME = aPPLICATIONNAME;
	}

	public String getSERVERGROUP() {
		return SERVERGROUP;
	}

	public void setSERVERGROUP(String sERVERGROUP) {
		SERVERGROUP = sERVERGROUP;
	}

	public String getSERVICENAME() {
		return SERVICENAME;
	}

	public void setSERVICENAME(String sERVICENAME) {
		SERVICENAME = sERVICENAME;
	}

	public String getDESCRIPTION() {
		return DESCRIPTION;
	}

	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}

	public String getALERT_CREATETIME() {
		return ALERT_CREATETIME;
	}

	public void setALERT_CREATETIME(String aLERT_CREATETIME) {
		ALERT_CREATETIME = aLERT_CREATETIME;
	}

	public String getALERT_LASTUPDATETIME() {
		return ALERT_LASTUPDATETIME;
	}

	public void setALERT_LASTUPDATETIME(String aLERT_LASTUPDATETIME) {
		ALERT_LASTUPDATETIME = aLERT_LASTUPDATETIME;
	}

	public String getEVENT_GATEWAY() {
		return EVENT_GATEWAY;
	}

	public void setEVENT_GATEWAY(String eVENT_GATEWAY) {
		EVENT_GATEWAY = eVENT_GATEWAY;
	}

	public String getVIOLATION_DESC() {
		return VIOLATION_DESC;
	}

	public void setVIOLATION_DESC(String vIOLATION_DESC) {
		VIOLATION_DESC = vIOLATION_DESC;
	}

	public String getALERT_OCCURANCES() {
		return ALERT_OCCURANCES;
	}

	public void setALERT_OCCURANCES(String aLERT_OCCURANCES) {
		ALERT_OCCURANCES = aLERT_OCCURANCES;
	}

	public String getEVENT_ALERTNAME() {
		return EVENT_ALERTNAME;
	}

	public void setEVENT_ALERTNAME(String eVENT_ALERTNAME) {
		EVENT_ALERTNAME = eVENT_ALERTNAME;
	}

	public String getEVENT_OCCURANCES() {
		return EVENT_OCCURANCES;
	}

	public void setEVENT_OCCURANCES(String eVENT_OCCURANCES) {
		EVENT_OCCURANCES = eVENT_OCCURANCES;
	}

	public String getEVENT_SEVERITY() {
		return EVENT_SEVERITY;
	}

	public void setEVENT_SEVERITY(String eVENT_SEVERITY) {
		EVENT_SEVERITY = eVENT_SEVERITY;
	}

	public String getEVENT_ID() {
		return EVENT_ID;
	}

	public void setEVENT_ID(String eVENT_ID) {
		EVENT_ID = eVENT_ID;
	}

	public String getEVENT_ACTION() {
		return EVENT_ACTION;
	}

	public void setEVENT_ACTION(String eVENT_ACTION) {
		EVENT_ACTION = eVENT_ACTION;
	}

	public String getEVENT_SIM_MODE() {
		return EVENT_SIM_MODE;
	}

	public void setEVENT_SIM_MODE(String eVENT_SIM_MODE) {
		EVENT_SIM_MODE = eVENT_SIM_MODE;
	}

	public String getEVENT_RESPONSECODE() {
		return EVENT_RESPONSECODE;
	}

	public void setEVENT_RESPONSECODE(String eVENT_RESPONSECODE) {
		EVENT_RESPONSECODE = eVENT_RESPONSECODE;
	}

	public String getEVENT_HTTP_METHOD() {
		return EVENT_HTTP_METHOD;
	}

	public void setEVENT_HTTP_METHOD(String eVENT_HTTP_METHOD) {
		EVENT_HTTP_METHOD = eVENT_HTTP_METHOD;
	}

	public String getEVENT_URL_PATH() {
		return EVENT_URL_PATH;
	}

	public void setEVENT_URL_PATH(String eVENT_URL_PATH) {
		EVENT_URL_PATH = eVENT_URL_PATH;
	}

	public String getEVENT_QUERY() {
		return EVENT_QUERY;
	}

	public void setEVENT_QUERY(String eVENT_QUERY) {
		EVENT_QUERY = eVENT_QUERY;
	}

	public String getEVENT_RESPONSESIZE() {
		return EVENT_RESPONSESIZE;
	}

	public void setEVENT_RESPONSESIZE(String eVENT_RESPONSESIZE) {
		EVENT_RESPONSESIZE = eVENT_RESPONSESIZE;
	}

	public String getEVENT_RESPONSETIME() {
		return EVENT_RESPONSETIME;
	}

	public void setEVENT_RESPONSETIME(String eVENT_RESPONSETIME) {
		EVENT_RESPONSETIME = eVENT_RESPONSETIME;
	}

	public String getLOG_FORMAT() {
		return LOG_FORMAT;
	}

	public void setLOG_FORMAT(String lOG_FORMAT) {
		LOG_FORMAT = lOG_FORMAT;
	}

	public String getLOG_VERSION() {
		return LOG_VERSION;
	}

	public void setLOG_VERSION(String lOG_VERSION) {
		LOG_VERSION = lOG_VERSION;
	}

	public String getVENDOR() {
		return VENDOR;
	}

	public void setVENDOR(String vENDOR) {
		VENDOR = vENDOR;
	}

	public String getVENDOR_PRODUCT() {
		return VENDOR_PRODUCT;
	}

	public void setVENDOR_PRODUCT(String vENDOR_PRODUCT) {
		VENDOR_PRODUCT = vENDOR_PRODUCT;
	}

	public String getVENDOR_PRODUCT_VERSION() {
		return VENDOR_PRODUCT_VERSION;
	}

	public void setVENDOR_PRODUCT_VERSION(String vENDOR_PRODUCT_VERSION) {
		VENDOR_PRODUCT_VERSION = vENDOR_PRODUCT_VERSION;
	}

	public String getLOB_SOURCE() {
		return LOB_SOURCE;
	}

	public void setLOB_SOURCE(String lOB_SOURCE) {
		LOB_SOURCE = lOB_SOURCE;
	}

	public String getLOB_CEF_VERSION() {
		return LOB_CEF_VERSION;
	}

	public void setLOB_CEF_VERSION(String lOB_CEF_VERSION) {
		LOB_CEF_VERSION = lOB_CEF_VERSION;
	}

}

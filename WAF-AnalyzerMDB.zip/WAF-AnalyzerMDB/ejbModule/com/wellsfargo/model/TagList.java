/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.model;

/**
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 */

public class TagList {
	private static String Policy;
	private static String ServerGroup;
	private static String ServiceName;
	private static String ApplicationName;
	private static String Descript;
	private static String AlertType;
	private static String AlertName;
	private static String AlertSeverity;
	private static String AlertID;
	private static String AlertFlag;
	private static String AlertLastUpdateTime;
	private static String EventGateway;
	private static String ViolationDescription;
	private static String AlertOccurences;
	private static String EventAlertName;
	private static String EventOccurences;
	private static String EventSeverity;
	private static String EventID;
	private static String EventAction;
	private static String EventSimulationMode;
	private static String EventResponseCode;
	private static String EventHTTPMethod;
	private static String EventURLPath;
	private static String cat;
	private static String act;
	private static String dst;
	private static String dpt;
	private static String duser;
	private static String src;
	private static String spt;
	private static String proto;
	private static String rt;
	private static String EventQuery;
	private static String EventReqHeaderName;
	private static String EventREqHeaderValue;
	private static String EventResponseSize;
	private static String EventResponseTime;
	private static String EventResHeaderName;
	private static String EventResHeaderValue;

	public static String getAct() {
		return act;
	}

	public void setAct(String act) {
		TagList.act = act;
	}

	public static String getDst() {
		return dst;
	}

	public void setDst(String dst) {
		TagList.dst = dst;
	}

	public static String getDpt() {
		return dpt;
	}

	public void setDpt(String dpt) {
		TagList.dpt = dpt;
	}

	public static String getDuser() {
		return duser;
	}

	public void setDuser(String duser) {
		TagList.duser = duser;
	}

	public static String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		TagList.src = src;
	}

	public static String getSpt() {
		return spt;
	}

	public void setSpt(String spt) {
		TagList.spt = spt;
	}

	public static String getProto() {
		return proto;
	}

	public void setProto(String proto) {
		TagList.proto = proto;
	}

	public static String getRt() {
		return rt;
	}

	public void setRt(String rt) {
		TagList.rt = rt;
	}

	public static String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		TagList.cat = cat;
	}

	public static String getPolicy() {
		return Policy;
	}

	public void setPolicy(String policy) {
		Policy = policy;
	}

	public static String getServerGroup() {
		return ServerGroup;
	}

	public void setServerGroup(String serverGroup) {
		ServerGroup = serverGroup;
	}

	public static String getServiceName() {
		return ServiceName;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	public static String getApplicationName() {
		return ApplicationName;
	}

	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}

	public static String getDescript() {
		return Descript;
	}

	public void setDescript(String descript) {
		Descript = descript;
	}

	public static String getAlertType() {
		return AlertType;
	}

	public void setAlertType(String alertType) {
		AlertType = alertType;
	}

	public static String getAlertName() {
		return AlertName;
	}

	public void setAlertName(String alertName) {
		AlertName = alertName;
	}

	public static String getAlertSeverity() {
		return AlertSeverity;
	}

	public void setAlertSeverity(String alertSeverity) {
		AlertSeverity = alertSeverity;
	}

	public static String getAlertID() {
		return AlertID;
	}

	public void setAlertID(String alertID) {
		AlertID = alertID;
	}

	public static String getAlertFlag() {
		return AlertFlag;
	}

	public void setAlertFlag(String alertFlag) {
		AlertFlag = alertFlag;
	}

	public static String getAlertLastUpdateTime() {
		return AlertLastUpdateTime;
	}

	public void setAlertLastUpdateTime(String alertLastUpdateTime) {
		AlertLastUpdateTime = alertLastUpdateTime;
	}

	public static String getEventGateway() {
		return EventGateway;
	}

	public void setEventGateway(String eventGateway) {
		EventGateway = eventGateway;
	}

	public static String getViolationDescription() {
		return ViolationDescription;
	}

	public void setViolationDescription(String violationDescription) {
		ViolationDescription = violationDescription;
	}

	public static String getAlertOccurences() {
		return AlertOccurences;
	}

	public void setAlertOccurences(String alertOccurences) {
		AlertOccurences = alertOccurences;
	}

	public static String getEventAlertName() {
		return EventAlertName;
	}

	public void setEventAlertName(String eventAlertName) {
		EventAlertName = eventAlertName;
	}

	public static String getEventOccurences() {
		return EventOccurences;
	}

	public void setEventOccurences(String eventOccurences) {
		EventOccurences = eventOccurences;
	}

	public static String getEventSeverity() {
		return EventSeverity;
	}

	public void setEventSeverity(String eventSeverity) {
		EventSeverity = eventSeverity;
	}

	public static String getEventID() {
		return EventID;
	}

	public void setEventID(String eventID) {
		EventID = eventID;
	}

	public static String getEventAction() {
		return EventAction;
	}

	public void setEventAction(String eventAction) {
		EventAction = eventAction;
	}

	public static String getEventSimulationMode() {
		return EventSimulationMode;
	}

	public void setEventSimulationMode(String eventSimulationMode) {
		EventSimulationMode = eventSimulationMode;
	}

	public static String getEventResponseCode() {
		return EventResponseCode;
	}

	public void setEventResponseCode(String eventResponseCode) {
		EventResponseCode = eventResponseCode;
	}

	public static String getEventHTTPMethod() {
		return EventHTTPMethod;
	}

	public void setEventHTTPMethod(String eventHTTPMethod) {
		EventHTTPMethod = eventHTTPMethod;
	}

	public static String getEventURLPath() {
		return EventURLPath;
	}

	public void setEventURLPath(String eventURLPath) {
		EventURLPath = eventURLPath;
	}

	public static String getEventQuery() {
		return EventQuery;
	}

	public void setEventQuery(String eventQuery) {
		EventQuery = eventQuery;
	}

	public static String getEventReqHeaderName() {
		return EventReqHeaderName;
	}

	public void setEventReqHeaderName(String eventReqHeaderName) {
		EventReqHeaderName = eventReqHeaderName;
	}

	public static String getEventREqHeaderValue() {
		return EventREqHeaderValue;
	}

	public void setEventREqHeaderValue(String eventREqHeaderValue) {
		EventREqHeaderValue = eventREqHeaderValue;
	}

	public static String getEventResponseSize() {
		return EventResponseSize;
	}

	public void setEventResponseSize(String eventResponseSize) {
		EventResponseSize = eventResponseSize;
	}

	public static String getEventResponseTime() {
		return EventResponseTime;
	}

	public void setEventResponseTime(String eventResponseTime) {
		EventResponseTime = eventResponseTime;
	}

	public static String getEventResHeaderName() {
		return EventResHeaderName;
	}

	public void setEventResHeaderName(String eventResHeaderName) {
		EventResHeaderName = eventResHeaderName;
	}

	public static String getEventResHeaderValue() {
		return EventResHeaderValue;
	}

	public void setEventResHeaderValue(String eventResHeaderValue) {
		EventResHeaderValue = eventResHeaderValue;
	}

}

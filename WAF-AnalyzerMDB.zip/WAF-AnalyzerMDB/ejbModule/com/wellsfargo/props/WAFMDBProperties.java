/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 
package com.wellsfargo.props;

*//** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*//*
import java.io.IOException;
import java.io.InputStream;

import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.security.PermitAll;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.log4j.Logger;

@Singleton
@Startup
public class WAFMDBProperties {

	private static Logger logger = Logger.getLogger(WAFMDBProperties.class);
	private static Properties properties_jdbc;
	private InputStream inputStream;

	@PostConstruct
	public void init() {
		logger.info("Properties Initialization:");
		inputStream = this.getClass().getClassLoader().getResourceAsStream("jdbc.analyzer.properties");
		logger.info("InputStream is: " + inputStream);
		properties_jdbc = new Properties();

		try {
			if (inputStream != null) {
				properties_jdbc.load(inputStream);
			}

		} catch (IOException e) {
			try {
				inputStream.close();
			} catch (IOException e1) {
				logger.error("Error while closing the InputStream" + e1);
			}
			logger.error("Error while reading properties" + e);
		}

	}

	@PermitAll
	public static String getProperty(String key) {
		return properties_jdbc.getProperty(key);
	}

	@PreDestroy
	public void close() {
		try {
			inputStream.close();
			properties_jdbc.clear();
		} catch (IOException e) {
			logger.error("Error while closing the InputStream:" + e);
		}
	}
}
*/
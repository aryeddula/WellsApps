/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.props;

/** 
* @Author: Ashok
* @Version: 1.1
* @Created on: 5/22/2017
*/

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.log4j.Logger;

import com.wellsfargo.model.TagList;

@Singleton
@Startup
public class WAFTagProperties {
	private static Logger logger = Logger.getLogger(WAFTagProperties.class);
	private static Properties properties;
	private InputStream inputStream;

	public WAFTagProperties() {
		// TODO Auto-generated constructor stub
	}

	@PostConstruct
	public void init() {
		logger.info("Intialization of Tags:");
		inputStream = this.getClass().getClassLoader().getResourceAsStream("console.properties");
		logger.info("InputStream is: " + inputStream);
		properties = new Properties();

		try {
			if (inputStream != null)
				properties.load(inputStream);
			if (properties != null)
				setTaglist();
		} catch (IOException e) {
			try {
				inputStream.close();
			} catch (IOException e1) {
				logger.error("Error while closing the InputStream" + e1);
			}
			logger.error("Error while reading properties" + e);
		}
	}

	public void setTaglist() {
		TagList tagList = new TagList();
		tagList.setPolicy(properties.getProperty("Policy"));
		tagList.setServerGroup(properties.getProperty("ServerGroup"));
		tagList.setServiceName(properties.getProperty("ServiceName"));
		tagList.setApplicationName(properties.getProperty("ApplicationName"));
		tagList.setDescript(properties.getProperty("Description"));
		tagList.setAlertType(properties.getProperty("AlertType"));
		tagList.setAlertName(properties.getProperty("AlertName"));
		tagList.setAlertSeverity(properties.getProperty("AlertSeverity"));
		tagList.setAlertID(properties.getProperty("AlertID"));
		tagList.setAlertFlag(properties.getProperty("AlertFlag"));
		tagList.setAlertLastUpdateTime(properties.getProperty("AlertLastUpdateTime"));
		tagList.setEventGateway(properties.getProperty("EventGateway"));
		tagList.setViolationDescription(properties.getProperty("ViolationDescription"));
		tagList.setAlertOccurences(properties.getProperty("AlertOccurences"));
		tagList.setEventAlertName(properties.getProperty("EventAlertName"));
		tagList.setEventOccurences(properties.getProperty("EventOccurences"));
		tagList.setEventSeverity(properties.getProperty("EventSeverity"));
		tagList.setEventID(properties.getProperty("EventID"));
		tagList.setEventAction(properties.getProperty("EventAction"));
		tagList.setEventSimulationMode(properties.getProperty("EventSimulationMode"));
		tagList.setEventResponseCode(properties.getProperty("EventResponseCode"));
		tagList.setEventHTTPMethod(properties.getProperty("EventHTTPMethod"));
		tagList.setEventURLPath(properties.getProperty("EventURLPath"));
		tagList.setEventQuery(properties.getProperty("EventQuery"));
		tagList.setEventReqHeaderName(properties.getProperty("EventReqHeaderName"));
		tagList.setEventREqHeaderValue(properties.getProperty("EventREqHeaderValue"));
		tagList.setEventResponseSize(properties.getProperty("EventResponseSize"));
		tagList.setEventResponseTime(properties.getProperty("EventResponseTime"));
		tagList.setEventResHeaderName(properties.getProperty("EventResHeaderName"));
		tagList.setEventResHeaderValue(properties.getProperty("EventResHeaderValue"));
		tagList.setCat(properties.getProperty("cat"));
		tagList.setAct(properties.getProperty("act"));
		tagList.setDst(properties.getProperty("dst"));
		tagList.setDpt(properties.getProperty("dpt"));
		tagList.setDuser(properties.getProperty("duser"));
		tagList.setSrc(properties.getProperty("src"));
		tagList.setSpt(properties.getProperty("spt"));
		tagList.setProto(properties.getProperty("proto"));
		tagList.setRt(properties.getProperty("rt"));
	}

	@PreDestroy
	public void close() {
		try {
			inputStream.close();
			properties.clear();
		} catch (IOException e) {
			logger.error("Error while closing the InputStream:" + e);
		}
	}
}

	$(document).ready(function() {
		
		$('#searchResults,#invalidip-results-msg').hide();	
		
		$("#multipleip-search-form :input").attr("disabled", true);
		$("input[type=radio]").attr('disabled', false);
		$('#fileupload').attr("disabled", true);
		$('#multipleIPRadio').attr("checked", false);
		
		
		$("#singleIPRadio").click(function () {
			
			$('#searchResults_wrapper,#invalidip-results-msg').hide();	
			$("#multipleip-search-form").trigger("reset");
			$("#multipleip-search-form :input").attr("disabled", true);
			$("#singleip-search-form :input").attr("disabled", false);
			$("input[type=radio]").attr('disabled', false);
			$('#multipleIPRadio').attr("checked", false);
			$('#fileupload').attr("disabled", true);
		});
		
		
		$("#multipleIPRadio").click(function () {
			
			$('#searchResults_wrapper,#invalidip-results-msg').hide();
			$('#geoIpAddress').val('');
			$("#singleip-search-form :input").attr("disabled", true);
			$("#multipleip-search-form :input").attr("disabled", false);
			$("input[type=radio]").attr('disabled', false);
			$('#singleIPRadio').attr("checked", false);
			$('#fileupload').attr("disabled", false);
		});
		
		
		$('input[type=file]').change(function () {
			var val = $(this).val().toLowerCase();
			var regex = new RegExp("(.*?)\.(txt|csv)$");
			if(!(regex.test(val))) {
				$(this).val('');
				BootstrapDialog.alert('Please upload valid file format (txt,csv) !');
			}
			if(this.files[0].size == 0){
				$(this).val('');
				showAlertMessage('Selected file cannot be empty !');
			}	
			if((this.files[0].size/1024) > 50){
				$(this).val('');
				showAlertMessage('Selected file cannot exceed more than 50 kb !');
			}
		});
		
		$("#singleip-search-form").submit(function(event) { 

			// Prevent the form from submitting via the browser.
			event.preventDefault();
			
			$('#searchResults_wrapper,#invalidip-results-msg').hide();
			
			var geoIpAddress = $("#geoIpAddress").val();
			
			if(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$|^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/.test(geoIpAddress))
				singleIpSearch(event,$(this),geoIpAddress);
			else
				showAlertMessage('Please enter valid IP address');
				
		 }); 
		
		$("#multipleip-search-form").submit(function(event) { 
			
			if ( $("div").hasClass("fileupload fileupload-new") ) { 
				showAlertMessage('Please select a file and then upload');
			    event.preventDefault(); // or return false;
			}
			else{
				$('#searchResults_wrapper,#invalidip-results-msg').hide();
				multipleIpSearch(event, $(this));
			} 
				
		});

	});
	
	
	function showInvalidIpResults() {

		BootstrapDialog.show({
            type: BootstrapDialog.TYPE_PRIMARY,
            title: 'Invalid IP data',
            message: $("#invalidip-results").val(),
            buttons: [{ label: 'OK',
                action: function(dialogItself){
                    dialogItself.close();
                }}]
    	}); 
		
	}
	
	function showAlertMessage(errMsg) {

		BootstrapDialog.show({
            type: BootstrapDialog.TYPE_DANGER,
            title: 'Error !',
            message: errMsg,
            buttons: [{ label: 'OK',
                action: function(dialogItself){
                    dialogItself.close();
                }}]
    	});
		
	}

	function singleIpSearch(event,form,geoIpAddress) {

		$.ajax({
			url			: $(form).attr("action"), // or  url : "/getGeoIPSearchResult.html"
			type 		: "POST",
			contentType : "application/json",
			data 		: geoIpAddress,
			dataType 	: "json",
			timeout 	: 100000,
			success : function(response) {
				console.log("SUCCESS: ", response);
				display(response);
			},
			error : function(ex) {
				console.log("ERROR: ", ex);
				display(ex);
			}
		});

	}
	
	function multipleIpSearch(event, form) {
		event.preventDefault();
		var fileData=new FormData($(form)[0]);
		showSpinner();
	    $.ajax({	      
	        url			:$(form).attr("action"),
			type		:'POST',
			data		:fileData,
			//async		:false,
			cache		:false,
			contentType	:false,
		    enctype		:'multipart/form-data',
			processData	:false,
			dataType 	: "json",
			timeout 	: 100000,
	        success : function(response) {
				console.log("SUCCESS: ", response);
				hideSpinner();
				display(response);
			},
			error : function(ex) {
				console.log("ERROR: ", ex);
				hideSpinner();
				display(ex); 
			}
	    }); 
	}
	
	function showSpinner() {
		$("#modal").css("display","block");
		$("#fade").css("display","block");
	}
	
	function hideSpinner() {
		$("#modal").css("display","none");
		$("#fade").css("display","none");
	}

	function display(response) {
		
		if(response.statusText == 'success' || response.statusText == 'partialSuccess'){
			
			if(response.invalidResult){
				$("#invalidip-results").val(response.invalidResult);
				$("#invalidip-results-msg").show();				
			}
			
			$("#searchResults").show();

			$('#searchResults').dataTable({
			
				"bDestroy": true,
	            "data": response.validResult,
	            "columns": [
	                        {"mDataProp": "geoIpAddress"},
	                        {"mDataProp": "countryCode"},
	                        {"mDataProp": "location"},
	                        {"mDataProp": "postalCode"},
	                        {"mDataProp": "approximateCoordinates"},
	                        {"mDataProp": "isp"},
	                        {"mDataProp": "organization"}
	                    ]
	        });	
		}
		else{
			showAlertMessage('Sorry, no results found. Possible issues could be either Invalid data or Backend connection failure.');
		}	
	}
	
	
	!function(e){var t=function(t,n){this.$element=e(t),this.type=this.$element.data("uploadtype")||(this.$element.find(".thumbnail").length>0?"image":"file"),this.$input=this.$element.find(":file");if(this.$input.length===0)return;this.name=this.$input.attr("name")||n.name,this.$hidden=this.$element.find('input[type=hidden][name="'+this.name+'"]'),this.$hidden.length===0&&(this.$hidden=e('<input type="hidden" />'),this.$element.prepend(this.$hidden)),this.$preview=this.$element.find(".fileupload-preview");var r=this.$preview.css("height");this.$preview.css("display")!="inline"&&r!="0px"&&r!="none"&&this.$preview.css("line-height",r),this.original={exists:this.$element.hasClass("fileupload-exists"),preview:this.$preview.html(),hiddenVal:this.$hidden.val()},this.$remove=this.$element.find('[data-dismiss="fileupload"]'),this.$element.find('[data-trigger="fileupload"]').on("click.fileupload",e.proxy(this.trigger,this)),this.listen()};t.prototype={listen:function(){this.$input.on("change.fileupload",e.proxy(this.change,this)),e(this.$input[0].form).on("reset.fileupload",e.proxy(this.reset,this)),this.$remove&&this.$remove.on("click.fileupload",e.proxy(this.clear,this))},change:function(e,t){if(t==="clear")return;var n=e.target.files!==undefined?e.target.files[0]:e.target.value?{name:e.target.value.replace(/^.+\\/,"")}:null;if(!n){this.clear();return}this.$hidden.val(""),this.$hidden.attr("name",""),this.$input.attr("name",this.name);if(this.type==="image"&&this.$preview.length>0&&(typeof n.type!="undefined"?n.type.match("image.*"):n.name.match(/\.(gif|png|jpe?g)$/i))&&typeof FileReader!="undefined"){var r=new FileReader,i=this.$preview,s=this.$element;r.onload=function(e){i.html('<img src="'+e.target.result+'" '+(i.css("max-height")!="none"?'style="max-height: '+i.css("max-height")+';"':"")+" />"),s.addClass("fileupload-exists").removeClass("fileupload-new")},r.readAsDataURL(n)}else this.$preview.text(n.name),this.$element.addClass("fileupload-exists").removeClass("fileupload-new")},clear:function(e){this.$hidden.val(""),this.$hidden.attr("name",this.name),this.$input.attr("name","");if(navigator.userAgent.match(/msie/i)){var t=this.$input.clone(!0);this.$input.after(t),this.$input.remove(),this.$input=t}else this.$input.val("");this.$preview.html(""),this.$element.addClass("fileupload-new").removeClass("fileupload-exists"),e&&(this.$input.trigger("change",["clear"]),e.preventDefault())},reset:function(e){this.clear(),this.$hidden.val(this.original.hiddenVal),this.$preview.html(this.original.preview),this.original.exists?this.$element.addClass("fileupload-exists").removeClass("fileupload-new"):this.$element.addClass("fileupload-new").removeClass("fileupload-exists")},trigger:function(e){this.$input.trigger("click"),e.preventDefault()}},e.fn.fileupload=function(n){return this.each(function(){var r=e(this),i=r.data("fileupload");i||r.data("fileupload",i=new t(this,n)),typeof n=="string"&&i[n]()})},e.fn.fileupload.Constructor=t,e(document).on("click.fileupload.data-api",'[data-provides="fileupload"]',function(t){var n=e(this);if(n.data("fileupload"))return;n.fileupload(n.data());var r=e(t.target).closest('[data-dismiss="fileupload"],[data-trigger="fileupload"]');r.length>0&&(r.trigger("click.fileupload"),t.preventDefault())})}(window.jQuery)
	
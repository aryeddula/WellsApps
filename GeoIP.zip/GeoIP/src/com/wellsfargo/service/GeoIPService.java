package com.wellsfargo.service;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.maxmind.db.Reader;
import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.model.IspResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Country;
import com.maxmind.geoip2.record.Location;
import com.maxmind.geoip2.record.Postal;
import com.maxmind.geoip2.record.Subdivision;
import com.wellsfargo.model.GeoIPLocationDetails;
@Configuration
@Service("geoIPService")
@PropertySource({ "classpath:db.properties"})
public class GeoIPService {

	// private static final Logger logger =
	// LoggerFactory.getLogger(GeoIPService.class);
	static final Logger logger = Logger.getLogger(GeoIPService.class);

	private static DatabaseReader cityReader = null;
	private static DatabaseReader ispReader = null;

	@Autowired
	private ResourceLoader resourceLoader;
	
	@Autowired
	Environment env;
	
	@PostConstruct
	public void init() {
		try {
			logger.info("GeoIPService: Trying to load GeoIP2-City & GeoIP2-ISP database...");
			String env1 = env.getProperty("HOSTNAME");
			logger.info("HOSTNAME:"+ env1);
    		Resource cityResource;
			Resource ispResource;

			cityResource = resourceLoader
					.getResource(env.getProperty("mmd_GeoIP2-City"));
			ispResource = resourceLoader
					.getResource(env.getProperty("mmd_GeoIP2-ISP"));
			
			// Initialize the reader
			cityReader = new DatabaseReader.Builder(cityResource.getInputStream()).fileMode(Reader.FileMode.MEMORY)
					.build();
			ispReader = new DatabaseReader.Builder(ispResource.getInputStream()).fileMode(Reader.FileMode.MEMORY)
					.build();

			logger.info("GeoIPService: Database was loaded successfully.");

		} catch (IOException | NullPointerException e) {
			logger.error("Database reader cound not be initialized. ", e);
			logger.info("Database reader cound not be initialized. " + ExceptionUtils.getFullStackTrace(e));
		}
	}

	@SuppressWarnings("rawtypes")
	public HashMap<String, List> getGeoIPDetails(List<String> validGeoIpAddresses, List<String> invalidGeoIpAddresses) {
		logger.info("getGeoIPDetails : start");
		HashMap<String, List> searchResults = new HashMap<String, List>();

		List<GeoIPLocationDetails> validResults = new ArrayList<GeoIPLocationDetails>();

		for (String geoIpAddress : validGeoIpAddresses) {
			try {
				validResults.add(getGeoIPDetail(geoIpAddress));
			} catch (Exception ex) {
				invalidGeoIpAddresses.add(geoIpAddress);
			}
		}

		searchResults.put("validResults", validResults);
		searchResults.put("invalidResults", invalidGeoIpAddresses);
		logger.info("getGeoIPDetails : end");
		return searchResults;

	}

	public GeoIPLocationDetails getGeoIPDetail(String geoIpAddress) throws IOException, GeoIp2Exception {
		logger.info("getGeoIPDetail : start");
		GeoIPLocationDetails geoIPLocationDetails = new GeoIPLocationDetails();

		InetAddress inetAddress = InetAddress.getByName(geoIpAddress);
		CityResponse cityResponse = cityReader.city(inetAddress);
		IspResponse ispResponse = ispReader.isp(inetAddress);
		/* DomainResponse domain = ispReader.domain(inetAddress); */

		Country country = cityResponse.getCountry();
		Subdivision subdivision = cityResponse.getMostSpecificSubdivision();
		City city = cityResponse.getCity();
		Postal postal = cityResponse.getPostal();
		Location location = cityResponse.getLocation();

		geoIPLocationDetails.setGeoIpAddress(geoIpAddress);
		geoIPLocationDetails.setCountryCode(country.getIsoCode() != null ? country.getIsoCode() : " ");
		geoIPLocationDetails.setLocation((country.getName() != null ? country.getName() + " " : " ")
				+ (city.getName() != null ? city.getName() + " " : " ")
				+ (subdivision.getName() != null ? subdivision.getName() : ""));
		geoIPLocationDetails.setPostalCode(postal.getCode() != null ? postal.getCode() : " ");
		geoIPLocationDetails.setApproximateCoordinates((location.getLatitude() != null ? location.getLatitude() : " ")
				+ "   " + (location.getLongitude() != null ? location.getLongitude() : ""));
		geoIPLocationDetails.setIsp(ispResponse.getIsp() != null ? ispResponse.getIsp() : "");
		geoIPLocationDetails
				.setOrganization(ispResponse.getOrganization() != null ? ispResponse.getOrganization() : "");
		logger.info("getGeoIPDetail : end");

		return geoIPLocationDetails;
	}

	@PreDestroy
	public void preDestroy() {
		if (cityReader != null && ispReader != null) {
			try {
				cityReader.close();
				ispReader.close();
			} catch (IOException e) {
				logger.info("Failed to close the reader.");
				logger.error("Failed to close the reader.");
			}
		}
	}

}

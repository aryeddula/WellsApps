package com.wellsfargo.model;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonView;

@Component
@Scope(value = "prototype")
public class GeoIPSearchResponse {
	
	@JsonView
	String statusCode;
	
	@JsonView
	String statusText;
	
	@JsonView
	String reason;
	
	@JsonView
	List<GeoIPLocationDetails> validResult;
	
	@JsonView
	List<String> invalidResult;
	
	public String getStatusCode() {
		return statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public List<GeoIPLocationDetails> getValidResult() {
		return validResult;
	}

	public void setValidResult(List<GeoIPLocationDetails> validResult) {
		this.validResult = validResult;
	}

	public List<String> getInvalidResult() {
		return invalidResult;
	}

	public void setInvalidResult(List<String> invalidResult) {
		this.invalidResult = invalidResult;
	}

}

package com.wellsfargo.model;

public class GeoIPLocationDetails {
	
	private String geoIpAddress;
	private String countryCode;
	private String location;
	private String postalCode;
	private String approximateCoordinates;
	private String isp;
	private String organization;

	
	public String getGeoIpAddress() {
		return geoIpAddress;
	}
	public void setGeoIpAddress(String geoIpAddress) {
		this.geoIpAddress = geoIpAddress;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getApproximateCoordinates() {
		return approximateCoordinates;
	}
	public void setApproximateCoordinates(String approximateCoordinates) {
		this.approximateCoordinates = approximateCoordinates;
	}
	public String getIsp() {
		return isp;
	}
	public void setIsp(String isp) {
		this.isp = isp;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}

}

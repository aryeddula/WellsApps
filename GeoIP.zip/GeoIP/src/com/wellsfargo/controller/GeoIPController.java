package com.wellsfargo.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.wellsfargo.model.GeoIPLocationDetails;
import com.wellsfargo.model.GeoIPSearchResponse;
import com.wellsfargo.service.GeoIPService;


@RestController
@Scope("prototype")
public class GeoIPController {
	
	
	//private static final Logger logger = LoggerFactory.getLogger(GeoIPController.class);
	private static final Logger logger = Logger.getLogger(GeoIPController.class);
	
	private static Pattern VALID_IPV4_PATTERN = null;
    private static Pattern VALID_IPV6_PATTERN = null;
    private static Pattern VALID_IPV6_HEX_COMPRESSED_PATTERN  = null;
    private static final String ipv4Pattern = "(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])";
    private static final String ipv6Pattern = "([0-9a-f]{1,4}:){7}([0-9a-f]){1,4}";
    private static final String ipv6HexCompressedPattern = "^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$";
    
    @Autowired(required = true)
    private GeoIPService geoIPService;
	
	@Autowired(required = true)
	private GeoIPSearchResponse geopIpSearchResponse;
	
    static {
        try {
          VALID_IPV4_PATTERN = Pattern.compile(ipv4Pattern, Pattern.CASE_INSENSITIVE);
          VALID_IPV6_PATTERN = Pattern.compile(ipv6Pattern, Pattern.CASE_INSENSITIVE);
          VALID_IPV6_HEX_COMPRESSED_PATTERN = Pattern.compile(ipv6HexCompressedPattern, Pattern.CASE_INSENSITIVE);
        } catch (PatternSyntaxException e) {
        	logger.info("Unable to compile pattern"+ ExceptionUtils.getFullStackTrace(e));
        }
    }	

    public static boolean isIpAddress(String ipAddress) {
        Matcher m1 = VALID_IPV4_PATTERN.matcher(ipAddress);
        if (m1.matches()) 
          return true;
        Matcher m2 = VALID_IPV6_PATTERN.matcher(ipAddress);
        if (m2.matches())
            return true;
        Matcher m3 = VALID_IPV6_HEX_COMPRESSED_PATTERN.matcher(ipAddress);
        return m3.matches();
    }
    
	@ResponseBody
	@RequestMapping(value="/getGeoIPSearchResult", method = RequestMethod.POST,headers="Accept=application/json")
	public String getGeoIPSearchResult(@RequestBody String geoIpAddress) {
		logger.info("getGeoIPSearchResult : start");
		List<GeoIPLocationDetails> searchResult = new ArrayList<GeoIPLocationDetails>();
		
		try{
			searchResult.add(geoIPService.getGeoIPDetail(geoIpAddress));
			geopIpSearchResponse.setStatusCode("200");
			geopIpSearchResponse.setStatusText("success");
			geopIpSearchResponse.setValidResult(searchResult);
		}catch(Exception ex){
			geopIpSearchResponse.setStatusCode("204");
			geopIpSearchResponse.setStatusText("error");
			geopIpSearchResponse.setReason(ex.getMessage());
		}
		System.out.println(new Gson().toJson(geopIpSearchResponse));
		logger.info("getGeoIPSearchResult : end");
		return new Gson().toJson(geopIpSearchResponse);
	}
	
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/getGeoIPSearchResults", method = RequestMethod.POST,headers="Accept=application/json")
	public String getGeoIPSearchResults( @RequestParam("file") MultipartFile file) throws IOException{
		logger.info("getGeoIPSearchResults : start");
		@SuppressWarnings("rawtypes")
		HashMap<String,List>  searchResults = null;
		String startTag = "<script";
	    String endTag = "</script>";
		List<String> validGeoIpAddressList = new ArrayList<String>(); 
		List<String> invalidGeoIpAddressList = new ArrayList<String>(); 
		
		String input = IOUtils.toString(file.getInputStream(), "UTF-8");
        if(input.contains(startTag) && input.contains(endTag)){
        	StringBuilder sb = new StringBuilder(input);        
            sb.replace(input.indexOf(startTag) + startTag.length(), input.indexOf(endTag), ""); //removing the text between script        
            input = sb.toString().replace(startTag, "").replace(endTag, ""); 
        }
        
        BufferedReader br = new BufferedReader(new StringReader(input));    
		
        String fileRead = br.readLine();
        while (fileRead != null){
            if(!fileRead.trim().equals("")){
            	String[] geoIpAddressess = fileRead.split("\\s*,\\s*");
            	for (String geoIpAddress : geoIpAddressess) {
             	   if(isIpAddress(geoIpAddress)) 
             		   validGeoIpAddressList.add(geoIpAddress); 
             	   else 
             		   invalidGeoIpAddressList.add(geoIpAddress);
            	}
            }
            fileRead = br.readLine();
        }
        br.close();
        
        searchResults = geoIPService.getGeoIPDetails(validGeoIpAddressList,invalidGeoIpAddressList);
        
        if((searchResults.get("validResults").size()>0) && (searchResults.get("invalidResults").size() == 0))
        {
        	geopIpSearchResponse.setStatusCode("200");
			geopIpSearchResponse.setStatusText("success");
			geopIpSearchResponse.setValidResult(searchResults.get("validResults"));
        }
        else if((searchResults.get("validResults").size() > 0) && (searchResults.get("invalidResults").size() > 0)){
        	geopIpSearchResponse.setStatusCode("203");
			geopIpSearchResponse.setStatusText("partialSuccess");
			geopIpSearchResponse.setValidResult(searchResults.get("validResults"));
			geopIpSearchResponse.setInvalidResult(searchResults.get("invalidResults"));
        }
        else{
        	geopIpSearchResponse.setStatusCode("204");
			geopIpSearchResponse.setStatusText("error");
			geopIpSearchResponse.setReason("No results found");
        }
		System.out.println(new Gson().toJson(geopIpSearchResponse));
		logger.info("getGeoIPSearchResults : end");
		return new Gson().toJson(geopIpSearchResponse);
	}
	
	
	
	/***********************************    Web service methods   ***************************************/
	
	
	@RequestMapping(value="/getGeoIPInfo", method = RequestMethod.GET,headers="Accept=application/json")
	public String getGeoIPInfo(@RequestParam("geoIpAddress") String  geoIpAddress) {			
		logger.info("getGeoIPInfo : start");
		List<GeoIPLocationDetails> searchResult = new ArrayList<GeoIPLocationDetails>();
		
		try{
			searchResult.add(geoIPService.getGeoIPDetail(geoIpAddress));
			geopIpSearchResponse.setStatusCode("200");
			geopIpSearchResponse.setStatusText("success");
			geopIpSearchResponse.setValidResult(searchResult);
		}catch(Exception ex){
			geopIpSearchResponse.setStatusCode("204");
			geopIpSearchResponse.setStatusText("error");
			geopIpSearchResponse.setReason(ex.getMessage());
		}
		logger.info("getGeoIPInfo : end");
		return new Gson().toJson(geopIpSearchResponse);
	}
	
	
	/*@RequestMapping(value="/getGeoIPInfo/{geoIpAddress}", method = RequestMethod.GET,headers="Accept=application/json")
	public String getGeoIPInfo(@PathVariable String  geoIpAddress) {	
		
		List<GeoIPLocationDetails> searchResult = new ArrayList<GeoIPLocationDetails>();
		
		try{
			searchResult.add(geoIPService.getGeoIPDetail(geoIpAddress));
			geopIpSearchResponse.setStatusCode("200");
			geopIpSearchResponse.setStatusText("success");
			geopIpSearchResponse.setResult(searchResult);
		}catch(Exception ex){
			geopIpSearchResponse.setStatusCode("400");
			geopIpSearchResponse.setStatusText("error");
			geopIpSearchResponse.setResult(searchResult);
		}
		return new Gson().toJson(geopIpSearchResponse);
		
	}*/

}

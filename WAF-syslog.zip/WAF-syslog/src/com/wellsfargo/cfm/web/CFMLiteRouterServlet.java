/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wellsfargo.cfm.common.ProducerAppConstants;
import com.wellsfargo.cfm.exception.JMSClientException;
import com.wellsfargo.cfm.lite.CFMLiteJMSHandler;
import com.wellsfargo.cfm.lite.CFMLiteMessageTimer;
import com.wellsfargo.cfm.lite.CFMLiteProperties;
import com.wellsfargo.cfm.lite.MessageHandler;

/**
 * @author zhushiwe
 *
 */
public class CFMLiteRouterServlet extends HttpServlet {
	
	private static final long serialVersionUID = 6757355617921392281L;
	private CFMLiteMessageTimer timer;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		if (CFMLiteProperties.getBoolean("cfmLite.timer.enabled")) {
			timer = new CFMLiteMessageTimer();
			new Thread(new CFMLiteMessageTimer()).start();
		}
	}
	
	@Override
	public void destroy() {
		if (timer != null)
			timer.stopTimer();
		super.destroy();
	}

	protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response)
                throws ServletException, IOException {
        this.doPost(request, response);
    }
    
    protected void doPost(final HttpServletRequest request,
	            final HttpServletResponse response)
	                throws ServletException, IOException {
    	
    	String sourceURL = request.getParameter(ProducerAppConstants.TEALEAF_URL_PARAM);
    	String requestString = getRequestBody(request);
        
        MessageHandler handler = MessageHandler.getInstance();
        handler.addMessage(sourceURL, requestString);
        
        Object msgs = handler.getConsolidatedMessages(CFMLiteProperties.getIntProperty("cfmLite.buffer.size", 10));
        if (msgs != null) {
				try {
					new CFMLiteJMSHandler().send(msgs);
				} catch (JMSClientException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        }
        
	}

	private String getRequestBody(final HttpServletRequest request)
			throws IOException {
		BufferedReader data = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String line;
        StringBuffer strData = new StringBuffer();
        while ((line = data.readLine()) != null) {
            strData.append(line);
        }
        String requestString = strData.toString();
		return requestString;
	}
}

package com.wellsfargo.cfm.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


import org.apache.log4j.Logger;


public class CFMProperties {

	private static String[] loginURL;
	private static String[] redirectLoginURL;
	
	private static final String cfmPropFileName="cfm.properties";
	private static Logger logger = Logger.getLogger(CFMProperties.class);
	private static String[] logoutURL;

	public static void load(){
		String propFilePath = System.getProperty(ProducerAppConstants.CFM_PROPS_DIR);
    	Properties prop = new Properties();
    	try {
    		if (null == propFilePath)
    			propFilePath ="";

            prop.load(new FileInputStream(propFilePath+cfmPropFileName));
            CFMProperties.parseLoginURLS(prop.getProperty(ProducerAppConstants.LOGIN_URLS));
            CFMProperties.parseRedirectLoginURLS(prop.getProperty(ProducerAppConstants.REDIRECT_LOGIN_URLS));
           
        } catch (IOException e) {
        	 logger.fatal("AppException Occured while reading CFM Config file",e);
		} catch (NumberFormatException nfe) {
			logger.fatal("NumberFormatException Occured while reading CFM Properties file", nfe);
		} catch (Exception exp) {
			logger.fatal("Exception Occured while reading CFM Properties file", exp);
		}
	}

	public static void parseLoginURLS(String propLoginURLS){
		loginURL = CFMUtility.splitValues(propLoginURLS,ProducerAppConstants.LOGIN_URLS_SEPARATOR);
	}

	public static void parseLogoutURLS(String propLogoutURLS){
		logoutURL = CFMUtility.splitValues(propLogoutURLS,ProducerAppConstants.LOGIN_URLS_SEPARATOR);
	}

	public static void parseRedirectLoginURLS(String propRedirectLoginURLS){
		redirectLoginURL = CFMUtility.splitValues(propRedirectLoginURLS,ProducerAppConstants.LOGIN_URLS_SEPARATOR);
	}


	public static String[] getLoginURLS(){
		return  loginURL;
	}

	public static String[] getRedirectLoginURLS(){
		return redirectLoginURL;
	}

	/**
	 * @return the logoutURL
	 */
	public static String[] getLogoutURL() {
		return logoutURL;
	}


}


package com.wellsfargo.cfm.common;

import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;



public class TealeafMessageUtility {
	
	private static final Logger logger = Logger.getLogger(TealeafMessageUtility.class);
	
	public static HashMap parseMessage(String strData) throws Exception
	{
		HashMap<String,String> nvpMap = new HashMap <String,String>();
		//Map < String, Object > nvpMap = null;
		//List< Map< String, Object > > domainMapList = new ArrayList< Map< String, Object > >();
		//nvpMap = new HashMap < String, Object >();

		//Debug info and putting nvp into map object
		logger.info("In doIt() - Retrieving parameter names:");
		//Enumeration en = request.getParameterNames();
		StringTokenizer st = new StringTokenizer(strData, "&");
		String sData;
		int idx;
		//while (st.hasMoreTokens()) {
		//   println(st.nextToken());
		//} 

		while (st.hasMoreTokens())
		{
			sData = (String)st.nextToken();
			//sData = new StringTokenizer(st.nextToken());
			idx = sData.indexOf("=");
			if (idx >= 0)
			{
				String keyName = sData.substring(0, idx);
				String value;
				if (sData.length() > idx+1)
					value = sData.substring(idx+1);
				else
					value = null;
				if (keyName != null)
				{
					//logger.debug("  " + keyName + " = " + value);
					nvpMap.put(keyName, value);
				}
			}
		}
		
		//Send response back to client
		return nvpMap;
	} 
	
	public static HashMap<String,String> parseDebitAccount(String input){
		if(input!= null && input.length()>0){
			HashMap<String,String> values = new HashMap<String,String>();
			int openBraceIndex=input.indexOf('[');
			int closeBraceIndex=input.indexOf(']');
			int hyphenIndex=input.indexOf('-',openBraceIndex);
			if(openBraceIndex>0){
			String accountNumber = input.substring(0, openBraceIndex);
			values.put("debitAccountNumber", accountNumber);
			    if(closeBraceIndex>0){
			    	String details = input.substring(openBraceIndex,closeBraceIndex);
			    	if(hyphenIndex>0){
			    		String debitBankId = input.substring(openBraceIndex+1,hyphenIndex);
			    		values.put("debitBankId", debitBankId);
			    		String accountName = input.substring(hyphenIndex+1,closeBraceIndex);
			    		values.put("debitAccountName",accountName);
			    	}else{
			    		values.put("debitBankId",details);
			    	}
			    }
			    values.put("debitBankName",input.substring(closeBraceIndex+1,input.length()));
			}
			return values;
		}
		return null;
	}

}

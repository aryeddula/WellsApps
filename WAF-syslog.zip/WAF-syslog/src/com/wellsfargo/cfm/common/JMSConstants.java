/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.cfm.common;

/**
 * Class used for defining JMS related constants.
 * @author Syntel
 * @version 1.0
 */
public final class JMSConstants {
    /**
     * Default constructor.
     */
    private JMSConstants() {

    }
    /** Constant used while inserting JNDI_PROVIDER_URL in HashMap. */
    public static final String JNDI_PROVIDER_URL = "JNDI_PROVIDER_URL";

    /** Constant used while inserting INITIAL_CONTEXT_FACTORY in HashMap. */
    public static final String INITIAL_CONTEXT_FACTORY = "INITIAL_CONTEXT_FACTORY";

    /** Constant used while inserting SECURITY_CREDENTIALS in HashMap. */
    public static final String SECURITY_CREDENTIALS = "SECURITY_CREDENTIALS";

    /** Constant used while inserting SECURITY_PRINCIPAL in HashMap. */
    public static final String SECURITY_PRINCIPAL = "SECURITY_PRINCIPAL";

    /** Constant used while inserting CONNECTION_FACTORY_JNDI in HashMap. */
    public static final String CONNECTION_FACTORY_JNDI = "CONNECTION_FACTORY_JNDI";

    /** Constant used while inserting DESTINATION_JNDI in HashMap. */
    public static final String DESTINATION_JNDI = "DESTINATION_JNDI";

    /** Constant used while inserting DESTINATION_TYPE in HashMap. */
    public static final String DESTINATION_TYPE = "DESTINATION_TYPE";
}

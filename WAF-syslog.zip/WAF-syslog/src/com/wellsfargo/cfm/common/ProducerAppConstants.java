/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.cfm.common;

/**
 * Class used for defining application level constants.
 *
 * @author Syntel
 * @version 1.0
 */
public final class ProducerAppConstants {

    /**
     * Default Constructor.
     *
     */
    private ProducerAppConstants() {

    }

    /** Denotes Message type. */
    public static final String OBJECT = "Object";

    /** Denotes Message type. */
    public static final String MAP = "Map";

    /** Denotes request data type. */
    public static final String NVP = "NVP";

    /** Denotes request data type. */
    public static final String SOAP = "SOAP";

    /** Denotes request data type. */
    public static final String XML = "XML";

    /** Denotes DataSource type. */
    public static final String WIRES = "Wires";

    /** Denotes DataSource type. */
    public static final String CEOPORTAL = "/portal/signon";

    /** Denotes DataSource type. */
    public static final String CEOWIRES = "wires";

    /** Denotes Destination type. */
    public static final String QUEUE = "QUEUE";

    /** Denotes Destination type. */
    public static final String TOPIC = "TOPIC";

    /** Request parameter async. */
    public static final String ASYNC = "async";

    /** Provider URL used by Logger bean to pull messages for bacth update **/
    public static final String PROVIDER_URL="PROVIDER_URL";

    public static final String TL_BATCH_PROCESS_FLAG="TL_BATCH_PROCESS_FLAG";

    public static final String ACTIMIZE_WEBSERVICE_EP="ACTIMIZE_WEBSERVICE_EP";
    public static final String ACTIMIZE_WEBSERVICE_TIMEOUT="ACTIMIZE_WEBSERVICE_TIMEOUT";

    /** Request parameter userName. */
    //public static final String USERNAME = "userName";

    /** Request parameter callerCredential. */
    public static final String CALLER_CREDENTIAL = "callerCredential";

    /** Request parameter callerId. */
    public static final String CALLER_ID = "callerId";

    /** Request parameter pm_fp. */
    public static final String PM_FP = "pm_fp";

    /** Request parameter pm_fp. */
    public static final String CEO_SESSION_ID = "ceo_session_id";

    /** new ceo portal session id cookie name */
    public static final String WL_CEOPORTAL = "WL_CEOPORTAL";

    /** new ceo Mobile session id cookie name E66 */
    public static final String WL_MOBPORTAL = "WL_MOBPORTAL";

    /** new ceo portal session id */
    public static final String WL_CEOPORTAL_ID = "WL_CEOPORTAL_ID";

    /** Request parameter application_id. */
    public static final String APPLICATION_ID = "application_id";

    /** Logger name. */
    public static final String LOGGER_NAME = "logger_name";

    /** Consumer name. */
    public static final String CONSUMER_NAME = "consumer_name";

    /** Request parameter query_id. */
    public static final String QUERY_ID = "query_id";

    /** Request parameter dataSourceId. */
    public static final String DATA_SOURCE_ID = "dataSourceId";

    /** Request parameter jdbc_ds. */
    public static final String JDBC_DS = "jdbc_ds";

    /** Request parameter groupName. */
    public static final String GROUP_NAME = "groupName";

    /** Request parameter orgName. */
    //public static final String ORG_NAME = "orgName";

    /** Request parameter clientSessionId. */
    //public static final String CLIENT_SESSION_ID = "clientSessionId";

    /** Request parameter clientTransactionId. */
    //public static final String CLIENT_HITTRANSACTION_ID = "clientTransactionId";

    /** Request parameter company_id. */
    public static final String COMPANY_ID = "company_id";

    /** Request attribute req. */
    public static final String REQUEST = "req";

    /** Constant to denote request data. */
    public static final String REQUEST_DATA = "request";

    /** Constant to denote request Data Type. */
    public static final String MESSAGE_TYPE = "MESSAGE_TYPE";

    /** JMS config id for CONSUMER. */
    public static final String CONSUMER_JMS_CONFIG = "CONSUMER_JMS_CONFIG";

    /** JMS config id for LOGGER. */
    public static final String LOGGING_JMS_CONFIG = "LOGGING_JMS_CONFIG";

    /** JMS config id for BUSINESS BEAN. */
    public static final String
                CEOPORTAL_BUSINESS_JMS = "CEOPORTAL_BUSINESS_JMS";

    /** JMS config id for RSA BEAN. */
    public static final String RSA_JMS_CONFIG = "RSA_JMS_CONFIG";

    /** Status for Rules result. */
    public static final String SEND_TO_CONSUMER = "SEND_TO_CONSUMER";

    /** Status for Rules result. */
    public static final String SEND_TO_LOGGER = "SEND_TO_LOGGER";

    /** Status for Rules result. */
    public static final String SEND_TO_BOTH = "SEND_TO_BOTH";

    /** webservice config id.*/
    public static final String RSA_WEB_SERVICE = "RSA_WEB_SERVICE";

    /** parameter used for setting Config in data in ServletContext. */
    public static final String CONFIG = "config";

    /** constants used to send the message has to Consumer bean. */
    public static final String CONSUMER_BEAN = "CONSUMER_BEAN";

    /** constants used to send the message has to Logger bean. */
    public static final String LOGGER_BEAN = "LOGGER_BEAN";

    /** constants used to send the message has to Business bean. */
    public static final String PRODUCER_BEAN = "PRODUCER_BEAN";

    /** constants used to send the message has to Security bean. */
    public static final String SECURITY_BEAN = "SECURITY_BEAN";

    /** Field used for DB operations.*/
    public static final String CORRELATION_ID = "CORRELATION_ID";

    /** Field used for DB operations.*/
    public static final String MESSAGE = "MESSAGE";

    /** Field used for DB operations.*/
    public static final String REQUEST_COUNT = "REQUEST_COUNT";

    /** Field used for DB operations.*/
    public static final String RESPONSE_COUNT = "RESPONSE_COUNT";

    /** Field used for DB operations.*/
    public static final String
                SECURITY_SYSTEM_RESPONSE = "SECURITY_SYSTEM_RESPONSE";

    /** Field used for DB operations.*/
    public static final String DATASOURCE = "datasource";

    /** Field used for DB operations.*/
    public static final String RSA = "RSA";

    /** Field used for DB operations.*/
    public static final String SECURITY_SYSTEMS = "SECURITY_SYSTEM_ID";

    /** Field used for DB operations.*/
    public static final String ALL_RESPONSE_RECEIVED = "ALL_RESPONSE_RECEIVED";

    /** XML file path for DataRouterConfig.xml. */
    public static final String CFM_PROPS_DIR = "cfmPropsDirPath";

    /** XML file path for Rules.xml. */
    public static final String CFM_RULES_DIR = "cfmRulesDirPath";

    //TeaLeaf parameters
    /** TeaLeaf Application Data ID. */
    public static final String TEALEAF_APPDATA_PARAM = "appdata";

    /** TeaLeaf urlfield parameter. */
    public static final String TEALEAF_URLFIELD_PARAM = "urlfield";

    /** TeaLeaf URL parameter. */
    public static final String TEALEAF_URL_PARAM = "url";

    /** TeaLeaf REFERRER parameter. */
    public static final String TEALEAF_REFERRER_PARAM = "referrer";

    /** TeaLeaf UA parameter. */
    public static final String TEALEAF_UA_PARAM = "ua";

    /** TeaLeaf IP parameter. */
    public static final String TEALEAF_IP_PARAM = "ip";

    /** TeaLeaf PAGETS parameter. */
    public static final String TEALEAF_PAGETS_PARAM = "pagets";

    /** TeaLeaf COOKIES parameter. */
    public static final String TEALEAF_COOKIES_PARAM = "cookies";

    /** TeaLeaf CEO user parameter. */
    public static final String USERNAME = "CEOUSER";

    /** Request parameter orgName. */
    public static final String ORG_NAME = "CEOCOMPANY";

    /** Request parameter clientSessionId. */
    public static final String CLIENT_SESSION_ID = "tltsid";

    /** Request parameter clientTransactionId. */
    public static final String CLIENT_HITTRANSACTION_ID = "tlthid";

    /** CEO Desktop Pattern. */
    public static final String CEO_DESKTOP_PATTERN = "/portal/appmanager/ceoPortal/ceoDesktop";


    /** TeaLeaf SMSESSION parameter. */
    public static final String SMSESSION = "SMSESSION";

    /** TeaLeaf TLTSID parameter. */
    public static final String TEALEAF_COMPANY_PARAM = "company";

    /** TeaLeaf WFUID parameter. */
    public static final String TEALEAF_WFUID_PARAM = "wfuid";

    /** CFM Constant used to save callerId map in security system response map */
    public static final String CALLER_ID_MAP = "CALLER_ID_MAP";

    /** CFM constant used to save status of RSA AA SOAP Response object */
    public static final String RSA_RESP_OBJ = "rsaRespObj";

    /** CFM Activity IDs */
	public static final String CEO_PRE_LOGIN = "90";
	public static final String CEO_PAYMENT = "400";
    public static final String CEO_LOGIN_ATTEMPT = "100";
    public static final String CEO_LOGIN_SUCCESS = "101";
    public static final String CEO_PRE_PASSWD_CHANGE = "99";
    public static final String CEO_PASSWD_CHANGE = "103";
    public static final String RSA_SCORE_RESP = "104";
    public static final String CEO_LOGIN_FAILURE = "110";
    public static final String CEO_LOGOUT= "111";
    public static final int WIRE_TRANSFER = 200;
    public static final int ACH = 300;
    public static final String CEO_MOB_TO_PORTAL_SWITCHOVER = "120";
	// E83 change
	public static final String RSA_AUTHENTICATION = "105";

    /** Security Engine IDs */
    public static final int RSA_ENG_ID = 1;

    /** CFM_TEALEAF_ACTIVITY_T table key names (for Hash map) names */
    public static final String SOURCE_ID = "source_id";
    public static final String ACTIVITY_ID = "activity_id";
    public static final String WFUID = "wfuid";
    public static final String COMPANY = "company";
    public static final String TLTSID = "tltsid";
    public static final String TLTHID = "tlthid";
    public static final String PAGETS = "pagets";
    public static final String REFERRER = "referrer";
    public static final String UA = "ua";
    public static final String IP = "ip";
    public static final String PROCESS_FLAG = "process_flag";
    public static final String CREATED_USER = "created_user";
    public static final String UPDATED_USER = "updated_user";
    public static final String REDIRECT_SERVLET_TLTHID = "redirect_servlet_tlthid";
    public static final String LOGIN_FCC_TLTHID = "login_fcc_tlthid";
    public static final String RSA_STATUS = "rsa_status";
    public static final String RSA_SUCCESS = "C";
    public static final String RSA_FAILED = "F";
    public static final String RSA_SKIPPED = "S";
    /** CFM_RISK_ANALYSIS_RESULT_T table key names (for Hash map) names */
    public static final String RISK_ENGINE_ID = "risk_engine_id";
    public static final String RISK_SCORE = "risk_score";
    public static final String ACTION_CODE = "action_id";

    /** Other CFM table key name (for Hash Map) names */
    public static final String REDIRECT_SERVLET_PAGETS = "redirect_servlet_pagets";
    public static final String LOGIN_SERVLET_PAGETS = "login_servlet_pagets";
    public static final String LOGIN_INFO_PAGETS = "login_info_pagets";

    public static final String KEY_UA = "ua";
    public static final String KEY_REFERRER = "referrer";
    public static final String KEY_IP = "ip";
    public static final String KEY_TLTHID ="tlthid";

    /** RSA AA Error/Warn code */
    public static final int RSA_WEB_SERVICE_SUCCESS  = 200;
    public static final int RSA_WEB_SERVICE_WARN     = 300;
    public static final int RSA_SYSTEM_ERR           = 500;
    public static final int RSA_WEB_SERVICE_DATA_ERR = 510;

    /** RSA AA Status Header params */
    public static final String RSA_REASON_CODE = "reasonCode";
    public static final String RSA_REASON_DESCRIPTION = "reasonDescription";
    public static final String RSA_STATUS_CODE = "statusCode";

    public static final String CFM_PROPERTIES = "cfm_properties";
    public static final String LOGIN_URLS = "LOGIN_URLS";
    public static final String REDIRECT_LOGIN_URLS = "REDIRECT_LOGIN_URLS";
    //E66
    public static final String HOMEFLOW_URLS = "HOMEFLOW_URLS";
    public static final String CEO_LOGOUT_URLS = "CEO_LOGOUT_URLS";
    public static final String LOGIN_URLS_SEPARATOR = ":";
    public static final String ENABLE_HIGH_RISK_LOGIN_RULES = "ENABLE_HIGH_RISK_LOGIN_RULES";
    public static final String ENABLE_SESSION_RULES = "ENABLE_SESSION_RULES";
    public static final String COMPANY_WHITE_LIST_PATTERN="COMPANY_WHITE_LIST_PATTERN";
	public static final String ENABLE_FT_RISKSCORING = "ENABLE_FT_RISKSCORING";
   /*High Risk Login Risk score*/
    public static final String HIGH_RISK_LOGIN_SCORE = "HIGH_RISK_LOGIN_SCORE";
    public static final String CS_RISK_SCORE_MULTIPLE_IP = "CS_RISK_SCORE_MULTIPLE_IP";
    public static final String CS_RISK_SCORE_SAME_IP = "CS_RISK_SCORE_SAME_IP";
    public static final String PORTAL_URL = "PORTAL_URL";
    public static final String WIRES_URLS = "WIRES_URLS";
    public static final String FT_DATASOUCE_ID = "fundsTransfer";


    /** For table CFM_TEA_LEAF_MSG */
    public static final String DS_DATACENTER_ID = "data_center_id";
    public static final String DS_CHANNEL_ID = "channel_id";
    public static final String DS_APPLICATION_ID = "application_id";
    public static final String DS_SUBAPPLICATION_ID = "sub_application_id";

    public static final String tealeaf_canister = "canister";
    public static final String tealeaf_tltsid = "tltsid";
    public static final String tealeaf_tlthid = "tlthid";
    public static final String tealeaf_host = "host";
    public static final String tealeaf_pagets = "pagets";
    public static final String tealeaf_ip = "ip";
    public static final String tealeaf_server  = "server ";
    public static final String tealeaf_port  = "port ";
    public static final String tealeaf_https  = "https ";
    public static final String tealeaf_httpvia = "httpvia";
    public static final String tealeaf_url  = "url ";
    public static final String tealeaf_tlt_url = "tlt_url";
    public static final String tealeaf_qs = "qs";
    public static final String tealeaf_referrer = "referrer";
    public static final String tealeaf_ua = "ua";
    public static final String tealeaf_method = "method";
    public static final String tealeaf_status = "status";
    public static final String tealeaf_reqcancel = "reqcancel";
    public static final String tealeaf_reqdiscard = "reqdiscard";
    public static final String tealeaf_reqsize = "reqsize";
    public static final String tealeaf_rspsize = "rspsize";
    public static final String tealeaf_wstime = "wstime";
    public static final String tealeaf_nttime = "nttime";
    public static final String tealeaf_rttime = "rttime";
    public static final String tealeaf_http_accept = "http_accept";
    public static final String tealeaf_http_accept_lang = "http_accept_lang";
    public static final String tealeaf_http_ua_cpu = "http_ua_cpu";
    public static final String tealeaf_http_accept_encoding = "http_accept_encoding";
    public static final String tealeaf_http_accept_charset = "http_accept_charset";
    public static final String tealeaf_http_connection = "http_connection";
    public static final String tealeaf_http_x_novinet = "http_x_novinet";
    public static final String tealeaf_http_cache_control = "http_cache_control";
    public static final String tealeaf_http_content_length = "http_content_length";
    public static final String tealeaf_http_content_type = "http_content_type";
    public static final String tealeaf_appdata = "appdata";
    public static final String tealeaf_urlfield = "urlfield";
    public static final String tealeaf_cookies = "cookies";
    public static final String RSA_MISSING = "M";

    public static final String tealeaf_datacenter = "data_center_id";
    public static final String tealeaf_application = "application_id";
    public static final String tealeaf_subapplication = "sub_application_id";
    public static final String tealeaf_channel = "channel_id";

    public static final String UTF8_ENCODING = "UTF-8";
    public static final String HIGH_RISK_FT_SCORE = "HIGH_RISK_FT_SCORE";
    //Wire transfer activity-id
    public static final String WIRE_TYPE_DOMESTIC = "Domestic";
    public static final String WIRE_TYPE_INTERNATIONAL = "International";

    public static final int WIRE_DOM_INITIATE = 200;
    public static final int WIRE_DOM_CONFIRM = 201;
    public static final int WIRE_INTL_INITIATE = 202;
    public static final int WIRE_INTL_CONFIRM = 203;

    public static final String wire_dom_init_url = "/wires/controller";
    public static final String wire_dom_init_ref = "InitiateFreeformWireDom";
    public static final String wire_dom_conf_url = "FreeformConfirm";
    public static final String wire_dom_conf_ref = "InitiateFreeformWireDom";

    public static final String wire_intl_init_url = "/wires/controller";
    public static final String wire_intl_init_ref = "InitiateFreeformWireIntl";
    public static final String wire_intl_conf_url = "FreeformConfirm";
    public static final String wire_intl_conf_ref = "InitiateFreeformWireIntl";

    public static final String WLDataSource = "WLFundsTransfer";
    public static final String WLDelimiter = "~";
    public static final String CEOAppId = "CEOW";
    public static final String WLResp = "RESP";
    public static final String requestId = "request_id";
    public static final String requestName = "request_name";
    public static final String wiresLogInput = "wiresLogInput";
    public static final String wiresLogHeader = "wiresLogHeader";
    public static final String inputWithoutHeader = "inputWithoutHeader";
    public static final String originalWLInput = "originalWLInput";
    public static final String transTS = "trans_ts";
    public static final String WLTimeZone = "PST";
    public static final String WLDayLightTimeZone = "PDT";
    public static final String SM_SERVERSESSION_ID = "sm_serversession_id";
    public static final String TRANS_SEQ_ID="trans_seq_id";
    public static final String ACTIMIZE_STATUS="ACTIMIZE_STATUS";

    public static final String qs_encoded_list = "QS_ENCODED_BLACKLIST";
    public static final String qs_pattern_string = "QS_PATTERN_STRING";
    public static final String qs_enable_analysis = "QS_ENABLE";
    public static final String wl_activity_setting = "wl_activity_setting";

	/*
	 * mandatory configurable information for the WireBlock Delay
	 */
	public static final String	ACCOUNT_BLOCK_DELAY_TIMER	       = "ACCOUNT_BLOCK_DELAY_TIMER";
	public static final String	ACCOUNT_BLOCK_DELAY_DATE_FORMAT	   = "ACCOUNT_BLOCK_DELAY_DATE_FORMAT";
	public static final String	TOTAL_AUTOTRIEVE_PARAMETERS_LENGTH	= "TOTAL_AUTOTRIEVE_PARAMETERS_LENGTH";
	public static final String	WIRE_DELAY_TIMEZONE_REQ	           = "WIRE_DELAY_TIMEZONE_REQ";
	public static final String	REG_EX	                           = "REG_EX";
	public static final String	ACCOUNT_NUMBER	                   = "accountNumber";
	public static final String	START_TIME	                       = "startTime";
	public static final String	END_TIME	                       = "endTime";
	public static final String	EVENT_SEQ_ID	                   = "eventSeqID";

	public static final String	WIRE_ID	                           = "transactionSeqID";
	public static final String DATA_LOAD_MODE = "DATA_LOAD_MODE";
	public static final String WIRE_BLOCK_ENABLED = "WIRE_BLOCK_ENABLED";
	public static final String WIRE_BLOCK_AUTOTRIEVE_DELIMITER = "WIRE_BLOCK_AUTOTRIEVE_DELIMITER";


	public static final String ALERT_ID_CFM_DB = "alertID";
	public static final String ALERT_DATE_CFM_DB = "alertDate";
	public static final String ALERT_TYPE_CFM_DB = "alertType";
	public static final String ALERT_CFM_DB = "alert";
	public static final String ALERT_DESCRIPTION_CFM_DB = "alertDescription";
	public static final String CEOSESSION_ID_CFM_DB = "ceoSessionID";
	public static final String COMPANY_CFM_DB = "company";
	public static final String EVENT_DESCRIPTION_CFM_DB = "eventDescription";
	public static final String EVENT_ID_CFM_DB = "eventID";
	public static final String GENERATED_AT_CFM_DB = "generatedAt";
	public static final String IP_ADDRESS_CFM_DB = "ipAddress";
	public static final String LAST_VALUE_CFM_DB = "lastValue";
	public static final String NOTIFICATION_SOURCE_CFM_DB = "notificationSource";
	public static final String RECORD_ID_CFM_DB = "recordID";
	public static final String REPORTING_PERIOD_CFM_DB = "reportedPeriod";
	public static final String TLT_HID_CFM_DB = "tealeafHitID";
	public static final String TLT_SID_CFM_DB = "tealeafSessionID";
	public static final String THRESHOLD_CFM_DB = "threshold";
	public static final String THRESHOLD_TYPE_CFM_DB = "thresholdType";
	public static final String USER_ID_CFM_DB = "userID";
	public static final String VALUE_CFM_DB = "value";
	/*
	 * mandatory configurable parameters from Tealeaf
	 *
	 */
	public static final String ALERT = "alert";
	public static final String ALERT_DATE_TL = "wstime";
	public static final String ALERT_DESCRIPTION_TL = "alertDescription";
	public static final String ALERT_ID_TL = "eventid";
	public static final String ALERT_TYPE_TL = "eventname";
	public static final String EVENT_TL = "eventname";

	public static final String CEOSESSION_ID = "ceoSessionID";
	public static final String EVENT_DESCRIPTION = "eventname";
	public static final String EVENT_ID_TL = "eventid";
	public static final String GENERATED_AT = "generatedAt";
	public static final String LAST_VALUE = "lastValue";
	public static final String NOTIFICATION_SOURCE = "notificationSource";
	public static final String RECORD_ID = "recordID";
	public static final String REPORTED_PERIOD = "reportedPeriod";
	public static final String THRESHOLD = "threshold";
	public static final String THRESHOLD_TYPE = "thresholdType";
	public static final String USERID = "userID";
	public static final String VALUE = "value";
	public static final String ACTIMIZE_HANDLE_ID = "CFM_F0012";
	public static final String ACTIMIZE_LOCATION = "Actimize";
	public static final String ACTIMIZE_CUSTOM_MESSAGE = "Tealeaf Alert Feed";
	public static final String IP_ADDRESS_TL = "ip";
	public static final String TEALEAF_HIT_ID = "tlthid";
	public static final String TEALEAF_SESSION_ID = "tltsid";
	public static final String TEALEAF_WL_CEOPORTAL = "WL_PORTAL";
	public static final String WL_CEOPORTAL_TL = "wlceoportal";

	public static final String PCPRINT_41 = "pcprint";
	public static final String TDL_41 = "tdl";


	public static int ACTIMIZE_IAS_ERROR_CODE_4 = 4;
	public static int ACTIMIZE_IAS_ERROR_CODE_9 = 9;

	/*
	 * mandatory configurable input parameters for Actimize Service(GeneralWS  Service)
	 *
	 */
	public static final String	ALERT_CUSTOM_DATE_1	       = "alert_customDate1";
	public static final String	ALERT_CUSTOM_DATE_2	       = "alert_customDate2";
	public static final String	ALERT_CUSTOM_STRING_1	       = "alert_customString1";
	public static final String	ALERT_CUSTOM_STRING_2	       = "alert_customString2";
	public static final String	ALERT_CUSTOM_STRING_3	       = "alert_customString3";
	public static final String	ALERT_CUSTOM_STRING_4	       = "alert_customString4";
	public static final String	ALERT_CUSTOM_STRING_5	       = "alert_customString5";
	public static final String	ALERT_CUSTOM_STRING_6	       = "alert_customString6";
	public static final String	ALERT_CUSTOM_STRING_7	       = "alert_customString7";
	public static final String	ALERT_CUSTOM_STRING_8	       = "alert_customString8";
	public static final String	ALERT_CUSTOM_STRING_9	       = "alert_customString9";
	public static final String	ALERT_CUSTOM_STRING_10	       = "alert_customString10";
	public static final String	ALERT_CUSTOM_NUMBER_1	       = "alert_customNumber1";
	public static final String	ALERT_CUSTOM_NUMBER_2	       = "alert_customNumber2";
	public static final String	ALERT_MESSAGE_KEY	       = "alert_messageKey";
	public static final String	SESSION_KEY	       = "session_key";
	public static final String	TEALEAF_SESSION_KEY	       = "tealeaf_SessionKey";
	public static final String	CEO_COMPANY_ID	       = "ceo_companyId";
	public static final String	CEO_USER_ID	       = "ceo_userId";
	public static final String	WGC_COMPANY_ID	       = "wgc_companyId";
	public static final String	WGC_USER_ID	       = "wgc_userId";
	public static final String	CASE_ID	       = "case_id";
	public static final String	ALERT_SOURCE	       = "Tealeaf";
	public static final String	PORTAL	       = "portal";
	public static final String	CHANNEL = "channel";
	public static final String	POSSIBLE_RESEND	       = "possible_resend";
	public static final String	SYS_RISK_SCORE	       = "system_riskscore";
	public static final String	RSA_SCORE	       = "rsa_score";
	public static final String SMS_ADDRESS = "smsAddress";
	public static final String CFM = "CFM";
	public static final String TEALEAF = "Tealeaf";
	public static final String CEO = "CEO";
	public static final String ALERT_SHORT_DESCRIPTION = "alert_short_description";

	public static final String IACH_BENENAME = "IACH_BENENAME";
	public static final String IACH_AMOUNT = "IACH_AMOUNT";

	public static final String INDIVIDUAL_NAME = "individualname";
	public static final String AMOUNT = "amount";

	/*
	 * mandatory configurable output parameters from Actimize Service(GeneralWS  Service)
	 *
	 */
	public static final String	ACTIONS_CODE	       = "actions_code";
	public static final String	ALERT_GENERATED_INDICATOR	       = "alert_generted_indicator";
	public static final String	ALERT_PRIORITY	       = "alert_priority";
	public static final String	CALL_STATUS	       = "call_status";
	public static final String	EMAIL_ADDRESS	       = "email_address";
	public static final String	POLICY_RULES_TRIGGERED	       = "policyRules_triggered";
	public static final String	ALERT_SCORE	       = "alert_score";
	public static final String ERROR_CODE = "errorCode";
	public static final String ERROR_REASON="errorReason";

	/** Denotes DataSource type. */
    public static final String TEALEAF_ALERT = "/tealeafAlert";
	public static final String	ALERT_SOURCE_TYPE	       = "ALERT_SOURCE";
	public static final String COOKIE = "cookies";
	public static final String INPUT_FEED = "inputFeed";
	/** Added for previous risk score on 25-4-2011*/
	public static final String FEED_TYPE = "FEED_TYPE";

	public static final String ALERT_FEED = "ALERT_FEED";

	public static final String WIRE_FEED = "WIRE_FEED";

	public static final String SESSION_FEED = "SESSION_FEED";

	public static final String CREATED_TS = "CREATED_TS";

	public static final String CURRENT_CREATED_TS = "CURRENT_CREATED_TS";
	public static final String RSA_PRIOR_RISK_SCORE_FOUND = "RSA_PRIOR_RISK_SCORE_FOUND";
	public static final String RSA_RISK_SCORE = "riskScore";
	public static final String RSA_PREVIOUS_RISK_SCORE = "prevRiskScore";
	public static final String RSA_SCORE_DIFFERENCE = "riskScoreDifference";
	public static final String RSA_SCORE_VARIANCE = "riskScoreVariance";
	public static final String  RSA_SCORE_VARIANCE_LIST_PATTERN = "SCORE_VARIANCE_LIST_PATTERN";

	//additional tealeaf fields


		public static final String HTTP_ACCEPT = "http_accept";
		public static final String HTTP_ACCEPT_LANG = "http_accept_lang";
		public static final String HTTP_UA_CPU = "http_ua_cpu";
		public static final String HTTP_ACCEPT_ENCODING = "http_accept_encoding";
		public static final String HTTP_CONNECTION = "http_connection";
		public static final String HTTP_X_NOVINET = "http_x_novinet";
		public static final String HTTP_CACHE_CONTROL = "http_cache_control";
		public static final String HTTP_CONTENT_LENGTH = "http_content_length";
		public static final String HTTP_CONTENT_TYPE = "http_content_type";
		public static final String HTTP_ACCEPT_CHARSET = "http_accept_charset";
	    public static final String PCA_NAME = "pca_name";
		public static final String HTTP_ACCEPT_LANGUAGE = "http_accept_language";

	// E28 changes
	public static final String TO_MAIL = "TOMAIL";
	public static final String REFERENCE_ID = "referenceID";
	public static final String CEO_COMPANYID = "ceoCompanyId";
	public static final String USERID1 = "userId1";
//E-31 Changes
		public static final String FAILURELOGINSTATUS = "failureloginStatus";
		public static final String FAIL = "FAIL";
/* Change 16 aug 2011 IP change start */
		public static final String PAYMENT_URLS = "PAYMENT_URLS";
	    public static final String LOGIN_SESSION_FOUND = "loginSessionFound";


		public static final String DEV_APP_URL = "DEV_APP_URL";
		public static final String PRE_LOGIN_SESSION_CONFIG =
		        "PRE_LOGIN_SESSION_CONFIG";
		public static final String ACTIMIZE_BEAN = "ACTIMIZE_BEAN";

		public static final String NO = "No";

		public static final String YES = "Yes";

		public static final String PRE_LOGIN_SESSION_FOUND = "preLoginSessionFound";

		public static final String CLICK_STREAM_PAGE_URL = "clickStreamPageUrl";

		public static final String LOGIN_IP_ADDRESS = "loginIpAddress";

		public static final String LOGIN_STATUS = "loginStatus";

		public static final String PRE_LOGIN_IP_ADDRESS = "preLoginIpAddress";

		public static final String PRE_LOGIN_SESSION_URLS =
		        "PRE_LOGIN_SESSION_URLS";
	public static final String ACTIVE_SESSIONS = "activeSessions";

	// DART constants start
	public static final String DART_SESSION_KEY = "SESSION_KEY";

	public static final String DART_TEALEAF_SESSION_KEY = "TEALEAF_SESSION_KEY";

	public static final String DART_TEALEAF_HIT_ID = "TEALEAF_HIT_ID";

	public static final String DART_CEO_COMPANY_ID = "CEO_COMPANY_ID";

	public static final String DART_CEO_USER_ID = "CEO_USER_ID";

	public static final String SESSION_START_DATE_TIME =
	        "SESSION_START_DATE_TIME";

	public static final String IP_ADDRESS = "IP_ADDRESS";

	public static final String HEADER_USER_AGENT = "HEADER_USER_AGENT";

	public static final String HEADER_PROXY_AUTHORIZATION =
	        "HEADER_PROXY_AUTHORIZATION";

	public static final String WGC_COMPANY = "WGC_COMPANY";

	public static final String WGC_USERID = "WGC_USERID";

	public static final String BROWSER_TIMEZONE = "BROWSER_TIMEZONE";

	public static final String CLIENT_SCREEN_RESOLUTION =
	        "CLIENT_SCREEN_RESOLUTION";

	public static final String SECOND_FACTOR_AUTH_IND =
	        "SECOND_FACTOR_AUTH_IND";

	public static final String IS_OTP = "IS_OTP";

	public static final String REJECT_TYPE_CD = "REJECT_TYPE_CD";

	public static final String DART_PRELOGIN_SESSION_FOUND =
	        "PRELOGIN_SESSION_FOUND";

	public static final String IP_CHANGE = "IP_CHANGE";

	public static final String PREVIOUS_IP_ADDRESS = "PREVIOUS_IP_ADDRESS";

	public static final String DART_LOGIN_STATUS = "LOGIN_STATUS";

	public static final String DART_CLICK_STREAM_PAGE_URL =
	        "CLICK_STREAM_PAGE_URL";

	public static final String PARTY_KEY = "PARTY_KEY";

	public static final String DART_LOGIN_SESSION_FOUND = "LOGIN_SESSION_FOUND";

	public static final String DART_RSA_SCORE_PREV = "RSA_SCORE_PREV";

	public static final String DART_RSA_SCORE_VAR = "RSA_SCORE_VAR";

	public static final String DART_RSA_SCORE_DIFF =
	        "RSA_SCORE_DIFF";
	public static final String DART_RSA_PRIOR_FOUND = "RSA_PRIOR_FOUND";

	public static final String RSA_SESSION_RISK_SCORE =
	        "RSA_SESSION_RISK_SCORE";

	public static final String AIS_RETURN_CODE = "AIS_RETURN_CODE";

	public static final String DART_TLTSID = "TLTSID";

	// DART constants End
	public static final String CEO_DOMAIN = "ceo_domain";
	public static final String MOBILE_DOMAIN = "MOBILE_DOMAIN";
	public static final String MOBILE_CHANNEL = "MOBILE";
	public static final String PORTAL_CHANNEL = "PORTAL";
	public static final String VALIDATE_IP_CHANNEL = "VALIDATE_IP_CHANNEL";
	/* Change 16 aug 2011 IP change end */

	//added for schema location
	public static final String WIRES_SCHEMA_LOC = "CFM_WIRES_SCHEMA_PATH";

	//Defect
    /** TeaLeaf COOKIES parameter. */
    public static final String TEALEAF_COOKIES2_PARAM = "cookies2";
    /** TeaLeaf urlfield parameter. */
    public static final String TEALEAF_URLFIELD2_PARAM = "urlfield2";

    // added for data validation refresh interval
	public static final String DATATRIM_REFRESHINTERVAL = "DATATRIM_REFRESHINTERVAL";
	//E96
	public static final String EMPTY_STRING = "";
	public static final String NO_STRING = "N";
	public static final String YES_STRING = "Y";
	public static final String PRE_LOGIN_REFERRER = "preLoginReferrer";
	//
	public static final String ACCOUNT_ENVOY_REFRESH_DURATION= "ACCOUNT_ENVOY_REFRESH_DURATION";
	//E95 Mobile to Portal Switchover
	public static final String MOBILE_TO_POTRAL_URLS = "MOBILE_TO_POTRAL_URLS";
	public static final String MOBILE_TLTSID = "MOBILE_TLTSID";
	public static final String MOBILE_TLTHID = "MOBILE_TLTHID";

	// E83 change
	public static final String RSA_AUTHENTICATION_URLS = "RSA_AUTHENTICATION_URLS";
	public static final String EXCLUDING_REFERRER_URLS = "EXCLUDING_REFERRER_URLS";

	public static final String SIGNON = "signon";
	//ACH
	public static final String ACH_COMPANY_ENVOY_REFRESH_DURATION= "ACH_COMPANY_ENVOY_REFRESH_DURATION";
	public static final String ACH_USER_ENVOY_REFRESH_DURATION= "ACH_USER_ENVOY_REFRESH_DURATION";
	public static final String LOGIN_COMPANY_ENVOY_REFRESH_DURATION ="LOGIN_COMPANY_ENVOY_REFRESH_DURATION";
	public static final String LOGIN_USER_ENVOY_REFRESH_DURATION = "LOGIN_USER_ENVOY_REFRESH_DURATION";
	public static final String PYMT_TRAN_SLEEP_TIME = "PYMT_TRAN_SLEEP_TIME";
	public static final String PYMT_TRAN_CHK_ITERATIONS = "PYMT_TRAN_CHK_ITERATIONS";
	public static final String HIGH_VAL_PYMT_ORIGIN_ID = "HIGH_VAL_PYMT_ORIGIN_ID";
    public static final String TEALTEAF_LOGINURL= "login_url";

	public static final String STAGING_SLEEP_TIME = "STAGING_SLEEP_TIME";

	//E120 - begin
	public static final String PREVIOUS_PRELOGIN_IPS = "previousLoginIPs";
	//E120 - end

	public static final String FULL_SITE_LINK_STATUS = "Full Site Link"; //E98 &122
	public static final String CEO_LOGIN_SUCCESS_STATUS = "CEO Login Success";

	public static final String LOGIN_MOBILE = "Login Mobile";
	public static final String LOGIN_WEB = "Login Web";
	
	public static final String USE_THREAD_SAFE_UNMARSHALLER = "USE_THREAD_SAFE_UNMARSHALLER"; 
	
	public static final String EMAIL_CONTENT_TYPE_HTML = "text/html";
	
	public static final String WCA_PROFILE_WEB_SERVICE_URL = "WCA_PROFILE_WEB_SERVICE_URL";	
	public static final String WCA_PROFILE_EXPIRATION = "WCA_PROFILE_EXPIRATION";
	public static final String RSA_WEB_SERVICE_URL = "RSA_WEB_SERVICE_URL";
	public static final String RSA_WEB_SERVICE_USERNAME = "RSA_WEB_SERVICE_USERNAME";
	public static final String RSA_WEB_SERVICE_PASSWORD = "RSA_WEB_SERVICE_PASSWORD";
	
	public static final String WCA_DO_NOT_PROCESS = "WCA_DO_NOT_PROCESS";
	public static final String WCA_DO_NOT_INVOKE_WEB_SERVICES = "WCA_DO_NOT_INVOKE_WEB_SERVICES";
	public static final String WCA_WEBSERVICE_TIMEOUT = "WCA_WEBSERVICE_TIMEOUT";
	public static final String WCA_MAX_CONNECTIONS = "WCA_MAX_CONNECTIONS";
	public static final String WCA_DO_NOT_SEND_WCA_EVENT_TO_RSA = "WCA_DO_NOT_SEND_WCA_EVENT_TO_RSA";
	public static final String WCA_EVENTS_TO_RISK_SCORE = "WCA_EVENTS_TO_RISK_SCORE";
	
	public static final String WS_APPLICATION_ID = "CFM";
	public static final String WS_BILLING_AU = "0000000";
	public static final String WS_HOST_NAME = "cfmhost";
	public static final String WS_INITIATOR = "cfm";
	public static final String WS_INVOKER_ID = "cfmuser";
	public static final String WS_ORIGINATOR = "cfmoriginator";
	public static final String WS_ORIGINATOR_TYPE = "application";
	public static final String WS_SUB_APPLICATION_ID = "cfmsubappid";
	public static final String WS_GL_ENTITY = "000000";

	// Start : E-133 : 08082013
	public static final String UA_DEVICE_TYPE = "UA_DEVICE_TYPE";
	public static final String UA_BROWSER_VERSION = "UA_BROWSER_VERSION";
	public static final String UA_BROWSER_TYPE = "UA_BROWSER_TYPE";
	public static final String UA_MANUFACTURER = "UA_MANUFACTURER";
	public static final String UA_OS_VERSION = "UA_OS_VERSION";
	public static final String UA_OPERATION_SYSTEM = "UA_OPERATION_SYSTEM";
	public static final String WCA_DOC_LINK = "WCA_DOC_LINK";
	
	// End : E-133 : 08082013
	
	// Start: E-140 : 10092013
	public static final String ANDROID = "Android";
	public static final String IOS = "iOS";
	public static final String SDK_HARDWARE_ID = "HardwareID";
	public static final String SDK_SIM_ID = "SIM_ID";
	public static final String SDK_PHONE_NUMBER = "PhoneNumber";
	public static final String SDK_LOCATION_AREA_CODE = "LocationAreaCode";
	public static final String SDK_COUNTRY_CODE = "SdkCountryCode";
	 
	// End: E-140 : 10092013
	
	public static String FORTY_FIRST_LICENSE_FILE_NAME = "FORTY_FIRST_LICENSE_FILE_NAME";
	public static String FORTY_FIRST_RECIPE = "FORTY_FIRST_RECIPE";
	public static String DEFAULT_FORTY_FIRST_RECIPE = "ISOLATED_4_3_S";
	
	public static String BASE64 = "BASE64-";
	//E147
	public static final String MISSING_IN_LOGIN = "Missing in login";		
	public static final String MISSING_IN_TRANSACTION = "Missing in transaction";	
	public static final String COMPLETELY_MISSING = "Completely missing";
	public static final String MISMATCHED = "Mismatched";
	public static final String MATCHED = "Matched";

}

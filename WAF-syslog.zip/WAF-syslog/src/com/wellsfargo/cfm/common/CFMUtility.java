/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import com.wellsfargo.cfm.exception.AppException;


/**
 * CFM Utility class for providing utility methods.
 * 
 * @author Daniel Barraza
 * @version 1.0
 * 
 *          History Changes:
 * 
 *          Date Author Description ---- ------ ----------- 06/26/09 DMB Initial, add parseNVP method to provide NVP.
 * 
 * 
 */

public class CFMUtility {

	/**
	 * Used for logging purpose.
	 */
	private static final Logger logger = Logger.getLogger(CFMUtility.class);

	/**
	 * Processes data and converts it to a HashMap.
	 * 
	 * @param requestString
	 * @param dataSource
	 * @return Object
	 */
	public static Map<String, String> parseNVP(String requestString, String nvpDelimeter, String nvpFieldDelimeter)
			throws AppException {
		logger.debug("CFMUtility.parseNVP() start");
		Map<String, String> requestdata = new HashMap<String, String>();

		// STEP 1 : Parse the NVP data and convert it into the HashMap.
		StringTokenizer requestTokenizer = new StringTokenizer(requestString, nvpDelimeter);
		StringTokenizer nvpTokenizer = null;
		String nvpPair = null;
		while (requestTokenizer.hasMoreTokens()) {
			nvpPair = requestTokenizer.nextToken();
			if (nvpPair != null) {
				nvpTokenizer = new StringTokenizer(nvpPair, nvpFieldDelimeter);
				while (nvpTokenizer.hasMoreTokens()) {
					String requestDataKey = nvpTokenizer.nextToken();
					if (requestDataKey != null) {
						String nextToken = "";
						if (nvpTokenizer.hasMoreTokens()) {
							nextToken = nvpTokenizer.nextToken();
						}
						requestdata.put(requestDataKey, nextToken);
					} else {
						logger.error("Invalid request received");
						throw new AppException("Invalid request received");
					}
				}
			}
		}
		logger.debug("CFMUtility.parseNVP() end");
		return requestdata;
	} // parseNVP

	public static boolean isURLFound(String input, String[] URLS) {
		// Enhancement to support null URLs begin
		if (URLS != null) {
			for (String loginUrl : URLS) {
				if (input.contentEquals(loginUrl))
					return true;
			}
		}
		// Enhancement to support null URLs end
		return false;
	}

	public static String[] splitValues(String input, String delimiter) {
		if (input != null && input.length() > 0) {
			String[] values = input.split(delimiter);
			for (int i = 0; i < values.length; i++)
				values[i] = values[i].trim();
			return values;
		}
		return null;
	}

	
} // CFMUtility


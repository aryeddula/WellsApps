/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.cfm.jmsclient;

import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.wellsfargo.cfm.common.JMSConstants;
import com.wellsfargo.cfm.exception.JMSClientException;

/**
 * This class is a Utility class used to send JMS Messages.
 * @author Syntel
 * @version 1.0
 */
public class JMSClient {
    /** For logging purpose. */
    private static final Logger logger = Logger.getLogger(JMSClient.class);

    /** Initial Context of server where MDB is deployed. */
    protected InitialContext context = null;

    /** Connection factory JNDI name. */
    private String cfJndiName;
    
    private String popParam(Map<String, String> params, String key)
    {
    	String value = params.get(key);
    	params.remove(key);
    	return value;
    }

    /**
     * Initializes the JMSClient.
     * @param initParams
     * @throws JMSClientException
     *             JMSClient specific exception.
     */
    protected final void initClient(Map < String, String > initParams)
            throws JMSClientException {
        //logger.debug("JMSClient.initClient() start");
        String jndiProviderUrl = popParam(initParams, JMSConstants.JNDI_PROVIDER_URL);
        String initialContextFactory = popParam(initParams, JMSConstants.INITIAL_CONTEXT_FACTORY);
        String securityCredential = popParam(initParams, JMSConstants.SECURITY_CREDENTIALS);
        String securityPrincipal = popParam(initParams, JMSConstants.SECURITY_PRINCIPAL);
        String strCfJndi = popParam(initParams, JMSConstants.CONNECTION_FACTORY_JNDI);

        if (logger.isDebugEnabled()){
	        logger.debug("JMSClient.initClient() jndiProviderUrl - " + jndiProviderUrl);
	        logger.debug("JMSClient.initClient() initialContextFactory - " + initialContextFactory);
//	        logger.debug("JMSClient.initClient() securityCredential - " + securityCredential);
//	        logger.debug("JMSClient.initClient() securityPrincipal - " + securityPrincipal);
	        logger.debug("JMSClient.initClient() strCfJndi - " + strCfJndi);
        }
        if (jndiProviderUrl == null) {
            logger.debug("JNDI Provider URL is null");
            //throw new JMSClientException("JNDI Provider URL is null");
        }
        if (initialContextFactory == null) {
            logger.error("Initial Context Factory is null");
            throw new JMSClientException("Initial Context Factory is null");
        }
        if (strCfJndi == null) {
            logger.error("Connection Factory JNDI name is null");
            throw new JMSClientException("Connection Factory JNDI name is null");
        }

        // initialize params with remaining extra parameters 
        Hashtable < String, String > params = new Hashtable < String, String >(initParams);
        if (null != initialContextFactory)
        	params.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
        
//        if ("weblogic.jndi.WLInitialContextFactory".equalsIgnoreCase(initialContextFactory)){
//        	//continue
//        } else {
//        	params.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
//        }
        
        if (null != jndiProviderUrl ) {
        	params.put(Context.PROVIDER_URL, jndiProviderUrl);
        }

        if (securityPrincipal != null) {
            params.put(Context.SECURITY_PRINCIPAL, securityPrincipal);
        }
        
        if (securityCredential != null)
            params.put(Context.SECURITY_CREDENTIALS, securityCredential);

        try {
        	if (params.size() > 0){
        		context = new InitialContext(params);
        	} else { 
        		context = new InitialContext();
        	}

        } catch (NamingException e) {
            JMSClientException exception = new JMSClientException(e);
            throw exception;
        }

        this.cfJndiName = strCfJndi;
        //logger.debug("JMSClient.initClient() end");
    }

    /**
     * Initializes the JMSClient.
     * @param queueJNDI
     * @throws JMSClientException
     *             JMSClient specific exception.
     */
    protected final void initClient(String cfJNDI)
            throws JMSClientException {
        if (cfJNDI == null) {
            logger.error("Connection Factory JNDI name is null");
            throw new JMSClientException("Connection Factory JNDI name is null");
        }

        try {
            context = new InitialContext();

        } catch (NamingException e) {
            JMSClientException exception = new JMSClientException(e);
            throw exception;
        }

        this.cfJndiName = cfJNDI;
        //logger.debug("JMSClient.initClient() end");
    }

    
    /**
     * Closes the initial context.
     * @throws JMSClientException
     *             JMSClient specific exception.
     */
    protected final void destroyClient() throws JMSClientException {
       // logger.debug("JMSClient.destroyClient() start");
        try {
            if (context != null) {
                context.close();
            }
        } catch (NamingException e) {
            JMSClientException exception = new JMSClientException(e);
            throw exception;
        }
        //logger.debug("JMSClient.destroyClient() end");
    }

    /**
     * Getter for connection factory JNDI name.
     * @return the cfJndiName
     */
    protected final String getCfJndiName() {
        return cfJndiName;
    }
}

/*
 * Copyright (c) 2000-2009 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.cfm.jmsclient;

import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.naming.NamingException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.cfm.common.JMSConstants;
import com.wellsfargo.cfm.exception.JMSClientException;

/**
 * This class is used for sending the JMS messages to Queue.
 * 
 * @author Syntel
 * @version 1.0
 */
public final class JMSQueueClient extends JMSClient {

	/** For logging purpose. */
	private static final Logger logger = Logger.getLogger(JMSQueueClient.class);

	/** Connection object for establishing connection with Queue. */
	private QueueConnection connection = null;

	/** Queue object. */
	private Queue queue = null;

	/** Used for sending messages to queue. */
	private QueueSender sender;

	/** Used for creating message and queueSender. */
	private QueueSession session;

	/**
	 * Used for establishing connection with Queue.
	 * 
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	private void createQueueConnection() throws JMSClientException {
		// logger.debug("JMSQueueClient.createQueueConnection() start");
		QueueConnectionFactory factory;

		try {
			if (super.getCfJndiName() != null) {
				factory = (QueueConnectionFactory) super.context.lookup(super.getCfJndiName());
				connection = factory.createQueueConnection();
			} else {
				logger.error("Queue Connection Factory name is null");
				throw new JMSClientException("Queue Connection Factory name is null");
			}
		} catch (NamingException e) {
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		} catch (JMSException e) {
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createQueueConnection() end");
	}

	/**
	 * Initializes JMSQueueClient by looking up Queue, creating QueueSender.
	 * 
	 * @param initParams
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public void initQueueClient(Map<String, String> initParams) throws JMSClientException {
		// logger.debug("JMSQueueClient.initQueueClient() start");
		super.initClient(initParams);
		createQueueConnection();

		String queueJndiName = initParams.get(JMSConstants.DESTINATION_JNDI);

		if (queueJndiName == null) {
			logger.error("Destination Queue JNDI Name is null.");
			throw new JMSClientException("Destination Queue JNDI Name is null.");
		}

		try {
			queue = (Queue) context.lookup(queueJndiName);
		} catch (NamingException e) {
			logger.error("Naming exception in JMSqueueCLient");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}

		try {
			// logger.debug("Before creating queue session");
			session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			sender = session.createSender(queue);
			/*
			 * sender.setDeliveryMode(DeliveryMode.PERSISTENT);
			 * sender.setPriority(7); sender.setTimeToLive(30000);
			 * 
			 * This way we can specify the message priority, message timeout &
			 * delivery mode as persistent or non-persistent. Default is
			 * persistent. Also we can set it with
			 * client @com.wellsfargo.cfm.sender.impl.
			 * ACHDispositionMessageSender
			 */
			logger.debug("After creating queue sender");
		} catch (JMSException e) {
			logger.error("JMSException in JMSqueueCLient");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.initQueueClient() end");
	}

	/**
	 * Initializes JMSQueueClient by looking up Queue, creating QueueSender.
	 * 
	 * @param queueJNDI
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public void initQueueClient(String cfJNDI, String queueJndiName) throws JMSClientException {
		// logger.debug("JMSQueueClient.initQueueClient() start");
		super.initClient(cfJNDI);
		createQueueConnection();

		if (queueJndiName == null) {
			logger.error("Destination Queue JNDI Name is null.");
			throw new JMSClientException("Destination Queue JNDI Name is null.");
		}

		try {
			queue = (Queue) context.lookup(queueJndiName);
		} catch (NamingException e) {
			logger.error("Naming exception in JMSqueueCLient");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}

		try {
			// logger.debug("Before creating queue session");
			session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			sender = session.createSender(queue);
			logger.debug("After creating queue sender");
		} catch (JMSException e) {
			logger.error("JMSException in JMSqueueCLient");
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.initQueueClient() end");
	}

	/**
	 * Sends the message to the queue.
	 * 
	 * @param message
	 *            to be sent to MDB
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public void sendMessage(Message message) throws JMSClientException {
		// logger.debug("JMSQueueClient.sendMessage() start");
		try {
			connection.start();
			sender.send(message);
			connection.stop();
		} catch (JMSException e) {
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		} finally {
			destroyQueueClient();
		}
		// logger.debug("JMSQueueClient.sendMessage() end");
	}

	public void sendMessage(Message message, int priority) throws JMSClientException {
		this.sendMessage(message, Message.DEFAULT_DELIVERY_MODE, priority, Message.DEFAULT_TIME_TO_LIVE);
	}

	public void sendMessage(Message message, int deliveryMode, int priority, long timeToLive)
			throws JMSClientException {
		// logger.debug("JMSQueueClient.sendMessage() start");
		try {
			connection.start();
			sender.send(message, deliveryMode, priority, timeToLive);
			connection.stop();
		} catch (JMSException e) {
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		} finally {
			destroyQueueClient();
		}
		// logger.debug("JMSQueueClient.sendMessage() end");
	}

	/**
	 * Closes all the open senders, connections and sessions.
	 * 
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	private void destroyQueueClient() throws JMSClientException {
		// logger.debug("JMSQueueClient.destroyQueueClient() start");
		super.destroyClient();

		try {
			if (sender != null) {
				sender.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}

		try {
			if (session != null) {
				session.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}

		try {
			if (connection != null) {
				connection.close();
			}
		} catch (JMSException e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		// logger.debug("JMSQueueClient.destroyQueueClient() end");
	}

	/**
	 * Creates the Object message.
	 * 
	 * @return MapMessage to be sent to MDB
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public ObjectMessage createObjectMessage() throws JMSClientException {
		// logger.debug("JMSQueueClient.createObjectMessage() start");
		ObjectMessage message = null;
		try {
			message = session.createObjectMessage();
		} catch (JMSException e) {
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createObjectMessage() end");
		return message;
	}

	/**
	 * Creates the Map message.
	 * 
	 * @return ObjectMessage to be sent to MDB.
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public MapMessage createMapMessage() throws JMSClientException {
		MapMessage message = null;
		// logger.debug("JMSQueueClient.createMapMessage() start");
		try {
			message = session.createMapMessage();
		} catch (JMSException e) {
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createMapMessage() end");
		return message;
	}

	/**
	 * Creates the Bytes message.
	 * 
	 * @return BytesMessage to be sent to MDB.
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public BytesMessage createBytesMessage() throws JMSClientException {
		BytesMessage message = null;
		// logger.debug("JMSQueueClient.createBytesMessage() start");
		try {
			message = session.createBytesMessage();
		} catch (JMSException e) {
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createBytesMessage() end");
		return message;

	}

	/**
	 * Creates the Text message.
	 * 
	 * @return TextMessage to be sent to MDB.
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public TextMessage createTextMessage() throws JMSClientException {
		TextMessage message = null;
		// logger.debug("JMSQueueClient.createTextMessage() start");
		try {
			message = session.createTextMessage();
		} catch (JMSException e) {
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createTextMessage() end");
		return message;
	}

	/**
	 * Creates the Stream message.
	 * 
	 * @return StreamMessage to be sent to MDB.
	 * @throws JMSClientException
	 *             JMSClient specific exception.
	 */
	public StreamMessage createStreamMessage() throws JMSClientException {
		StreamMessage message = null;
		// logger.debug("JMSQueueClient.createStreamMessage() start");
		try {
			message = session.createStreamMessage();
		} catch (JMSException e) {
			destroyQueueClient();
			JMSClientException exception = new JMSClientException(e);
			throw exception;
		}
		// logger.debug("JMSQueueClient.createStreamMessage() end");
		return message;
	}
}

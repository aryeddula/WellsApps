/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;

import org.apache.log4j.Logger;

import com.wellsfargo.cfm.exception.JMSClientException;

/**
 * @author zhushiwe
 *
 */
public class CFMLiteMessageTimer implements Runnable {

	private boolean stopped = false;
	
	private static final Logger logger = Logger.getLogger(CFMLiteMessageTimer.class);
	
	public CFMLiteMessageTimer() {
		// TODO Auto-generated constructor stub
		
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		logger.trace("Entering CFMLite flush timer...");
		while (!stopped && CFMLiteProperties.getBoolean("cfmLite.timer.enabled")) {
			try {
				Thread.sleep(CFMLiteProperties.getIntProperty("cfmLite.timer.frequency"));
				Object msg = MessageHandler.getInstance().getConsolidatedMessages();
				if (msg != null) {
					logger.trace("flushing message buffer...");
					new CFMLiteJMSHandler().send(msg);
				}
			} catch (InterruptedException e) {
				logger.debug("Thread interrupted!");
				e.printStackTrace();
			} catch (JMSClientException e) {
				logger.debug("Failed to flush the message buffer");
				e.printStackTrace();
			}
		}
		logger.debug("Exiting CFMLite flush timer");
	}
	
	public void stopTimer() {
		stopped = true;
	}

}

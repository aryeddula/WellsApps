/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;


/**
 * @author zhushiwe
 *
 */
public class MessageHandler {
	
	private static MessageHandler INSTANCE = new MessageHandler();
	
	private MessageBufferIntf buffer;
	
	
	private MessageHandler()
	{
		buffer = new PrioritizedMessageBuffer();
		buffer.setSize(CFMLiteProperties.getIntProperty("cfmLite.buffer.size", 10));
	}
	
	public static MessageHandler getInstance() {
		return INSTANCE;
	}
	
	public void addMessage(String sourceURL, String message) {
		buffer.addMessage(sourceURL, message);
	}
	
	public synchronized Object getConsolidatedMessages(int msgCount) {
		Object retVal = null;
		
		buffer.setSize(msgCount);
		if (buffer.isFull()) {
			retVal = buffer.getBufferedMessages();
		}
		
		return retVal;
	}
	
	/**
	 * Returns all messages yet to be sent
	 * @return
	 */
	public synchronized Object getConsolidatedMessages() {
		return buffer.getBufferedMessages();
	}
}

/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;

import java.io.Serializable;

public class CFMLiteMessageDTO implements Serializable {

	private static final long serialVersionUID = -6563127267643982705L;
	
	private String sourceURL;
	private int priority;
	private long messageID;
	private Object message;
	
	public CFMLiteMessageDTO(String sourceURL, Object msg, int priority, long id) {
		this.sourceURL = sourceURL;
		this.message = msg;
		this.priority = priority;
		this.messageID = id;
	}
	
	public long getMessageID() {
		return messageID;
	}

	public int getPriority() {
		return this.priority;
	}
	
	public void setMessageID(long messageID) {
		this.messageID = messageID;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public Object getMessage() {
		return this.message;
	}
	
	public void setMessage(Object message) {
		this.message = message;
	}

	public String getSourceURL() {
		return sourceURL;
	}

	public void setSourceURL(String sourceURL) {
		this.sourceURL = sourceURL;
	}

	@Override
	public boolean equals(Object obj) {
		boolean equals = false;
		if (obj instanceof CFMLiteMessageDTO) {
			CFMLiteMessageDTO other = (CFMLiteMessageDTO) obj;
			equals = this.messageID == other.getMessageID() &&
					 this.priority == other.getPriority() &&
					 ((this.sourceURL != null && this.sourceURL.equalsIgnoreCase(other.getSourceURL())) ||
					   this.sourceURL == other.getSourceURL()) &&
					 ((this.message != null && this.message.equals(other.getMessage())) ||
					   this.message == other.getMessage());
		}
		return equals;
	}
}
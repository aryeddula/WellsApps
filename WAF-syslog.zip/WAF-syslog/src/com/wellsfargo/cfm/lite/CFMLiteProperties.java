/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.log4j.Logger;

import com.wellsfargo.cfm.common.ProducerAppConstants;

/**
 * @author zhushiwe
 * 
 */
public class CFMLiteProperties {
	private static final String CFMLITE_PROP_FILENAME = "cfmLite.properties";
	
	private static PropertiesConfiguration props;
	
	private static Logger logger = Logger.getLogger(CFMLiteProperties.class);
	
	static {
		load();
	}
	
	private static void load() {
		String propFilePath = System.getProperty(ProducerAppConstants.CFM_PROPS_DIR);
		String fname = propFilePath + CFMLITE_PROP_FILENAME;
		try {
			props = new PropertiesConfiguration(fname);
			props.setReloadingStrategy(new FileChangedReloadingStrategy());
		} catch (ConfigurationException e) {
			logger.debug("failed to load " + fname);
			e.printStackTrace();
		}
	}
	
	public static String getProperty(String key) {
		return  props.getString(key);
	}
	
	public static String getProperty(String key, String defaultValue) {
		return props.getString(key, defaultValue);
	}
	
	public static int getIntProperty(String key, int defaultValue) {
		return props.getInt(key, defaultValue);
	}
	
	public static int getIntProperty(String key) {
		return props.getInt(key);
	}
	
	/**
	 * Returns a boolean value for the key. If no match is found for the key, returns false.
	 * @param key
	 * @return
	 */
	public static boolean getBoolean(String key) {
		return props.getBoolean(key, false);
	}
}

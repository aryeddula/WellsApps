/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;

import org.apache.log4j.Logger;

import com.wellsfargo.cfm.common.DataCompressor;
import com.wellsfargo.cfm.common.JMSConstants;
import com.wellsfargo.cfm.exception.JMSClientException;
import com.wellsfargo.cfm.jmsclient.JMSQueueClient;

/**
 * @author zhushiwe
 *
 */
public class CFMLiteJMSHandler {
	
	private static final Logger logger = Logger.getLogger(CFMLiteJMSHandler.class);
	
	private JMSQueueClient queueClient;
	

	public CFMLiteJMSHandler() throws JMSClientException {
		
		queueClient = new JMSQueueClient();
		// Try the direct forward first, then SAF if direct send is unavailable.
		boolean useSAF = CFMLiteProperties.getBoolean("cfmLite.useSAF");
		Map<String, String> configs = useSAF ? getSafJMSQueueConfig() : getDirectJMSQueueConfig();
		try {
			queueClient.initQueueClient(configs);
		} catch (JMSClientException ex) {
			if (!useSAF) {
				logger.debug("Force to use SAF queue", ex);
				queueClient.initQueueClient(getSafJMSQueueConfig());
			} else
				throw ex;
		}
	}
	

	private Map<String, String> getSafJMSQueueConfig() {
		HashMap<String, String> configMap = new HashMap<String, String>();
		
		configMap.put(JMSConstants.JNDI_PROVIDER_URL, CFMLiteProperties.getProperty("cfmLite.saf.jndi.provider"));
		configMap.put(JMSConstants.INITIAL_CONTEXT_FACTORY, CFMLiteProperties.getProperty("cfmLite.saf.initial.context.factory"));
		configMap.put(JMSConstants.SECURITY_CREDENTIALS, CFMLiteProperties.getProperty("cfmLite.saf.security.credentials"));
		configMap.put(JMSConstants.SECURITY_PRINCIPAL, CFMLiteProperties.getProperty("cfmLite.saf.security.principal"));
		configMap.put(JMSConstants.CONNECTION_FACTORY_JNDI, CFMLiteProperties.getProperty("cfmLite.saf.connection.factory.jndi"));
		configMap.put(JMSConstants.DESTINATION_JNDI, CFMLiteProperties.getProperty("cfmLite.saf.destination.jndi"));
		
		return configMap;
	}


	private Map<String, String> getDirectJMSQueueConfig() {
		HashMap<String, String> configMap = new HashMap<String, String>();
		
		configMap.put(JMSConstants.JNDI_PROVIDER_URL, CFMLiteProperties.getProperty("cfmLite.direct.jndi.provider"));
		configMap.put(JMSConstants.INITIAL_CONTEXT_FACTORY, CFMLiteProperties.getProperty("cfmLite.direct.initial.context.factory"));
		configMap.put(JMSConstants.SECURITY_CREDENTIALS, CFMLiteProperties.getProperty("cfmLite.direct.security.credentials"));
		configMap.put(JMSConstants.SECURITY_PRINCIPAL, CFMLiteProperties.getProperty("cfmLite.direct.security.principal"));
		configMap.put(JMSConstants.CONNECTION_FACTORY_JNDI, CFMLiteProperties.getProperty("cfmLite.direct.connection.factory.jndi"));
		configMap.put(JMSConstants.DESTINATION_JNDI, CFMLiteProperties.getProperty("cfmLite.direct.destination.jndi"));
		
		return configMap;
	}
	
	public void send(Object message) {
		//TODO debugging purposes, remove later
		String concatedMsg = "";
		boolean highPriorityPackage = false;
		int lowPriorityVal = Integer.MAX_VALUE;
		for (CFMLiteMessageDTO msg : (ArrayList<CFMLiteMessageDTO>) message) {
			logger.trace("About to send msg - Message ID: " + msg.getMessageID()  + ", Priority: " + msg.getPriority());
			lowPriorityVal = Math.min(msg.getPriority(), lowPriorityVal);
			concatedMsg += (String) msg.getMessage() + "|";
		}
		highPriorityPackage = lowPriorityVal <= CFMLiteProperties.getIntProperty("cfmLite.msg.priority.threshold");
		
		try {
			Message jmsMessage = null;
			if (CFMLiteProperties.getBoolean("cfmLite.msg.concat")) {
				BytesMessage bMessage = queueClient.createBytesMessage();
				boolean compress = CFMLiteProperties.getBoolean("cfmLite.msg.concat.compress");
				byte[] compressedMsg = compress ? DataCompressor.zipStringToBytes(concatedMsg) : concatedMsg.getBytes();
				bMessage.writeBytes(compressedMsg);
				bMessage.setBooleanProperty("Compressed", compress);
				jmsMessage = bMessage;
				queueClient.sendMessage(jmsMessage);
			} else {
				ObjectMessage objMessage = queueClient.createObjectMessage();
				objMessage.setObject((Serializable) message);
				jmsMessage = objMessage;
				int priority = highPriorityPackage ? 9 : Message.DEFAULT_PRIORITY;
				queueClient.sendMessage(jmsMessage, priority);
			}
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JMSClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

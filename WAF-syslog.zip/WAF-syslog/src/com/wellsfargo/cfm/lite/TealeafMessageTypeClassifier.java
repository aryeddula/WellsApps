/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.lite;

import com.wellsfargo.cfm.common.CFMProperties;
import com.wellsfargo.cfm.common.CFMUtility;

/**
 * @author zhushiwe
 *
 */
public class TealeafMessageTypeClassifier {
	
	public final static int UNKNOWN = 0;
	public final static int LOGIN = 1;
	public final static int WIRES = 2;
	
	public static int getMessageType(String url) {
		int type = UNKNOWN;
		
		if (url != null)
		{
			if(CFMUtility.isURLFound(url,CFMProperties.getLoginURLS()) || CFMUtility.isURLFound(url,CFMProperties.getRedirectLoginURLS()) 
					||CFMUtility.isURLFound(url,CFMProperties.getLogoutURL()))
				type = LOGIN;
			else if(url.contains("FreeformConfirm") || url.equalsIgnoreCase("/wires/controller")) 
				type = WIRES;
		}
		
		return type;
	}
	
}

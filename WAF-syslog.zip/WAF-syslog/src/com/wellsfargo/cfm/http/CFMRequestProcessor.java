package com.wellsfargo.cfm.http;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.wellsfargo.cfm.common.TealeafMessageUtility;

public class CFMRequestProcessor {

	private static final Logger logger = Logger.getLogger("CFMLiteLogger");

	public static void processRequest(String requestString) {
        try {
			HashMap msgMap = TealeafMessageUtility.parseMessage(requestString);
			String sid = (String) msgMap.get("tltsid");
			String hid = (String) msgMap.get("tlthid");
			logger.debug("CFMRequestProcessor Received message: sid = " + sid + " , hid=" + hid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

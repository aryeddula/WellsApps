/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.http;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.log4j.Logger;

/**
 * @author zhushiwe
 *
 */
public class HTTPPostClientWorker implements Runnable {
	
	private static final Logger logger = Logger.getLogger(HTTPPostClientWorker.class);
	
	private String url;
	private String requestBody;
	private NameValuePair[] params;
	private HttpClient client;
	
	public HTTPPostClientWorker(String url, String body, NameValuePair[] params, HttpClient client) {
		this.url = url;
		this.requestBody = body;
		this.params = params;
		this.client = client;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		PostMethod method = new PostMethod(url);
		
		try {
			if (params != null)
				method.setQueryString(params);
			method.setRequestEntity(new StringRequestEntity(requestBody, "text/plain", null));
			int status = client.executeMethod(method);
			if (status != HttpStatus.SC_OK) {
				logger.error("Post returns error code: " + status);
			}
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (HttpException e) {
			logger.error("HTTP Post failed...");
			e.printStackTrace();
		} catch (IOException e) {
			logger.error("HTTP Post failed...");
			e.printStackTrace();
		} finally {
			method.releaseConnection();
		}
		
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}

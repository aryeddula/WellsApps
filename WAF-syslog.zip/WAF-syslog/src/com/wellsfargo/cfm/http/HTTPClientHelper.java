/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.cfm.http;

import java.util.HashMap;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethodRetryHandler;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.httpclient.params.HttpMethodParams;

import com.wellsfargo.cfm.lite.CFMLiteProperties;

/**
 * @author zhushiwe
 *
 */
public class HTTPClientHelper {
	
	private static HashMap<String, HttpClient> clientsMap = new HashMap<String, HttpClient> ();
	
	/**
	 * An convenience method to get an HttpClient instance for CFMLite. Corresponding parameters are read from CFMLiteProperties.
	 * @return
	 */
	public static HttpClient getCFMLitePostClient() {
    	String cfmURL = CFMLiteProperties.getProperty("cfm.servlet.url");
    	HttpClient cfmLitePostClient = HTTPClientHelper.getClient(cfmURL, 
    			CFMLiteProperties.getIntProperty("cfmLite.post.maxConnections", 10),
    			new DefaultHttpMethodRetryHandler(CFMLiteProperties.getIntProperty("cfmLite.post.maxRetry", 10), false));

		return cfmLitePostClient;
	}
	
	/**
	 * Returns the HttpClient instance for the specified destination url. If the instance has already been created, it will
	 * be reused, and the other 2 parameters are ignored; otherwise, a new instance will be created with the maxConnections
	 * and MethodRetryHandler, and it is managed by MultiThreadedHttpConnectionManager for sharing among multiple threads executing
	 * on this HttpClient.
	 * @param url URL for the http method
	 * @param maxConnections max # of connection for the host
	 * @return
	 */
	public static HttpClient getClient(String url, int maxConnections, HttpMethodRetryHandler retryHandler) {
		HttpClient client = clientsMap.get(url);
		if (client == null) {
			MultiThreadedHttpConnectionManager connMgr = new MultiThreadedHttpConnectionManager();
			HostConfiguration hostConfig = new HostConfiguration();
			HttpConnectionManagerParams params = new HttpConnectionManagerParams();
			try {
				hostConfig.setHost(new URI(url, false));
				params.setMaxConnectionsPerHost(hostConfig, maxConnections);
			} catch (Exception e) {
				e.printStackTrace();
			}
			connMgr.setParams(params );
			client = new HttpClient(connMgr);
			client.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, retryHandler);
			clientsMap.put(url, client);
		} else {
			//TODO change the maxConnections per host
		}
		return client;
	}
	
	public static void recycleClient(String url) {
		HttpClient client = clientsMap.get(url);
		if (client != null) {
			clientsMap.remove(url);
		}
	}
}

package com.wellsfargo.waf.syslog;


import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.SyslogServerIF;
import org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

import com.wellsfargo.cfm.common.JMSConstants;
import com.wellsfargo.cfm.exception.JMSClientException;
import com.wellsfargo.cfm.jmsclient.JMSQueueClient;
import com.wellsfargo.waf.WAFProperties;
import com.wellsfargo.waf.util.Encryptor;
import com.wellsfargo.waf.util.WAFEventUtility;

public class JMSSyslogServerEventHandler implements SyslogServerSessionlessEventHandlerIF {

	private Logger logger = Logger.getLogger(getClass());
	private Logger perfLogger = Logger.getLogger("perfLogger");
	
	private JMSQueueClient queueClient;
	private String wwafCredential;


	private Map<String, String> getJMSQueueConfig() {
		HashMap<String, String> configMap = new HashMap<String, String>();
		
		configMap.put(JMSConstants.JNDI_PROVIDER_URL, WAFProperties.getProperty("waf.jndi.provider"));
		configMap.put(JMSConstants.INITIAL_CONTEXT_FACTORY, WAFProperties.getProperty("waf.initial.context.factory"));
		configMap.put(JMSConstants.SECURITY_PRINCIPAL, WAFProperties.getProperty("waf.security.principal"));
		if (wwafCredential != null)
			configMap.put(JMSConstants.SECURITY_CREDENTIALS, wwafCredential);
		configMap.put(JMSConstants.CONNECTION_FACTORY_JNDI, WAFProperties.getProperty("waf.connection.factory.jndi"));
		configMap.put(JMSConstants.DESTINATION_JNDI, WAFProperties.getProperty("waf.destination.jndi"));
		
		// Solace additions
/*		String vpn = WAFProperties.getProperty("solace.vpn");
		if (vpn != null)
			configMap.put(SupportedProperty.SOLACE_JMS_VPN, vpn);
		String compression = WAFProperties.getProperty("solace.compression");
		if (compression != null)
			configMap.put(SupportedProperty.SOLACE_JMS_COMPRESSION_LEVEL, compression);*/
		
		return configMap;
	}
	
	private String getDecryptedCredentials(String encrypted) {
		String decrypted = "";
		try {
			Encryptor enc = Encryptor.getInstance();
			decrypted = enc.decrypt(encrypted);
		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		} 
		
		logger.trace("credential decrypted...");
		
		return decrypted;
	}
	
	@Override
	public void initialize(SyslogServerIF syslogServer) {
		//set credentials once on init, as decryption on each every event may be costly,
		// and the credential also needs to be in sync with SAF remote context on WLS, which requires a WLS restart anyway.
		wwafCredential = getDecryptedCredentials(WAFProperties.getProperty("waf.security.credentials"));
	}
	
/*
	private void initQueueClient() {
		logger.trace("in JMSSyslogServerEventHandler.init()");
		
		queueClient = new JMSQueueClient();
		Map<String, String> configs = getJMSQueueConfig();
		
		try {
			queueClient.initQueueClient(configs);
		} catch (JMSClientException ex) {
			logger.error(ExceptionUtils.getStackTrace(ex));
		}
	}
*/
	
	@Override
	public void destroy(SyslogServerIF syslogServer) {
		// TODO Auto-generated method stub

	}

	@Override
	public void event(SyslogServerIF syslogServer, SocketAddress socketAddress,
			SyslogServerEventIF event) {
		if (!WAFEventUtility.isValidEventSource(socketAddress, event) ||
			!WAFEventUtility.isImpervaEvent(event))
			return;
		
		String date = (event.getDate() == null) ? "*" + new Date().toString() + "*" : event.getDate().toString();
		String facility = SyslogUtility.getFacilityString(event.getFacility() << 3);
		String level = SyslogUtility.getLevelString(event.getLevel());
		String message = "{" + facility + "," + level + "} " + date + " " + event.getMessage();
		
        MessageHandler handler = MessageHandler.getInstance();
        handler.addMessage(event.getLevel(), message);
        
        ArrayList<WAFEventDTO> msgs = (ArrayList<WAFEventDTO>) handler.getConsolidatedMessages(WAFProperties.getIntProperty("waf.buffer.size", 10));

        if (msgs != null) {
			String concatedMsg = "";
			boolean highPriorityPackage = false;
			int lowPriorityVal = Integer.MAX_VALUE;
			String newline = System.getProperty("line.separator");
			for (WAFEventDTO msg : (ArrayList<WAFEventDTO>) msgs) {
				perfLogger.trace("About to send msg - Message ID: " + msg.getMessageID()  + ", Priority: " + msg.getPriority());
				lowPriorityVal = Math.min(msg.getPriority(), lowPriorityVal);
				concatedMsg += msg.getMessage() + (msgs.size() > 1 ? newline : "");
			}
			highPriorityPackage = lowPriorityVal <= WAFProperties.getIntProperty("waf.msg.priority.threshold");
	
			try {
				//initQueueClient();
				logger.trace("in JMSSyslogServerEventHandler.init()");
				
				JMSQueueClient lQueueClient = new JMSQueueClient();
				Map<String, String> configs = getJMSQueueConfig();
				
				lQueueClient.initQueueClient(configs);

				TextMessage jmsMessage = lQueueClient.createTextMessage();
				//jmsMessage.setText("{" + facility + "," + level + "} " + date + " " + event.getMessage());
				jmsMessage.setText(concatedMsg);
				lQueueClient.sendMessage(jmsMessage);//, lowPriorityVal); //send with the lowest priority value among the bundled messages
				perfLogger.trace("message sent: " + concatedMsg);
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				logger.error(ExceptionUtils.getStackTrace(e));
			} catch (JMSClientException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
			}
        }
	}

	@Override
	public void exception(SyslogServerIF syslogServer,
			SocketAddress socketAddress, Exception exception) {
		logger.error(ExceptionUtils.getStackTrace(exception));
	}

}

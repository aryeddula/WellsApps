/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.waf.syslog;

/**
 * Interface for buffering multiple incoming messages before they are retrieved and sent.
 * 
 * @author zhushiwe
 *
 */
public interface MessageBufferIntf {
	
	/**
	 * Sets the size of the buffer, which determines the number of messages to be bundled into one
	 * being sent. This size may be different from the capacity of the buffer, depending on the implementation.
	 * 
	 * @param size
	 */
	public void setSize(int size);
	
	/**
	 * Returns the current size of the buffer.
	 * @return
	 */
	public int getSize();
	
	/**
	 * Checks if the buffer contains enough messages to be bundled into one
	 * @return
	 */
	public boolean isFull();
	
	/**
	 * Adds the specified message into the buffer, waiting to be sent.
	 * @param priority message priority
	 * @param message message to be added
	 */
	public void addMessage(int priority, Object message);
	
	/**
	 * Retrieves the messages stored in the buffer, up to the number defined by size {@link #getSize()}.
	 * Retrieved messages are then removed from the buffer.
	 * @return Object containing the bundled messages.
	 */
	public Object getBufferedMessages();
	
}

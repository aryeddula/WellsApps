/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.waf.syslog;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.apache.log4j.Logger;

/**
 * @author zhushiwe
 *
 */
public class PrioritizedMessageBuffer implements MessageBufferIntf, Serializable{
	
	private static final long serialVersionUID = 4547688102650795752L;
	
	private int bufferSize;
	private long msgIDCounter = 0L;
	
	private TreeSet<WAFEventDTO> orderedSet;
	
	private static final Logger logger = Logger.getLogger(PrioritizedMessageBuffer.class);
	
	public PrioritizedMessageBuffer() {
		orderedSet = new TreeSet<WAFEventDTO>(new PriorityComparator());
	}

	public synchronized void addMessage(int priority, Object message) {

		orderedSet.add(new WAFEventDTO(message, priority, generateMessageID()));
	}

	private synchronized long generateMessageID() {
		return msgIDCounter++;
	}

	public synchronized Object getBufferedMessages() {
		ArrayList<Object> bundledMessages = new ArrayList<Object>();
		int count = 1;
		for (Object element : orderedSet) {
			WAFEventDTO object = (WAFEventDTO) element;
			bundledMessages.add(object);
			if (count++ >= bufferSize) break;
		}
		
		if (bundledMessages.size() > 0) {
			boolean success = orderedSet.removeAll(bundledMessages);
			if (!success) {
				logger.debug("Failed to remove from the buffer...");
			}
		}
		
		return bundledMessages.size() > 0 ? bundledMessages : null;
	}

	public synchronized int getSize() {
		return bufferSize;
	}

	public synchronized boolean isFull() {
		return orderedSet.size() >= this.bufferSize;
	}

	public synchronized void setSize(int size) {
		bufferSize = size;
	}
	
	private class PriorityComparator implements Comparator<WAFEventDTO> {

		public int compare(WAFEventDTO o1, WAFEventDTO o2) {
			
			WAFEventDTO msg1 = (WAFEventDTO) o1;
			WAFEventDTO msg2 = (WAFEventDTO) o2;
			
			int val = 0;
			if (msg1.getPriority() < msg2.getPriority())
				val = -1;
			else if (msg1.getPriority() > msg2.getPriority())
				val = 1;
			else {
				//equal priority, then compare message ID. Older message has higher priority.
				long id1 = msg1.getMessageID();
				long id2 = msg2.getMessageID();
				val = id1 < id2 ? -1 : (id1 > id2 ? 1 : 0); 
			}
			
			return val;
		}
		
	}

}

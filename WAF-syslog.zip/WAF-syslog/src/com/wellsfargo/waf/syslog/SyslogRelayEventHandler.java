/**
 * 
 */
package com.wellsfargo.waf.syslog;

import java.net.SocketAddress;

import org.apache.log4j.Logger;
import org.productivity.java.syslog4j.Syslog;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfig;
import org.productivity.java.syslog4j.impl.net.udp.UDPNetSyslogConfig;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.SyslogServerIF;
import org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF;

import com.wellsfargo.waf.WAFProperties;
import com.wellsfargo.waf.util.WAFEventUtility;

/**
 * Event handler to relay/redirect received Syslog messages to another destination, e.g. ArcSight.
 * @author zhushiwe
 *
 */
public class SyslogRelayEventHandler implements SyslogServerSessionlessEventHandlerIF {
	
	private SyslogIF[] syslogInst;
	
	private Logger logger = Logger.getLogger(getClass());

	/* (non-Javadoc)
	 * @see org.productivity.java.syslog4j.server.SyslogServerEventHandlerIF#initialize(org.productivity.java.syslog4j.server.SyslogServerIF)
	 */
	@Override
	public void initialize(SyslogServerIF syslogServer) {
		
		String[] hosts = WAFProperties.getStringArray("waf.relay.host");
//		String[] enabled = WAFProperties.getStringArray("waf.relay.hosts.enabled");
		String[] ports = WAFProperties.getStringArray("waf.relay.port");
		String[] protocols = WAFProperties.getStringArray("waf.relay.protocol");
		
//		int port = WAFProperties.getIntProperty("waf.relay.port", 514);
//		String protocol = WAFProperties.getProperty("waf.relay.protocol", "tcp");
		
		syslogInst = new SyslogIF[hosts.length];
		for (int i = 0; i < syslogInst.length; i++)
		{
			syslogInst[i] = Syslog.createInstance(protocols[i]+i, 
					protocols[i].equalsIgnoreCase("tcp") ? new TCPNetSyslogConfig() : new UDPNetSyslogConfig());
			// instead of calling Syslog.getInstance() which returns a Singleton, use createInstance for each host
			
			SyslogConfigIF syslogConfig = syslogInst[i].getConfig();
			syslogConfig.setHost(hosts[i]);
			syslogConfig.setPort(Integer.valueOf(ports[i]));
			syslogConfig.setThrowExceptionOnInitialize(true);
			syslogConfig.setThrowExceptionOnWrite(true);
			
			logger.debug("Syslog Relay: host = " + hosts[i] + ", port = " + ports[i] + ", protocol = " + protocols[i] );
		}
		
	}

	/* (non-Javadoc)
	 * @see org.productivity.java.syslog4j.server.SyslogServerEventHandlerIF#destroy(org.productivity.java.syslog4j.server.SyslogServerIF)
	 */
	@Override
	public void destroy(SyslogServerIF syslogServer) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF#event(org.productivity.java.syslog4j.server.SyslogServerIF, java.net.SocketAddress, org.productivity.java.syslog4j.server.SyslogServerEventIF)
	 */
	@Override
	public void event(SyslogServerIF syslogServer, SocketAddress socketAddress,
			SyslogServerEventIF event) {
		if (!WAFProperties.getBoolean("waf.syslog.relay") ||
			!WAFEventUtility.isValidEventSource(socketAddress, event) ||
			!WAFEventUtility.isImpervaEvent(event))
			return;
		
		event.setFacility(event.getFacility() << 3); // a hack to fix a syslog4j bug on facility mapping
		
		
		String message = event.getMessage();
		String vStr = WAFProperties.getProperty("waf.relay.version");
		boolean versioning = vStr != null && !vStr.isEmpty();
		
		if (versioning) {
			event.setMessage(message.replaceFirst("Imperva Inc\\.", vStr));
		}
		
		for (int i = 0; i < syslogInst.length; i++)
		{
			SyslogConfigIF syslogConfig = syslogInst[i].getConfig();
			syslogConfig.setFacility(event.getFacility());
//			syslogConfig.setSendLocalTimestamp(false);
//			syslogConfig.setSendLocalName(false);
	
			try {
				syslogInst[i].log(event.getLevel(), event.getMessage());
				logger.trace("Relayed: " + WAFEventUtility.getFormattedSyslogMessage(event));
			} catch (SyslogRuntimeException sre) {
				logger.trace(sre.getMessage());
			} catch (Exception ex) {
				logger.trace(ex.getMessage());
			}
		}
		
		if (versioning)
			event.setMessage(message); //restore the original message
		
		// event.setFacility(event.getFacility() >> 3); // a hack to fix a syslog4j bug on facility mapping

	}

	/* (non-Javadoc)
	 * @see org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF#exception(org.productivity.java.syslog4j.server.SyslogServerIF, java.net.SocketAddress, java.lang.Exception)
	 */
	@Override
	public void exception(SyslogServerIF syslogServer,
			SocketAddress socketAddress, Exception exception) {
		// TODO Auto-generated method stub

	}

}

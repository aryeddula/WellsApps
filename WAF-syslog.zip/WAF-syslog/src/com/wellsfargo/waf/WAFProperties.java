/**
 * 
 */
package com.wellsfargo.waf;

import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

/**
 * @author zhushiwe
 *
 */
public class WAFProperties {
	private static final String WAF_PROP_FILENAME = "props/waf.properties";
	
	private static PropertiesConfiguration props;
	
	private static Logger logger = Logger.getLogger(WAFProperties.class);
	
	static {
		load();
	}
	
	private static void load() {
		String fname = WAF_PROP_FILENAME;
		try {
//			PropertiesConfiguration.setDefaultListDelimiter(',');
			props = new PropertiesConfiguration(fname);
			props.setReloadingStrategy(new FileChangedReloadingStrategy());
//			props.setListDelimiter('|');
//			props.setDelimiterParsingDisabled(false);
			
		} catch (ConfigurationException e) {
			logger.error("failed to load " + fname);
			logger.error(ExceptionUtils.getStackTrace(e));
		}
	}
	
	public static String getProperty(String key) {
		return  props.getString(key);
	}
	
	public static String getProperty(String key, String defaultValue) {
		return props.getString(key, defaultValue);
	}
	
	public static int getIntProperty(String key, int defaultValue) {
		return props.getInt(key, defaultValue);
	}
	
	public static int getIntProperty(String key) {
		return props.getInt(key);
	}
	
	/**
	 * Returns a boolean value for the key. If no match is found for the key, returns false.
	 * @param key
	 * @return
	 */
	public static boolean getBoolean(String key) {
		return props.getBoolean(key, false);
	}
	
	public static List getList(String key) {
		return props.getList(key);
	}
	
	public static String[] getStringArray(String key) {
		return props.getStringArray(key);
	}

}

/**
 * 
 */
package com.wellsfargo.waf.util;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

import com.wellsfargo.waf.WAFProperties;

/**
 * @author zhushiwe
 *
 */
public class WAFEventUtility {
	private static Logger logger = Logger.getLogger(WAFEventUtility.class);
	
	private static String[] impervaSyslogKeywords = new String[] {"Imperva Inc.", "SecureSphere"};
	
	public static boolean isValidEventSource(SocketAddress socketAddress,
			SyslogServerEventIF event) {
		
		if (!WAFProperties.getBoolean("waf.ipfiltering"))
			return true;
		
		List<String> whiteList = WAFProperties.getList("waf.syslog.whitelist");
		InetSocketAddress address = (InetSocketAddress) socketAddress;
		String hostName = address.getHostName();
//		int port = address.getPort();
		boolean valid = false;
		for (Iterator iterator = whiteList.iterator(); iterator.hasNext() && !valid;) {
			String allowed = (String) iterator.next();
			valid = allowed.equalsIgnoreCase(hostName);
		}
		if (!valid) {
			logger.warn("source ip not in whitelist: " + hostName);
			logger.warn("Message: " + event.getMessage());
		}
		
		return valid;
	}
	
	public static boolean isImpervaEvent(SyslogServerEventIF event) {
		boolean retVal = true;
		
		String msg = event.getMessage();
		for (int i = 0; i < impervaSyslogKeywords.length; i++) {
			retVal &= (msg.indexOf(impervaSyslogKeywords[i]) != -1);
		}
		
		return retVal;
	}
	
	public static String getFormattedSyslogMessage(SyslogServerEventIF event) {
		String date = (event.getDate() == null) ? "*" + new Date().toString() + "*" : event.getDate().toString();
		String facility = SyslogUtility.getFacilityString(event.getFacility());
		String level = SyslogUtility.getLevelString(event.getLevel());
		
		String msg = "{" + facility + "," + level + "} " + date + " " + event.getMessage();
		
		return msg;
	}
}

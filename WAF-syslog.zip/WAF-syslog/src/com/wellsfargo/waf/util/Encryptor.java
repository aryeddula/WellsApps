package com.wellsfargo.waf.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStore.SecretKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import com.wellsfargo.waf.WAFProperties;

/**
 * keytool command.
 * keytool -genseckey -keyalg AES -alias myseckey -keysize 128 -keypass
 * mykeypass -storetype jceks -keystore mystore.jck -storepass mystorepass
 */

public class Encryptor {

    private static final String PROP_KEY_ALIAS = "waf.crypto.keyAlias";
	private static final String PROP_KEYSTORE_PASSWORD = "waf.crypto.storePassword";
	private static final String PROP_KEYSTORE_PATH = "waf.crypto.keystorePath";
	private static final String KEYSTORE_TYPE = "JCEKS";
//    private static final String PATH_TO_KEYSTORE = "props/WAFKeyStore";
    private static final String UNICODE_FORMAT  = "UTF8";
    private static final String ALGO  = "AES";

    private static Encryptor mEncryptor = null;
    
    private KeyStore ks;
    private Cipher cipher;
    private String storePassword;
    
    private Encryptor() throws Exception {
    	this(KEYSTORE_TYPE, 
    	     WAFProperties.getProperty(PROP_KEYSTORE_PATH), 
    	     /*System.getProperty(PROP_KEYSTORE_PASSWORD)*/ "?kSlGgYQcx");
    }
    
    private Encryptor(final String typeKeyStore,
		              final String pathToKeyStore,
		              final String storePassword) 
		    throws Exception {
    	this.storePassword =storePassword;
    	
        ks = KeyStore.getInstance(typeKeyStore);
        ks.load(new FileInputStream(pathToKeyStore),
                storePassword.toCharArray());
        
        cipher = Cipher.getInstance(ALGO);
    }
    
    public static Encryptor getInstance(final String typeKeyStore, final String pathToKeyStore, final String storePassword) 
    		throws Exception {
    	if (mEncryptor == null) {
    		mEncryptor = new Encryptor(typeKeyStore, pathToKeyStore, storePassword);
    	}
    	
    	return mEncryptor;
    }
    
    public static Encryptor getInstance() throws Exception {
    	if (mEncryptor == null) {
    		mEncryptor = new Encryptor();
    	}
    	
    	return mEncryptor;
    }
    
    /**
     * @param typeKeyStore
     * @param pathToKeyStore
     * @param storePassword
     * @param aliasPassword
     * @param keyAlias
     * @throws java.io.FileNotFoundException
     * @throws java.security.cert.CertificateException
     *
     * @throws java.security.UnrecoverableEntryException
     *
     */

    private SecretKey getSecretKey(final String keyAlias,
                                  final String aliasPassword) throws KeyStoreException,
            IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableEntryException {

        SecretKeyEntry entry = (SecretKeyEntry) ks.getEntry(
                keyAlias,
                new KeyStore.PasswordProtection(aliasPassword
                        .toCharArray()));
        return entry.getSecretKey();
    }
    
    public String encrypt(final String keyAlias, final String text) throws Exception {
    	return this.encrypt(keyAlias, storePassword, text);
    }
    
    public String encrypt(final String text) throws Exception {
    	String keyAlias = WAFProperties.getProperty(PROP_KEY_ALIAS);
    	return this.encrypt(keyAlias, text);
    }
    
    public synchronized String encrypt(final String keyAlias, final String aliasPassword, final String text) 
    		throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException, 
    		KeyStoreException, CertificateException, NoSuchAlgorithmException, UnrecoverableEntryException, IOException {
        // Initialize the cipher for encryption
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(keyAlias, aliasPassword));
        byte[] textEncrypted = cipher.doFinal(text.getBytes(UNICODE_FORMAT));

        String encodeBase64String = new BASE64Encoder().encode(textEncrypted);
        return encodeBase64String;
    }
    
    public String decrypt(final String keyAlias, final String encrypted) throws Exception {
    	return this.decrypt(keyAlias, storePassword, encrypted);
    }
    
    public String decrypt(final String encrypted) throws Exception {
    	String keyAlias = WAFProperties.getProperty(PROP_KEY_ALIAS);
    	return this.decrypt(keyAlias, encrypted);
    }
    
    public synchronized String decrypt(final String keyAlias, final String aliasPassword, final String encrypted)
    		throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, KeyStoreException, CertificateException, NoSuchAlgorithmException, UnrecoverableEntryException, IOException {
        // Switch the cipher to decryption
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(keyAlias, aliasPassword));

        byte[] decodedValue = new BASE64Decoder().decodeBuffer(encrypted);

        // Decrypt the text
        cipher.doFinal(decodedValue);
        
        String decrypted = new String(cipher.doFinal(decodedValue));
        
    	return decrypted;
    }
    
    public static void main(String[] args) {
    	if (args.length != 1)
    		System.out.println("Please specify the plain text");
    	
    	String text = "enEOWMBu/8VAAgCY8yRN7w==";
    	Encryptor enc;
		try {
			enc = Encryptor.getInstance();
//	    	String encrypted = enc.encrypt(text);
	    	String decrypted = enc.decrypt(text);
	    	if (decrypted.equals(text))
	    		System.out.println("Encrypted value = " + decrypted);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


}
sed -i 's/^waf\.listener\.stop=[Ff][Aa][Ll][Ss][Ee]\s*$/waf\.listener\.stop=true/' /apps/wwaf/listener/props/waf.properties


#!/bin/bash
/apps/wwaf/java/jre1.7.0_45-64/bin/java -Dlog4j.configuration=props/log4j.xml -Dwaf.crypto.storePassword=?kSlGgYQcx -jar ../../WAF-Syslog.jar -p 5512 -o test.out -a udp

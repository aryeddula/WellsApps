#ENVMT=uat | prod
ENVMT=uat
# DC (DadatCenter code) = uat | nc | al | mn | az
DC=uat
#MODE =debug | prod
MODE=debug

#JNDI configs
PROTOCOL=t3s
#HOST=`hostname -f`
HOST=wwaf-listener-$DC.wellsfargo.com
PORT=9001

#copy the properties for the corresponding environment
cd /apps/wwaf/listener/props
cp waf.$ENVMT.properties waf.properties
cp log4j.$ENVMT.xml log4j.xml

#set the JMS provider ui, which should always be local listener weblogic instance
sed -i "s/^waf\.jndi\.provider=.*$/waf\.jndi\.provider=$PROTOCOL\:\/\/$HOST\:$PORT/" /apps/wwaf/listener/props/waf.properties

#flip the property to start listener
sed -i 's/^waf\.listener\.stop=[Tt][Rr][Uu][Ee]\s*$/waf\.listener\.stop=false/' /apps/wwaf/listener/props/waf.properties

cd /apps/wwaf/listener/sh/TCP
./start.$MODE.sh 1>out.log 2>err.log &

cd /apps/wwaf/listener/sh/UDP
./start.$MODE.sh 1>out.log 2>err.log &


